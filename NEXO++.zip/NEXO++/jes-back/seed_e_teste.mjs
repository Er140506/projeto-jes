

const BASE = "http://localhost:3000";

async function req(method, path, body, token) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  const resp = await fetch(BASE + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await resp.json();
  } catch {
    data = null;
  }
  return { status: resp.status, data };
}

function log(acao, ok, detalhe) {
  console.log(`${ok ? "✅" : "❌"} ${acao}${detalhe ? " :: " + detalhe : ""}`);
}

async function main() {
  console.log("\n===== Cadastrando a Copa NEXO =====\n");

  // --- Login/registro ---
  const email = `ana.carolina${Date.now()}@gmail.com`;
  const registro = await req("POST", "/auth/registrar", {
    nome: "ana carolina",
    email,
    senha: "professora123",
    codigoProfessor: process.env.CODIGO_PROFESSOR || "defina_um_codigo_secreto ",
  });
  log("Cadastrar conta de professor", registro.status === 201, `status ${registro.status}`);
  if (registro.status !== 201) {
    console.log("Detalhe do erro de cadastro:", JSON.stringify(registro.data));
  }

  const login = await req("POST", "/auth/login", {
    email,
    senha: "professora123",
  });
  log("Login", login.status === 200, `status ${login.status}`);
  const token = login.data?.token || registro.data?.token;

  // --- Séries ---
  const seriesData = [
    { nome: "Série A - Ensino Médio", nivel: "Médio", pais: "Brasil", corPrimaria: "#1D4ED8", corSecundaria: "#FFFFFF" },
    { nome: "Série B - Fundamental II", nivel: "Fundamental", pais: "Brasil", corPrimaria: "#16A34A", corSecundaria: "#F0FDF4" },
  ];
  const seriesIds = {};
  for (const s of seriesData) {
    const r = await req("POST", "/series", s, token);
    log(`Série "${s.nome}"`, r.status === 201, `status ${r.status}`);
    seriesIds[s.nome] = r.data?.serie?.id;
  }

  // --- Modalidades ---
  const modalidades = [
    { nome: "Futsal", emoji: "⚽", tipo: "equipe", minJogadores: 5, maxJogadores: 10, formato: "eliminatoria" },
    { nome: "Vôlei", emoji: "🏐", tipo: "equipe", minJogadores: 6, maxJogadores: 12, formato: "pontoscorridos" },
    { nome: "Atletismo - 100m", emoji: "🏃", tipo: "individual", minJogadores: 1, maxJogadores: 4, formato: "ranking", ranking: true },
  ];
  const modIds = {};
  for (const m of modalidades) {
    const r = await req("POST", "/modalidades", m, token);
    log(`Modalidade "${m.nome}"`, r.status === 201, `status ${r.status}`);
    modIds[m.nome] = r.data?.msg?.id;
  }

  // --- Equipes ---
  const equipes = [
    { modalidadeId: modIds["Futsal"], turma: "3D", nome: "3D Futsal", jogadores: 8 },
    { modalidadeId: modIds["Futsal"], turma: "3E", nome: "3E Futsal", jogadores: 7 },
    { modalidadeId: modIds["Vôlei"], turma: "3D", nome: "3D Vôlei", jogadores: 6, serieId: seriesIds["Série A - Ensino Médio"] },
    { modalidadeId: modIds["Vôlei"], turma: "3E", nome: "3E Vôlei", jogadores: 6, serieId: seriesIds["Série A - Ensino Médio"] },
    { modalidadeId: modIds["Atletismo - 100m"], turma: "3D", nome: "3D Atletismo", jogadores: 1 },
    { modalidadeId: modIds["Atletismo - 100m"], turma: "3E", nome: "3E Atletismo", jogadores: 1 },
  ];
  const equipeIds = {};
  for (const e of equipes) {
    const r = await req("POST", "/equipes", e, token);
    const ok = r.status === 201;
    log(`Equipe "${e.nome}"`, ok, `status ${r.status}`);
    if (ok) equipeIds[e.nome] = r.data?.msg?.id ?? r.data?.id;
  }

  // --- Chaveamentos ---
  console.log("\n--- Gerando chaveamentos ---\n");
  const chaveamentos = {};
  for (const nome of ["Futsal", "Vôlei"]) {
    const r = await req("POST", `/modalidades/${modIds[nome]}/chaveamento`, null, token);
    log(`Chaveamento de "${nome}"`, r.status === 200, `status ${r.status}`);
    chaveamentos[nome] = Array.isArray(r.data) ? r.data : r.data?.msg || [];
  }

  // --- Resultados ---
  console.log("\n--- Lançando resultados ---\n");
  for (const p of Array.isArray(chaveamentos["Vôlei"]) ? chaveamentos["Vôlei"] : []) {
    if (!p.timeA || !p.timeB) continue;
    const placarA = Math.floor(Math.random() * 3) + 1;
    let placarB = Math.floor(Math.random() * 3) + 1;
    if (placarB === placarA) placarB = placarA + 1;
    const r = await req("PUT", `/partidas/${p.id}`, {
      placarA, placarB, status: "finalizado", local: "Quadra Poliesportiva", data: "2026-09-08",
    }, token);
    log(`Vôlei: ${p.timeA?.nome} ${placarA} x ${placarB} ${p.timeB?.nome}`, r.status === 200, `status ${r.status}`);
  }
  const jogosFutsal = Array.isArray(chaveamentos["Futsal"]) ? chaveamentos["Futsal"] : [];
  for (const p of jogosFutsal.filter(p => p.rodada === 1)) {
    if (!p.timeA || !p.timeB) continue;
    const placarA = Math.floor(Math.random() * 4);
    let placarB = Math.floor(Math.random() * 4);
    if (placarB === placarA) placarB = placarA + 1;
    const r = await req("PUT", `/partidas/${p.id}`, {
      placarA, placarB, status: "finalizado", local: "Quadra Coberta", data: "2026-09-08",
    }, token);
    log(`Futsal (rodada 1): ${p.timeA?.nome} ${placarA} x ${placarB} ${p.timeB?.nome}`, r.status === 200, `status ${r.status}`);
  }

  // --- Provas e resultados de Atletismo ---
  console.log("\n--- Atletismo ---\n");
  const provaFinal = await req("POST", "/provas", {
    modalidadeId: modIds["Atletismo - 100m"],
    nome: "Final 100m rasos",
    tipoMarca: "menor",
  }, token);
  log("Cadastrar prova (100m)", provaFinal.status === 201, `status ${provaFinal.status}`);
  const provaId = provaFinal.data?.prova?.id;

  const marcas = [
    { nome: "3D Atletismo", marca: 12.45 },
    { nome: "3E Atletismo", marca: 13.02 },
  ];
  for (const m of marcas) {
    const r = await req("POST", "/resultados", { provaId, equipeId: equipeIds[m.nome], marca: m.marca }, token);
    log(`Marca de ${m.nome} (${m.marca}s)`, r.status === 201, `status ${r.status}`);
  }

  console.log("\nIDs gerados nesta seed:");
  console.log("Modalidades:", modIds);
  console.log("Séries:", seriesIds);
  console.log("Equipes:", equipeIds);
}

main().catch(err => {
  console.error("ERRO FATAL NO SCRIPT DE SEED:", err);
  process.exit(1);
});