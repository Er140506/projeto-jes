# NEXO+

Sistema de gerenciamento e acompanhamento dos Jogos Internos Estudantis (JES). Permite que professores cadastrem modalidades, equipes, partidas, séries e provas, e que alunos e professores acompanhem resultados, classificação e o **Ranking Geral** em tempo real.

O projeto é dividido em dois pacotes, cada um com seu próprio README detalhado:

* `jes-back/` — API REST (Node.js, Express, Sequelize, MySQL) responsável pela regra de negócio, persistência dos dados e autenticação.
* `front-jes/` — interface web (React, Vite) que consome a API e se conecta via Socket.io para atualizações em tempo real.

---

## Principais funcionalidades

### Acompanhamento (aluno e professor)

* Painel inicial com partidas ao vivo e resultados recentes
* Lista de modalidades, com classificação e chaveamento de cada uma
* Lista de equipes, filtrável por modalidade
* Classificação por modalidade (posição, jogos, vitórias, derrotas, pontos)
* **Ranking Geral**: soma os pontos da mesma turma (ex: `3D`) entre todas as modalidades em que ela participa, mesmo sendo cadastros de equipe separados em cada uma
* Atualizações em tempo real via Socket.io, sem precisar recarregar a página

### Gestão (exclusiva para professor, autenticado)

* Cadastro, edição e geração de chaveamento de modalidades
* Cadastro, edição e exclusão de equipes
* Cadastro, edição, lançamento de placar e exclusão de partidas
* Cadastro, edição e exclusão de séries
* Cadastro, edição e exclusão de provas e de seus resultados (marcas)

---

## Regras de negócio

* **Sem empate**: nenhuma partida pode ser finalizada com placares iguais
* **Autenticação exclusiva para professores**: cadastro com código de professor e login; o aluno acessa as informações de acompanhamento sem conta

---

## Tecnologias utilizadas

| Camada    | Tecnologias                                                                            |
| --------- | -------------------------------------------------------------------------------------- |
| Back-end  | Node.js, Express, Sequelize, MySQL, JSON Web Token (JWT), Socket.io, Vitest, Supertest |
| Front-end | React 19, Vite, JavaScript (JSX), socket.io-client, lucide-react, CSS puro             |

Veja a lista completa de dependências e versões nos READMEs de cada pacote.

---

## Estrutura do repositório

```text
NEXO+/
├── jes-back/     # API (Node.js + Express + MySQL)
│   └── README.md
├── front-jes/    # Interface web (React + Vite)
│   └── README.md
└── README.md     # este arquivo
```

A estrutura interna de pastas de cada pacote (controllers, models, components, context etc.) está detalhada nos respectivos READMEs.

---

## Como rodar o projeto completo

### Pré-requisitos

* Node.js
* npm
* Git
* MySQL em funcionamento

### 1. Back-end

```bash
cd jes-back
npm install
cp .env.example .env
```

Configure no `.env`:

```env
DB_HOST=
DB_USER=
DB_PASS=
DB_NAME=
JWT_SECRET=
CODIGO_PROFESSOR=
```

Depois, execute:

```bash
npm run dev
```

A API sobe por padrão em `http://localhost:3000` (ou na porta definida em `PORT`).

### 2. Front-end

Em outro terminal:

```bash
cd front-jes
npm install
cp .env.example .env
```

Configure `VITE_API_URL` com a URL do Back-end:

```env
VITE_API_URL=http://localhost:3000
```

Depois, execute:

```bash
npm run dev
```

A interface fica disponível em `http://localhost:5173`.

Detalhes de cada variável de ambiente e dos demais scripts disponíveis (`build`, `preview`, `lint`, `test`, etc.) estão nos READMEs de `jes-back` e `front-jes`.

---

## Populando o banco com dados fictícios (seed)

Para testar e avaliar o projeto rapidamente — sem precisar cadastrar manualmente modalidades, equipes e partidas antes de conseguir ver a tela funcionando — existe um script de seed que popula o banco com um campeonato fictício completo, a **"Copa NEXO"**, usando a própria API.

De quebra, o script também simula duas pessoas usando o sistema (uma professora cadastrando tudo e um aluno consultando sem login) para checar se a aplicação está respondendo corretamente.

Instruções completas de como rodar, o que é criado e as credenciais de teste geradas estão na seção **"Seed de dados fictícios (dados de teste)"** do README do Back-end.

---

## Testes

O Back-end possui uma suíte de testes automatizados (Vitest + Supertest) cobrindo cadastro, validações, permissões, geração de chaveamento e cálculo de classificação.

Os resultados mais recentes e as instruções para executá-la estão na seção **"Testes"** do README do Back-end.

---

## Autenticação

A autenticação é exclusiva para professores: cadastro com código de professor, login e emissão de token JWT pelo Back-end, enviado como `Authorization: Bearer <token>` nas rotas protegidas do Front-end.

O aluno não possui conta — acessa diretamente as informações públicas de acompanhamento.

---

## Comunicação em tempo real

Back-end e Front-end se conectam através de Socket.io: o Front-end entra nas salas de cada modalidade sendo visualizada e recebe os eventos de partida criada, atualizada ou deletada, além do evento de chaveamento gerado.

Esses eventos permitem atualizar as telas de **Partidas**, **Classificação** e **Ranking Geral** sem necessidade de recarregar a página.
