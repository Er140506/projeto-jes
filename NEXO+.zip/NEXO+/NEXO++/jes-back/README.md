# NEXO+ - Back-end

É uma API responsável pelo gerenciamento dos Jogos Internos Estudantis. Ela oferece diversas funcionalidades de controle, como cadastro, gerenciamento de resultados e acompanhamento em tempo real.

O Back-end do projeto fornece os serviços utilizados pelo Front-end do NEXO+ através de uma API que realiza a comunicação com o banco de dados.

---

## Principais Funções

### Manipulação de Dados

A API viabiliza operações de CRUD para diversos recursos presentes no sistema, incluindo:

* Modalidades
* Equipes
* Resultados
* Partidas
* Provas
* Séries

As operações disponibilizadas incluem:

* Cadastro
* Listagem
* Consultas por ID
* Atualizações
* Exclusão

### Autenticação

O sistema possui funcionalidades de autenticação de usuários de uso exclusivo para os responsáveis. Isso é realizado através de:

* Cadastro de usuário (Professor)
* Login
* Validação de acesso
* Autenticação através de Token JWT

### Comunicação em tempo real

O projeto utiliza o Socket.io para comunicação em tempo real entre o Back-end e o Front-end, permitindo que determinadas informações do sistema sejam atualizadas sem a necessidade de atualização manual da página.

---

## Tecnologias Utilizadas

* Node.js 22.14.0
* JavaScript
* Express 5.2.1
* Sequelize 6.37.8
* MySQL 8.0.45
* MySQL2 3.23.3
* JSON Web Token (JWT) 9.0.3
* CORS 2.8.6
* dotenv 17.4.2
* Socket.io 4.8.3
* Vitest 4.1.11
* Supertest 7.2.2
* Nodemon 3.1.14
* `@vitest/coverage-v8` 4.1.11

---

## Instalação

### Pré-requisitos

Antes de iniciar o projeto, é necessário ter os seguintes componentes instalados:

* Node.js
* npm
* Git
* MySQL

Após instalar os pré-requisitos, clone o projeto para sua máquina.

### 1. Clonar o projeto

Utilize:

```bash
git clone (link do projeto)
```

Depois, entre na pasta do projeto:

```bash
cd jes-back
```

### 2. Instalar as dependências

Instale as dependências utilizando:

```bash
npm install
```

ou:

```bash
npm i
```

Após concluir as configurações necessárias, execute:

```bash
npm run dev
```

O comando inicia o servidor utilizando o Nodemon e o arquivo `src/server.js`.

Por padrão, a aplicação utiliza a porta `3000`, podendo ser alterada pela variável `PORT`.

Após a inicialização, a API estará disponível em:

`http://localhost:3000`

---

## Configuração

Após instalar as dependências, é necessário configurar o banco de dados e as variáveis de ambiente utilizadas pela aplicação.

### Banco de dados

O NEXO+ utiliza o MySQL como banco de dados e o Sequelize como ORM para realizar a comunicação entre a aplicação e o banco.

Durante a inicialização do servidor, o Sequelize sincroniza os modelos definidos no projeto com o banco de dados através de `conexao.sync()`.

O banco de dados é essencial para o projeto, pois as informações necessárias para o funcionamento do sistema são armazenadas nele, como:

* Tabelas de modalidades
* Resultados
* Partidas
* Equipes
* Séries
* Provas

É necessário possuir uma instalação do MySQL em funcionamento para executar o Back-end.

### Criação do banco

Antes de iniciar a aplicação, é necessário possuir o banco de dados configurado.

Caso o banco ainda não exista, ele pode ser criado no MySQL utilizando:

```sql
CREATE DATABASE jes;
```

Depois disso, as informações de acesso ao banco devem ser configuradas no arquivo `.env`.

O banco utilizado pelo projeto é configurado através das variáveis de ambiente.

---

## Variáveis de ambiente

### `.env`

O projeto utiliza o arquivo `.env` para armazenar configurações do sistema, incluindo informações do banco de dados, porta da API e autenticação.

Crie um arquivo `.env` na raiz do projeto e configure-o através das variáveis necessárias.

Exemplo:

```env
DB_HOST=localhost
DB_USER=root
DB_PASS=sua_senha
DB_NAME=jes
JWT_SECRET=seu_secret
JWT_EXPIRES_IN=12h
CODIGO_PROFESSOR=seu_codigo
```

Os nomes das variáveis devem ser correspondentes e exatos.

### Descrição das variáveis

| Variável           | Função                                             |
| ------------------ | -------------------------------------------------- |
| `DB_HOST`          | Endereço do servidor MySQL                         |
| `DB_USER`          | Usuário utilizado para acessar o banco             |
| `DB_PASS`          | Senha do usuário do banco                          |
| `DB_NAME`          | Nome do banco de dados utilizado pelo projeto      |
| `JWT_SECRET`       | Chave utilizada para gerar e validar os tokens JWT |
| `JWT_EXPIRES_IN`   | Define o tempo de expiração dos tokens             |
| `CODIGO_PROFESSOR` | Código utilizado no cadastro de professores        |

**Não compartilhe o arquivo `.env` original e real**, pois ele pode conter credenciais e informações privadas.

---

## Como executar

Após a instalação das dependências e a configuração do banco de dados e do `.env`, execute:

```bash
npm run dev
```

Após iniciar, o sistema estará disponível no endereço indicado pelo terminal.

Por exemplo:

`http://localhost:3000`

---

## Seed de dados fictícios (dados de teste)

Para facilitar o teste e a avaliação do projeto (por exemplo, pelo professor avaliador), existe um script opcional que popula o banco com dados fictícios de um campeonato completo — a **"Copa NEXO"** — usando a própria API (não faz inserção direta no banco).

Como ele passa pela API de verdade, o script também funciona como um teste de ponta a ponta da aplicação.

### O que o script cria

1. 1 usuário professor já cadastrado (e logado durante a execução)
2. 2 séries (turmas/categorias)
3. 5 modalidades: Futsal, Vôlei, Basquete, Atletismo - 100m e Xadrez
4. 17 equipes, distribuídas entre as turmas 3D, 3E, 2A e 2B (a mesma turma aparece em várias modalidades, para também exercitar o cálculo do Ranking Geral)
5. Chaveamentos gerados e partidas com placares já lançados
6. 1 prova de atletismo com marcas lançadas

Além de popular o banco, o script simula duas pessoas usando o sistema — uma professora cadastrando e editando tudo, e um aluno sem login tentando ações que deveriam ser bloqueadas — e imprime no terminal um resumo de `PASS/FAIL` ao final de cada etapa.

### Como rodar

1. Suba o Back-end normalmente:

```bash
npm run dev
```

2. Confirme que a variável `CODIGO_PROFESSOR` está definida no `.env`.

O script usa `PROF2026` como valor padrão, caso você não informe outro.

3. Salve o arquivo `seed_e_teste.mjs` na raiz do `jes-back` (mesma pasta do `package.json`).

4. Em outro terminal, dentro da pasta `jes-back`, execute:

```bash
node seed_e_teste.mjs
```

Se o Back-end estiver rodando em uma porta diferente de `3001`, ajuste a linha:

```javascript
const BASE = "http://localhost:3001";
```

no início do arquivo antes de rodar.

### Credenciais criadas pela seed

| Campo  | Valor                         |
| ------ | ----------------------------- |
| E-mail | `ana.souza@escolanexo.edu.br` |
| Senha  | `professora123`               |

### Rodando de novo (banco limpo)

O script apenas adiciona dados — ele não apaga o que já existe no banco.

Para recomeçar do zero antes de rodar a seed novamente, recrie o banco:

```sql
DROP DATABASE jes;
CREATE DATABASE jes;
```

Ao reiniciar o Back-end, o Sequelize recria as tabelas automaticamente através de `conexao.sync()`.

---

## Testes

### Como executar os testes

Para executar todos os testes, utilize:

```bash
npm run test
```

Para executar um teste específico, utilize:

```bash
npm run test -- nome_do_arquivo.test.js
```

### Como gerar o coverage

Para gerar o relatório de cobertura dos testes:

```bash
npm run test:coverage
```

O relatório de cobertura será gerado na pasta `coverage/`.

O Coverage permite verificar quais partes do código foram executadas durante os testes.

### Resultados dos Testes

Os testes automatizados foram executados utilizando Vitest e Supertest.

| Métrica                 | Resultado |
| ----------------------- | --------: |
| Suítes de teste         |        14 |
| Testes executados       |       173 |
| Testes aprovados        |       173 |
| Testes reprovados       |         0 |
| Cobertura de Statements |    87,06% |
| Cobertura de Branches   |    83,13% |
| Cobertura de Functions  |    87,77% |
| Cobertura de Lines      |    87,29% |

Todos os 173 testes executados foram aprovados, sem ocorrência de falhas durante a execução da suíte de testes.

A análise de cobertura apresentou:

* 87,06% de cobertura de Statements
* 83,13% de cobertura de Branches
* 87,77% de cobertura de Functions
* 87,29% de cobertura de Lines

---

## O que foi testado

### Cenários considerados

Os testes consideram cenários de sucesso, validação e tratamento de erros, incluindo:

* Operações de cadastro, consulta, atualização e exclusão de modalidades, equipes, partidas, provas, resultados e séries
* Consultas por ID válido, ID inválido e registros inexistentes
* Validação de campos obrigatórios e valores inválidos
* Atualizações completas e parciais, incluindo validação de campos permitidos
* Controle de acesso com autenticação por token JWT
* Validação de tokens ausentes, inválidos, expirados ou adulterados
* Validação das permissões de acesso de professores
* Prevenção de registros duplicados em operações que exigem unicidade
* Detecção de conflitos de horário e local entre partidas
* Geração de partidas para formatos de pontos corridos e eliminatória
* Propagação de vencedores entre partidas de uma chave
* Cálculo e ordenação da classificação das equipes
* Processamento de provas e resultados, incluindo validações e prevenção de resultados duplicados
* Tratamento de erros em operações assíncronas
* Formatação dos dados apresentados pelas views

---

## Testes Unitários x Testes de Integração

### Testes unitários

Os testes unitários verificam partes específicas do sistema de forma isolada, como funções ou determinadas regras de negócio.

Por exemplo, uma função responsável por atualizar um resultado pode ser testada individualmente.

### Testes de integração

Os testes de integração verificam a comunicação entre diferentes partes do sistema.

No NEXO+, isso pode envolver, por exemplo, verificar se uma requisição realizada pela API consegue acessar os componentes necessários e realizar corretamente determinada operação.

---

## Estrutura do Projeto

```text
jes-back/

├── src/
│   ├── config/
│   │   ├── conexao.js
│   │   └── socket.js
│   │
│   ├── controllers/
│   │   ├── authControllers.js
│   │   ├── equipesControllers.js
│   │   ├── modalidadesControllers.js
│   │   ├── partidasControllers.js
│   │   ├── provaControllers.js
│   │   ├── resultadoControllers.js
│   │   └── seriesControllers.js
│   │
│   ├── middlewares/
│   │   ├── authMiddleware.js
│   │   └── permitirProfessor.js
│   │
│   ├── model/
│   │   ├── equipe.js
│   │   ├── index.js
│   │   ├── modalidades.js
│   │   ├── partidas.js
│   │   ├── prova.js
│   │   ├── resultado.js
│   │   ├── series.js
│   │   └── usuarioModel.js
│   │
│   ├── router/
│   │   ├── authRoute.js
│   │   ├── equipesRoute.js
│   │   ├── indexRoute.js
│   │   ├── modalidadesRouter.js
│   │   ├── partidasRoute.js
│   │   ├── provaRoute.js
│   │   ├── resultadoRoute.js
│   │   └── seriesRoute.js
│   │
│   ├── service/
│   │   ├── bracketService.js
│   │   ├── conflictService.js
│   │   └── standingsService.js
│   │
│   ├── utils/
│   │   ├── asyncHandler.js
│   │   ├── erroHandler.js
│   │   ├── gerarToken.js
│   │   └── getToken.js
│   │
│   ├── views/
│   │   ├── equipesViews.js
│   │   ├── modalidadeView.js
│   │   ├── partidaView.js
│   │   ├── provaView.js
│   │   └── seriesViews.js
│   │
│   ├── app.js
│   └── server.js
│
├── test/
├── coverage/
├── .env.example
├── .gitignore
├── package.json
├── package-lock.json
└── README.md
```

### Organização das pastas

| Pasta         | Responsabilidade                                            |
| ------------- | ----------------------------------------------------------- |
| `config`      | Configurações do banco de dados e do Socket.io              |
| `controllers` | Processamento das requisições e respostas da API            |
| `middlewares` | Validações e controle de acesso antes da execução das rotas |
| `model`       | Modelos utilizados para representar os dados do sistema     |
| `router`      | Definição e organização das rotas da API                    |
| `service`     | Regras de negócio e operações específicas do sistema        |
| `utils`       | Funções auxiliares utilizadas pela aplicação                |
| `views`       | Formatação e organização dos dados retornados pela API      |
| `test`        | Testes automatizados do Back-end                            |
| `coverage`    | Relatórios de cobertura dos testes                          |

---

## Integração com o Front-end

O Back-end do NEXO+ disponibiliza os serviços utilizados pelo Front-end através da API.

A comunicação entre as duas partes permite que o Front-end realize operações como cadastro, consulta, atualização e exclusão dos dados, além de receber informações relacionadas às partidas, resultados, equipes, modalidades e demais recursos do sistema.

A autenticação das operações protegidas é realizada através de tokens JWT.
