import { describe, test, expect } from "vitest";
import jwt from "jsonwebtoken";
import { gerarToken } from "../src/utils/gerarToken.js";

process.env.JWT_SECRET = process.env.JWT_SECRET || "segredo-teste";
process.env.JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "12h";

describe("gerarToken", () => {
  test("Deve gerar um token JWT para o usuário", () => {
    const usuario = {
      id: 1,
      email: "professor@email.com",
      tipo: "professor",
    };

    const token = gerarToken(usuario);

    expect(typeof token).toBe("string");
    expect(token.split(".")).toHaveLength(3);
  });

  test("Deve gerar um token que pode ser validado com o segredo configurado", () => {
    const usuario = {
      id: 2,
      email: "teste@email.com",
      tipo: "professor",
    };

    const token = gerarToken(usuario);
    const payload = jwt.verify(token, process.env.JWT_SECRET);

    expect(payload.id).toBe(usuario.id);
    expect(payload.email).toBe(usuario.email);
    expect(payload.tipo).toBe(usuario.tipo);
  });

  test("Deve incluir a data de expiração no token", () => {
    const token = gerarToken({
      id: 3,
      email: "usuario@email.com",
      tipo: "professor",
    });

    const payload = jwt.verify(token, process.env.JWT_SECRET);

    expect(payload).toHaveProperty("iat");
    expect(payload).toHaveProperty("exp");
    expect(payload.exp).toBeGreaterThan(payload.iat);
  });
});
    