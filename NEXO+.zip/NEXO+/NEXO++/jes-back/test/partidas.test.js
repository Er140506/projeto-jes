import { describe, test, expect, beforeAll } from "vitest";
import app from "../src/app.js";
import request from "supertest";
import { conexao as conn } from "../src/config/conexao.js";
import { partidasModel } from "../src/model/index.js";

let token;
let modalidade;

beforeAll(async () => {
  await conn.sync({ force: true });

  const usuario = await request(app)
    .post("/auth/registrar")
    .send({
      nome: "Professor Teste",
      email: `professor${Date.now()}@email.com`,
      senha: "123456789",
      codigoProfessor: process.env.CODIGO_PROFESSOR,
    });

  expect(usuario.status).toBe(201);

  token = usuario.body.token;

  const respostaModalidade = await request(app)
    .post("/modalidades")
    .set("Authorization", `Bearer ${token}`)
    .send({
      nome: `Futebol ${Date.now()}`,
      tipo: "equipe",
      minJogadores: 1,
      maxJogadores: 15,
      formato: "pontoscorridos",
    });

  expect(respostaModalidade.status).toBe(201);

  modalidade = respostaModalidade.body.msg;
});



describe("GET /partidas", () => {
  test("Deve retornar o status 200", async () => {
    const response = await request(app).get("/partidas");

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(Array.isArray(response.body)).toBeTruthy();
  });
});


describe("POST /partidas", () => {
  test("Deve retornar o status 201", async () => {
    const response = await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "pontoscorridos",
        rodada: 1,
        faseNome: "Fase de Grupos",
      });

    expect(response.status).toBe(201);
    expect(response.ok).toBeTruthy();
    expect(response.body.message).toBe("Partida Criada");
    expect(response.body.partida).toBeDefined();
  });

  test("Deve retornar 401 quando não enviar token", async () => {
    const response = await request(app)
      .post("/partidas")
      .send({
        modalidadeId: modalidade.id,
        formato: "pontoscorridos",
        rodada: 2,
        faseNome: "Fase de Grupos",
      });

    expect(response.status).toBe(401);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 409 quando existir conflito de horário", async () => {
    const data = "2026-08-24";
    const hora = "10:00";
    const local = "Quadra 1";

    const primeiraPartida = await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "pontoscorridos",
        rodada: 3,
        faseNome: "Fase de Grupos",
        data,
        hora,
        local,
      });

    expect(primeiraPartida.status).toBe(201);

    const segundaPartida = await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "pontoscorridos",
        rodada: 4,
        faseNome: "Fase de Grupos",
        data,
        hora,
        local,
      });

    expect(segundaPartida.status).toBe(409);
    expect(segundaPartida.ok).toBeFalsy();
    expect(segundaPartida.body.message).toContain(
      "Conflito de horário"
    );
  });
});


describe("GET /partidas/:id", () => {
  test("Deve retornar o status 200", async () => {
    await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "pontoscorridos",
        rodada: 5,
        faseNome: "Fase de Grupos",
      });

    const partida = await partidasModel.findOne({
      order: [["id", "DESC"]],
    });

    const response = await request(app)
      .get(`/partidas/${partida.id}`);

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(response.body.id).toBeDefined();
  });

  test("Deve retornar 404 quando a partida não existir", async () => {
    const response = await request(app).get("/partidas/9999");

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
    expect(response.body.message).toBe("Partida não encontrada");
  });
});


describe("PUT /partidas/:id", () => {
  test("Deve retornar o status 200", async () => {
    await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "pontoscorridos",
        rodada: 6,
        faseNome: "Fase de Grupos",
      });

    const partida = await partidasModel.findOne({
      order: [["id", "DESC"]],
    });

    const response = await request(app)
      .put(`/partidas/${partida.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        status: "finalizado",
        placarA: 2,
        placarB: 1,
      });

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(response.body.message).toBe(
      "Partida atualizada com sucesso"
    );
    expect(response.body.partida).toBeDefined();
  });

  test("Deve propagar o vencedor para a próxima partida", async () => {
    const equipeA = await request(app)
      .post("/equipes")
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: `Equipe A ${Date.now()}`,
        modalidadeId: modalidade.id,
        turma: "3A",
        jogadores: 5,
      });

    const equipeB = await request(app)
      .post("/equipes")
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: `Equipe B ${Date.now()}`,
        modalidadeId: modalidade.id,
        turma: "3A",
        jogadores: 5,
      });

    expect(equipeA.status).toBe(201);
    expect(equipeB.status).toBe(201);

    const idEquipeA = equipeA.body.id;
    const idEquipeB = equipeB.body.id;

    const proximaPartida = await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "eliminatoria",
        rodada: 2,
        faseNome: "Final",
        timeAId: null,
        timeBId: null,
      });

    expect(proximaPartida.status).toBe(201);

    const proxima = proximaPartida.body.partida;

    const partidaAtual = await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "eliminatoria",
        rodada: 1,
        faseNome: "Semifinal",
        timeAId: idEquipeA,
        timeBId: idEquipeB,
        proximaPartidaId: proxima.id,
        proximaPartidaVaga: "A",
      });

    expect(partidaAtual.status).toBe(201);

    const partida = partidaAtual.body.partida;

    const response = await request(app)
      .put(`/partidas/${partida.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        status: "finalizado",
        placarA: 2,
        placarB: 1,
      });

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(response.body.message).toBe(
      "Partida atualizada com sucesso"
    );

    const proximaAtualizada = await partidasModel.findByPk(proxima.id);

    expect(proximaAtualizada.timeAId).toBe(idEquipeA);
  });

  test("Deve retornar 404 caso a partida não exista", async () => {
    const response = await request(app)
      .put("/partidas/9999")
      .set("Authorization", `Bearer ${token}`)
      .send({
        status: "finalizado",
        placarA: 2,
        placarB: 1,
      });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
    expect(response.body.message).toBe("Partida não encontrada");
  });

  test("Deve retornar 401 quando não enviar token", async () => {
    const response = await request(app)
      .put("/partidas/9999")
      .send({
        status: "finalizado",
        placarA: 2,
        placarB: 1,
      });

    expect(response.status).toBe(401);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 409 quando existir conflito de horário", async () => {
    const data = "2026-08-25";
    const hora = "14:00";
    const local = "Quadra 2";

    await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "pontoscorridos",
        rodada: 7,
        faseNome: "Fase de Grupos",
        data,
        hora,
        local,
      });

    const segundaPartida = await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "pontoscorridos",
        rodada: 8,
        faseNome: "Fase de Grupos",
        data: "2026-08-25",
        hora: "15:00",
        local,
      });

    expect(segundaPartida.status).toBe(201);

    const partida = await partidasModel.findOne({
      order: [["id", "DESC"]],
    });

    const response = await request(app)
      .put(`/partidas/${partida.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        data,
        hora,
        local,
      });

    expect(response.status).toBe(409);
    expect(response.ok).toBeFalsy();
    expect(response.body.message).toContain(
      "Conflito de horário"
    );
  });
});

// ======================================================
// DELETE /partidas/:id
// ======================================================

describe("DELETE /partidas/:id", () => {
  test("Deve retornar o status 200 ao deletar uma partida", async () => {
    await request(app)
      .post("/partidas")
      .set("Authorization", `Bearer ${token}`)
      .send({
        modalidadeId: modalidade.id,
        formato: "pontoscorridos",
        rodada: 9,
        faseNome: "Fase de Grupos",
      });

    const partida = await partidasModel.findOne({
      order: [["id", "DESC"]],
    });

    const response = await request(app)
      .delete(`/partidas/${partida.id}`)
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(response.body.message).toBe(
      "Partida deletada com sucesso"
    );
  });

  test("Deve retornar 404 caso a partida não exista", async () => {
    const response = await request(app)
      .delete("/partidas/9999")
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
    expect(response.body.message).toBe("Partida não encontrada");
  });

  test("Deve retornar 401 quando não enviar token", async () => {
    const response = await request(app)
      .delete("/partidas/9999");

    expect(response.status).toBe(401);
    expect(response.ok).toBeFalsy();
  });
});