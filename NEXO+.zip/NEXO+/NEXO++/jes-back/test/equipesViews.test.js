import { describe, test, expect } from "vitest";
import { formatEquipeList } from "../src/views/equipesViews.js";

describe("formatEquipeList", () => {
  test("Deve formatar uma lista de equipes", () => {
    const lista = [
      { id: 1, nome: "Equipe A", modalidadeId: 1, get: undefined },
    ];

    const resultado = formatEquipeList(lista);

    expect(resultado).toHaveLength(1);
    expect(resultado[0].id).toBe(1);
    expect(resultado[0].nome).toBe("Equipe A");
  });
});