import { describe, test, expect, beforeAll } from "vitest";
import app from "../src/app.js";
import request from "supertest";
import { conexao } from "../src/config/conexao.js";

let token;
let modalidade;

beforeAll(async () => {
  await conexao.sync({ force: true });

  const usuario = await request(app)
    .post("/auth/registrar")
    .send({
      nome: "Professor Teste",
      email: `professor${Date.now()}${Math.random()}@email.com`,
      senha: "123456789",
      codigoProfessor: process.env.CODIGO_PROFESSOR,
    });

  expect(usuario.status).toBe(201);

  token = usuario.body.token;

  const respostaModalidade = await request(app)
    .post("/modalidades")
    .set("Authorization", `Bearer ${token}`)
    .send({
      nome: `Atletismo ${Date.now()}${Math.random()}`,
      tipo: "individual",
      minJogadores: 1,
      maxJogadores: 1,
      formato: "ranking",
    });

  expect(respostaModalidade.status).toBe(201);

  modalidade = respostaModalidade.body.msg;
});

const criarProva = async (dados = {}) => {
  return await request(app)
    .post("/provas")
    .set("Authorization", `Bearer ${token}`)
    .send({
      nome: `100m rasos ${Date.now()}${Math.random()}`,
      modalidadeId: modalidade.id,
      tipoMarca: "menor",
      ...dados,
    });
};

// PROVAS

describe("GET /provas", () => {
  test("Deve retornar o status 200 e uma lista", async () => {
    await criarProva();

    const response = await request(app).get("/provas");

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(Array.isArray(response.body)).toBeTruthy();
  });
});

describe("POST /provas", () => {
  test("Deve retornar o status 201 e criar uma prova", async () => {
    const response = await criarProva({
      nome: `200m rasos ${Date.now()}${Math.random()}`,
    });

    expect(response.status).toBe(201);
    expect(response.ok).toBeTruthy();
    expect(response.body.prova).toHaveProperty("id");
    expect(response.body.prova.nome).toContain("200m rasos");
    expect(response.body.prova.tipoMarca).toBe("menor");
  });

  test("Deve retornar 401 sem token", async () => {
    const response = await request(app)
      .post("/provas")
      .send({ nome: `Prova sem token ${Date.now()}`, modalidadeId: modalidade.id });

    expect(response.status).toBe(401);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 sem nome", async () => {
    const response = await request(app)
      .post("/provas")
      .set("Authorization", `Bearer ${token}`)
      .send({ modalidadeId: modalidade.id });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 sem modalidadeId", async () => {
    const response = await request(app)
      .post("/provas")
      .set("Authorization", `Bearer ${token}`)
      .send({ nome: `Prova sem modalidade ${Date.now()}` });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 404 quando a modalidade informada não existir", async () => {
    const response = await criarProva({ modalidadeId: 9999 });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando o tipoMarca for inválido", async () => {
    const response = await criarProva({ tipoMarca: "invalido" });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });
});

describe("PUT /provas/:id", () => {
  test("Deve retornar o status 200 e substituir os dados da prova", async () => {
    const prova = await criarProva();

    const response = await request(app)
      .put(`/provas/${prova.body.prova.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: "Prova Atualizada",
        modalidadeId: modalidade.id,
        tipoMarca: "maior",
      });

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(response.body.prova.nome).toBe("Prova Atualizada");
    expect(response.body.prova.tipoMarca).toBe("maior");
  });

  test("Deve retornar 404 caso a prova não exista", async () => {
    const response = await request(app)
      .put("/provas/9999")
      .set("Authorization", `Bearer ${token}`)
      .send({ nome: "Prova Atualizada", modalidadeId: modalidade.id });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 sem nome", async () => {
    const prova = await criarProva();

    const response = await request(app)
      .put(`/provas/${prova.body.prova.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ modalidadeId: modalidade.id });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });
});

describe("PATCH /provas/:id", () => {
  test("Deve retornar o status 200 atualizando somente um campo", async () => {
    const prova = await criarProva();

    const response = await request(app)
      .patch(`/provas/${prova.body.prova.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ tipoMarca: "maior" });

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(response.body.prova.tipoMarca).toBe("maior");
  });

  test("Deve retornar 400 quando nenhum campo for enviado", async () => {
    const prova = await criarProva();

    const response = await request(app)
      .patch(`/provas/${prova.body.prova.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({});

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve ignorar campos fora da whitelist", async () => {
    const prova = await criarProva();

    const response = await request(app)
      .patch(`/provas/${prova.body.prova.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ id: 99999, tipoMarca: "maior" });

    expect(response.status).toBe(200);
    expect(response.body.prova.id).toBe(prova.body.prova.id);
  });

  test("Deve retornar 404 caso a prova não exista", async () => {
    const response = await request(app)
      .patch("/provas/9999")
      .set("Authorization", `Bearer ${token}`)
      .send({ tipoMarca: "maior" });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });
});

describe("DELETE /provas/:id", () => {
  test("Deve retornar o status 200", async () => {
    const prova = await criarProva();

    const response = await request(app)
      .delete(`/provas/${prova.body.prova.id}`)
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
  });

  test("Deve retornar 404 caso a prova não exista", async () => {
    const response = await request(app)
      .delete("/provas/9999")
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });
});