import { describe, test, expect } from "vitest";
import { getToken } from "../src/utils/getToken.js";

describe("getToken", () => {
    test("Deve retornar null quando o header Authorization não existir", () => {
        const request = { headers: {} };

        expect(getToken(request)).toBeNull();
    });

    test("Deve extrair o token do header Authorization", () => {
        const request = {
            headers: {
                authorization: "Bearer token-de-teste",
            },
        };

        expect(getToken(request)).toBe("token-de-teste");
    });

    test("Deve retornar null quando o header não possuir token", () => {
        const request = {
            headers: {
                authorization: "Bearer",
            },
        };

        expect(getToken(request)).toBeNull();
    });

    test("Deve extrair somente a parte do token depois do primeiro espaço", () => {
        const request = {
            headers: {
                authorization: "Bearer token-extra",
            },
        };

        expect(getToken(request)).toBe("token-extra");
    });
});
