
import { describe, test, expect, beforeAll } from "vitest";
import app from "../src/app.js";
import request from "supertest";
import { conexao } from "../src/config/conexao.js";

let token;
let modalidade;

beforeAll(async () => {
  await conexao.sync({ force: true });

  const usuario = await request(app)
    .post("/auth/registrar")
    .send({
      nome: "Professor Teste",
      email: `professor${Date.now()}${Math.random()}@email.com`,
      senha: "123456789",
      codigoProfessor: process.env.CODIGO_PROFESSOR,
    });

  expect(usuario.status).toBe(201);

  token = usuario.body.token;

  const respostaModalidade = await request(app)
    .post("/modalidades")
    .set("Authorization", `Bearer ${token}`)
    .send({
      nome: `Atletismo ${Date.now()}${Math.random()}`,
      tipo: "individual",
      minJogadores: 1,
      maxJogadores: 1,
      formato: "ranking",
    });

  expect(respostaModalidade.status).toBe(201);

  modalidade = respostaModalidade.body.msg;
});

const gerarEquipe = async (dados = {}) => {
  const response = await request(app)
    .post("/equipes")
    .set("Authorization", `Bearer ${token}`)
    .send({
      nome: `Equipe ${Date.now()}${Math.random()}`,
      modalidadeId: modalidade.id,
      jogadores: 5,
      ...dados,
    });

  return response.body;
};

const gerarProva = async (dados = {}) => {
  const response = await request(app)
    .post("/provas")
    .set("Authorization", `Bearer ${token}`)
    .send({
      nome: `100m rasos ${Date.now()}${Math.random()}`,
      modalidadeId: modalidade.id,
      tipoMarca: "menor",
      ...dados,
    });

  return response.body.prova;
};

const criarResultado = async (dados = {}) => {
  return await request(app)
    .post("/resultados")
    .set("Authorization", `Bearer ${token}`)
    .send({
      marca: 10,
      ...dados,
    });
};

// RESULTADOS

describe("GET /resultados", () => {
  test("Deve retornar o status 200 e uma lista junto das propriedades corretas", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    await criarResultado({
      provaId: prova.id,
      equipeId: equipe.id,
      marca: 14.2,
    });

    const response = await request(app).get("/resultados");

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(Array.isArray(response.body)).toBeTruthy();

    const resultadoCriado = response.body.find(
      (r) => r.provaId === prova.id && r.equipeId === equipe.id
    );
    expect(resultadoCriado).toBeDefined();
    expect(resultadoCriado.marca).toBe(14.2);
  });
});

describe("POST /resultados", () => {
  test("Deve retornar 201 e criar o resultado com os dados corretos", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    const response = await criarResultado({
      provaId: prova.id,
      equipeId: equipe.id,
      marca: 14.2,
    });

    expect(response.status).toBe(201);
    expect(response.ok).toBeTruthy();
    expect(response.body.resultado).toHaveProperty("id");
    expect(response.body.resultado.marca).toBe(14.2);
  });

  test("Deve retornar 401 sem token", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    const response = await request(app)
      .post("/resultados")
      .send({ provaId: prova.id, equipeId: equipe.id, marca: 10 });

    expect(response.status).toBe(401);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 caso provaId não seja informado", async () => {
    const equipe = await gerarEquipe();

    const response = await criarResultado({
      provaId: undefined,
      equipeId: equipe.id,
      marca: 14.2,
    });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 caso equipeId não seja informado", async () => {
    const prova = await gerarProva();

    const response = await criarResultado({
      provaId: prova.id,
      equipeId: undefined,
      marca: 14.2,
    });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 caso marca não seja informada", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    const response = await criarResultado({
      provaId: prova.id,
      equipeId: equipe.id,
      marca: undefined,
    });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 404 quando a prova informada não existir", async () => {
    const equipe = await gerarEquipe();

    const response = await criarResultado({
      provaId: 9999,
      equipeId: equipe.id,
      marca: 14.2,
    });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 404 quando a equipe informada não existir", async () => {
    const prova = await gerarProva();

    const response = await criarResultado({
      provaId: prova.id,
      equipeId: 9999,
      marca: 14.2,
    });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 409 quando a equipe já tiver um resultado nessa prova", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    await criarResultado({ provaId: prova.id, equipeId: equipe.id, marca: 14.2 });

    const response = await criarResultado({
      provaId: prova.id,
      equipeId: equipe.id,
      marca: 15.0,
    });

    expect(response.status).toBe(409);
    expect(response.ok).toBeFalsy();
  });
});

describe("PUT /resultados/:id", () => {
  test("Deve atualizar o resultado e retornar 200", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    const resultado = await criarResultado({
      provaId: prova.id,
      equipeId: equipe.id,
      marca: 14.2,
    });

    const outraEquipe = await gerarEquipe();

    const response = await request(app)
      .put(`/resultados/${resultado.body.resultado.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        provaId: prova.id,
        equipeId: outraEquipe.id,
        marca: 10.2,
      });

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(response.body.resultado.marca).toBe(10.2);
    expect(response.body.resultado.equipeId).toBe(outraEquipe.id);
  });

  test("Deve retornar 404 caso o resultado não exista", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    const response = await request(app)
      .put("/resultados/9999")
      .set("Authorization", `Bearer ${token}`)
      .send({ provaId: prova.id, equipeId: equipe.id, marca: 10.2 });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 caso a marca não seja informada", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    const resultado = await criarResultado({
      provaId: prova.id,
      equipeId: equipe.id,
      marca: 14.2,
    });

    const response = await request(app)
      .put(`/resultados/${resultado.body.resultado.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ provaId: prova.id, equipeId: equipe.id });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });
});

describe("PATCH /resultados/:id", () => {
  test("Deve atualizar somente um campo e retornar 200", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    const resultado = await criarResultado({
      provaId: prova.id,
      equipeId: equipe.id,
      marca: 14.2,
    });

    const response = await request(app)
      .patch(`/resultados/${resultado.body.resultado.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ marca: 11.5 });

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(response.body.resultado.marca).toBe(11.5);
  });

  test("Deve retornar 400 quando nenhum campo for enviado", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    const resultado = await criarResultado({
      provaId: prova.id,
      equipeId: equipe.id,
      marca: 14.2,
    });

    const response = await request(app)
      .patch(`/resultados/${resultado.body.resultado.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({});

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 404 caso o resultado não exista", async () => {
    const response = await request(app)
      .patch("/resultados/9999")
      .set("Authorization", `Bearer ${token}`)
      .send({ marca: 11.5 });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });
});

describe("DELETE /resultados/:id", () => {
  test("Deve retornar o status 200", async () => {
    const equipe = await gerarEquipe();
    const prova = await gerarProva();

    const resultado = await criarResultado({
      provaId: prova.id,
      equipeId: equipe.id,
      marca: 14.2,
    });

    const response = await request(app)
      .delete(`/resultados/${resultado.body.resultado.id}`)
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
  });

  test("Deve retornar 404 caso o resultado não exista", async () => {
    const response = await request(app)
      .delete("/resultados/9999")
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });
});
