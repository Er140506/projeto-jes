import { describe, test, expect } from "vitest";
import { calcularClassificacao } from "../src/service/standingsService.js";

describe("calcularClassificacao", () => {
  test("Deve criar uma classificação zerada para todas as equipes", () => {
    const equipes = [{ id: 1 }, { id: 2 }];

    const resultado = calcularClassificacao(equipes, [], 10);

    expect(resultado).toHaveLength(2);
    expect(resultado[0]).toMatchObject({
      timeId: expect.any(Number),
      jogos: 0,
      vitorias: 0,
      empates: 0,
      derrotas: 0,
      pontosPro: 0,
      pontosContra: 0,
      pontos: 0,
    });
  });

  test("Deve dar 3 pontos para a equipe vencedora", () => {
    const equipes = [{ id: 1 }, { id: 2 }];
    const partidas = [
      {
        modalidadeId: 10,
        status: "finalizado",
        timeAId: 1,
        timeBId: 2,
        placarA: 3,
        placarB: 1,
      },
    ];

    const resultado = calcularClassificacao(equipes, partidas, 10);
    const equipe1 = resultado.find((equipe) => equipe.timeId === 1);
    const equipe2 = resultado.find((equipe) => equipe.timeId === 2);

    expect(equipe1).toMatchObject({ jogos: 1, vitorias: 1, pontos: 3 });
    expect(equipe2).toMatchObject({ jogos: 1, derrotas: 1, pontos: 0 });
  });

  test("Deve dar 1 ponto para cada equipe em caso de empate", () => {
    const equipes = [{ id: 1 }, { id: 2 }];
    const partidas = [
      {
        modalidadeId: 10,
        status: "finalizado",
        timeAId: 1,
        timeBId: 2,
        placarA: 2,
        placarB: 2,
      },
    ];

    const resultado = calcularClassificacao(equipes, partidas, 10);

    expect(resultado.find((equipe) => equipe.timeId === 1)).toMatchObject({
      jogos: 1,
      empates: 1,
      pontos: 1,
    });
    expect(resultado.find((equipe) => equipe.timeId === 2)).toMatchObject({
      jogos: 1,
      empates: 1,
      pontos: 1,
    });
  });

  test("Deve calcular pontos pró e pontos contra", () => {
    const equipes = [{ id: 1 }, { id: 2 }];
    const partidas = [
      {
        modalidadeId: 10,
        status: "finalizado",
        timeAId: 1,
        timeBId: 2,
        placarA: 5,
        placarB: 2,
      },
    ];

    const resultado = calcularClassificacao(equipes, partidas, 10);
    const equipe1 = resultado.find((equipe) => equipe.timeId === 1);
    const equipe2 = resultado.find((equipe) => equipe.timeId === 2);

    expect(equipe1.pontosPro).toBe(5);
    expect(equipe1.pontosContra).toBe(2);
    expect(equipe2.pontosPro).toBe(2);
    expect(equipe2.pontosContra).toBe(5);
  });

  test("Deve ignorar partidas de outra modalidade", () => {
    const equipes = [{ id: 1 }, { id: 2 }];
    const partidas = [
      {
        modalidadeId: 99,
        status: "finalizado",
        timeAId: 1,
        timeBId: 2,
        placarA: 5,
        placarB: 0,
      },
    ];

    const resultado = calcularClassificacao(equipes, partidas, 10);

    expect(resultado.find((equipe) => equipe.timeId === 1).jogos).toBe(0);
    expect(resultado.find((equipe) => equipe.timeId === 2).jogos).toBe(0);
  });

  test("Deve ignorar partidas que ainda não foram finalizadas", () => {
    const equipes = [{ id: 1 }, { id: 2 }];
    const partidas = [
      {
        modalidadeId: 10,
        status: "agendado",
        timeAId: 1,
        timeBId: 2,
        placarA: 5,
        placarB: 0,
      },
    ];

    const resultado = calcularClassificacao(equipes, partidas, 10);

    expect(resultado.find((equipe) => equipe.timeId === 1).jogos).toBe(0);
    expect(resultado.find((equipe) => equipe.timeId === 2).jogos).toBe(0);
  });

  test("Deve ordenar a classificação primeiro por pontos", () => {
    const equipes = [{ id: 1 }, { id: 2 }, { id: 3 }];
    const partidas = [
      {
        modalidadeId: 10,
        status: "finalizado",
        timeAId: 1,
        timeBId: 2,
        placarA: 3,
        placarB: 0,
      },
      {
        modalidadeId: 10,
        status: "finalizado",
        timeAId: 2,
        timeBId: 3,
        placarA: 1,
        placarB: 0,
      },
    ];

    const resultado = calcularClassificacao(equipes, partidas, 10);

    expect(resultado.map((equipe) => equipe.timeId)).toEqual([1, 2, 3]);
  });

  test("Deve usar saldo como primeiro desempate quando os pontos forem iguais", () => {
    const equipes = [{ id: 1 }, { id: 2 }, { id: 3 }];
    const partidas = [
      {
        modalidadeId: 10,
        status: "finalizado",
        timeAId: 1,
        timeBId: 3,
        placarA: 5,
        placarB: 0,
      },
      {
        modalidadeId: 10,
        status: "finalizado",
        timeAId: 2,
        timeBId: 3,
        placarA: 2,
        placarB: 0,
      },
    ];

    const resultado = calcularClassificacao(equipes, partidas, 10);

    expect(resultado[0].timeId).toBe(1);
    expect(resultado[1].timeId).toBe(2);
  });
});
