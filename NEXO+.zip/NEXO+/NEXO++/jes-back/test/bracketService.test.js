import { describe, test, expect } from "vitest";
import {
  gerarPontosCorridos,
  gerarEliminatoria,
  propagarVencedor,
} from "../src/service/bracketService.js";

describe("gerarPontosCorridos", () => {
  test("Deve retornar uma lista vazia quando houver menos de duas equipes", () => {
    expect(gerarPontosCorridos([], 1)).toEqual([]);
    expect(gerarPontosCorridos([{ id: 1 }], 1)).toEqual([]);
  });

  test("Deve gerar todas as partidas de um campeonato com número par de equipes", () => {
    const equipes = [
      { id: 1 },
      { id: 2 },
      { id: 3 },
      { id: 4 },
    ];

    const partidas = gerarPontosCorridos(equipes, 10);

    expect(partidas).toHaveLength(6);
    expect(partidas.every((partida) => partida.modalidadeId === 10)).toBeTruthy();
    expect(partidas.every((partida) => partida.formato === "pontoscorridos")).toBeTruthy();
    expect(partidas.every((partida) => partida.status === "agendado")).toBeTruthy();
  });

  test("Deve gerar o número correto de partidas quando houver número ímpar de equipes", () => {
    const equipes = [
      { id: 1 },
      { id: 2 },
      { id: 3 },
      { id: 4 },
      { id: 5 },
    ];

    const partidas = gerarPontosCorridos(equipes, 20);

    expect(partidas).toHaveLength(10);
    expect(partidas.every((partida) => partida.modalidadeId === 20)).toBeTruthy();
  });
});

describe("gerarEliminatoria", () => {
  test("Deve retornar uma lista vazia quando houver menos de duas equipes", () => {
    expect(gerarEliminatoria([], 1)).toEqual([]);
    expect(gerarEliminatoria([{ id: 1 }], 1)).toEqual([]);
  });

  test("Deve gerar uma chave completa para quatro equipes", () => {
    const equipes = [
      { id: 1 },
      { id: 2 },
      { id: 3 },
      { id: 4 },
    ];

    const partidas = gerarEliminatoria(equipes, 30);

    expect(partidas).toHaveLength(3);
    expect(partidas.filter((partida) => partida.rodada === 1)).toHaveLength(2);
    expect(partidas.filter((partida) => partida.rodada === 2)).toHaveLength(1);
    expect(partidas.every((partida) => partida.formato === "eliminatoria")).toBeTruthy();
    expect(partidas.every((partida) => partida.modalidadeId === 30)).toBeTruthy();
  });

  test("Deve criar partidas com os nomes das fases corretos", () => {
    const equipes = [
      { id: 1 },
      { id: 2 },
      { id: 3 },
      { id: 4 },
      { id: 5 },
      { id: 6 },
      { id: 7 },
      { id: 8 },
    ];

    const partidas = gerarEliminatoria(equipes, 30);
    const fases = new Set(partidas.map((partida) => partida.faseNome));

    expect(fases).toEqual(new Set(["Quartas de Final", "Semifinal", "Final"]));
  });

  test("Deve preencher as vagas da primeira rodada com as equipes disponíveis", () => {
    const equipes = [{ id: 1 }, { id: 2 }, { id: 3 }];

    const partidas = gerarEliminatoria(equipes, 30);
    const primeiraRodada = partidas.filter((partida) => partida.rodada === 1);

    expect(primeiraRodada.some((partida) => partida.timeAId === 1 || partida.timeBId === 1)).toBeTruthy();
    expect(primeiraRodada.some((partida) => partida.status === "bye")).toBeTruthy();
  });
});

describe("propagarVencedor", () => {
  test("Deve retornar as partidas sem alteração quando a partida não existir", () => {
    const partidas = [
      { id: 1, status: "finalizado", placarA: 2, placarB: 0, timeAId: 10, timeBId: 20 },
    ];

    expect(propagarVencedor(partidas, 999)).toEqual(partidas);
  });

  test("Deve retornar as partidas sem alteração quando a partida não estiver finalizada", () => {
    const partidas = [
      {
        id: 1,
        status: "agendado",
        placarA: 2,
        placarB: 0,
        timeAId: 10,
        timeBId: 20,
        proximaPartidaId: 2,
        proximaPartidaVaga: "A",
      },
      { id: 2, status: "agendado", timeAId: null, timeBId: 30 },
    ];

    expect(propagarVencedor(partidas, 1)).toEqual(partidas);
  });

  test("Deve propagar o vencedor para a vaga A da próxima partida", () => {
    const partidas = [
      {
        id: 1,
        status: "finalizado",
        placarA: 3,
        placarB: 1,
        timeAId: 10,
        timeBId: 20,
        proximaPartidaId: 2,
        proximaPartidaVaga: "A",
      },
      { id: 2, status: "agendado", timeAId: null, timeBId: 30 },
    ];

    const resultado = propagarVencedor(partidas, 1);

    expect(resultado.find((partida) => partida.id === 2).timeAId).toBe(10);
  });

  test("Deve propagar o vencedor para a vaga B da próxima partida", () => {
    const partidas = [
      {
        id: 1,
        status: "finalizado",
        placarA: 1,
        placarB: 2,
        timeAId: 10,
        timeBId: 20,
        proximaPartidaId: 2,
        proximaPartidaVaga: "B",
      },
      { id: 2, status: "agendado", timeAId: 30, timeBId: null },
    ];

    const resultado = propagarVencedor(partidas, 1);

    expect(resultado.find((partida) => partida.id === 2).timeBId).toBe(20);
  });

  test("Não deve propagar o vencedor quando houver empate", () => {
    const partidas = [
      {
        id: 1,
        status: "finalizado",
        placarA: 2,
        placarB: 2,
        timeAId: 10,
        timeBId: 20,
        proximaPartidaId: 2,
        proximaPartidaVaga: "A",
      },
      { id: 2, status: "agendado", timeAId: null, timeBId: 30 },
    ];

    const resultado = propagarVencedor(partidas, 1);

    expect(resultado.find((partida) => partida.id === 2).timeAId).toBeNull();
  });
});
