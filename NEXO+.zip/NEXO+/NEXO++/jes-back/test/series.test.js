import { describe, test, expect, beforeAll } from "vitest";
import app from "../src/app.js";
import request from "supertest";
import { conexao } from "../src/config/conexao.js";

let token;

beforeAll(async () => {
  await conexao.sync({ force: true });

  const usuario = await request(app)
    .post("/auth/registrar")
    .send({
      nome: "Professor Teste",
      email: `professor${Date.now()}@email.com`,
      senha: "123456789",
      codigoProfessor: process.env.CODIGO_PROFESSOR,
    });

  expect(usuario.status).toBe(201);

  token = usuario.body.token;
});

const criarSerie = async (dados = {}) => {
  return await request(app)
    .post("/series")
    .set("Authorization", `Bearer ${token}`)
    .send({
      nome: `Série ${Date.now()}${Math.random()}`,
      nivel: "Intermediário",
      pais: "Brasil",
      corPrimaria: "#000000",
      corSecundaria: "#FFFFFF",
      ...dados,
    });
};


// SERIES

describe("GET /series", () => {

  test("Deve retornar o status 200 e uma lista de séries", async () => {
    await criarSerie();

    const response = await request(app)
      .get("/series");

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();
    expect(Array.isArray(response.body)).toBeTruthy();
  });

  test("Deve retornar as séries cadastradas", async () => {
    const serie = await criarSerie({
      nome: "Série Para Listagem",
    });

    const response = await request(app)
      .get("/series");

    expect(response.status).toBe(200);
    expect(response.body).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          id: serie.body.serie.id,
          nome: "Série Para Listagem",
          nivel: "Intermediário",
          pais: "Brasil",
          corPrimaria: "#000000",
          corSecundaria: "#FFFFFF",
        }),
      ])
    );
  });

});


describe("POST /series", () => {

  test("Deve retornar o status 201 e criar uma série", async () => {
    const response = await criarSerie({
      nome: "Série A",
    });

    expect(response.status).toBe(201);
    expect(response.ok).toBeTruthy();

    expect(response.body).toHaveProperty("msg");
    expect(response.body).toHaveProperty("serie");

    expect(response.body.serie).toHaveProperty("id");
    expect(response.body.serie.nome).toBe("Série A");
    expect(response.body.serie.nivel).toBe("Intermediário");
    expect(response.body.serie.pais).toBe("Brasil");
    expect(response.body.serie.corPrimaria).toBe("#000000");
    expect(response.body.serie.corSecundaria).toBe("#FFFFFF");
  });

  test("Deve retornar 401 sem token", async () => {
    const response = await request(app)
      .post("/series")
      .send({
        nome: "Série sem token",
        nivel: "Intermediário",
        pais: "Brasil",
      });

    expect(response.status).toBe(401);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 sem nome", async () => {
    const response = await request(app)
      .post("/series")
      .set("Authorization", `Bearer ${token}`)
      .send({
        nivel: "Intermediário",
        pais: "Brasil",
      });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando o nome estiver vazio", async () => {
    const response = await request(app)
      .post("/series")
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: "",
        nivel: "Intermediário",
        pais: "Brasil",
      });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando o nome tiver menos de 2 caracteres", async () => {
    const response = await criarSerie({
      nome: "A",
    });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 409 quando o nome da série já existir", async () => {
    const nome = "Série Duplicada";

    await criarSerie({
      nome,
    });

    const response = await criarSerie({
      nome,
    });

    expect(response.status).toBe(409);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando a cor primária for inválida", async () => {
    const response = await criarSerie({
      nome: "Série Cor Primária",
      corPrimaria: "cor-invalida",
    });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando a cor secundária for inválida", async () => {
    const response = await criarSerie({
      nome: "Série Cor Secundária",
      corSecundaria: "cor-invalida",
    });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve aceitar uma cor hexadecimal válida", async () => {
    const response = await criarSerie({
      nome: "Série Cor Válida",
      corPrimaria: "#FF0000",
      corSecundaria: "#00FF00",
    });

    expect(response.status).toBe(201);
    expect(response.body.serie.corPrimaria).toBe("#FF0000");
    expect(response.body.serie.corSecundaria).toBe("#00FF00");
  });

});


describe("PUT /series/:id", () => {

  test("Deve atualizar uma série", async () => {
    const serie = await criarSerie({
      nome: "Série Antes",
    });

    const response = await request(app)
      .put(`/series/${serie.body.serie.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: "Série Atualizada",
        nivel: "Avançado",
        pais: "Brasil",
        corPrimaria: "#111111",
        corSecundaria: "#222222",
      });

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();

    expect(response.body).toHaveProperty("msg");
    expect(response.body).toHaveProperty("serie");

    expect(response.body.serie.nome).toBe("Série Atualizada");
    expect(response.body.serie.nivel).toBe("Avançado");
    expect(response.body.serie.pais).toBe("Brasil");
    expect(response.body.serie.corPrimaria).toBe("#111111");
    expect(response.body.serie.corSecundaria).toBe("#222222");
  });

  test("Deve retornar 401 sem token", async () => {
    const serie = await criarSerie();

    const response = await request(app)
      .put(`/series/${serie.body.serie.id}`)
      .send({
        nome: "Série Atualizada",
      });

    expect(response.status).toBe(401);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando o ID for inválido", async () => {
    const response = await request(app)
      .put("/series/abc")
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: "Série Atualizada",
      });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 404 quando a série não existir", async () => {
    const response = await request(app)
      .put("/series/999999")
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: "Série Inexistente",
      });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando o nome não for informado", async () => {
    const serie = await criarSerie();

    const response = await request(app)
      .put(`/series/${serie.body.serie.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        nivel: "Avançado",
        pais: "Brasil",
      });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

});


describe("PATCH /series/:id", () => {

  test("Deve atualizar somente o campo enviado", async () => {
    const serie = await criarSerie({
      nome: "Série Original",
      nivel: "Intermediário",
      pais: "Brasil",
    });

    const response = await request(app)
      .patch(`/series/${serie.body.serie.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: "Série Alterada",
      });

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();

    expect(response.body.serie.nome).toBe("Série Alterada");
    expect(response.body.serie.nivel).toBe("Intermediário");
    expect(response.body.serie.pais).toBe("Brasil");
  });

  test("Deve atualizar o nível da série", async () => {
    const serie = await criarSerie({
      nome: "Série Nível",
      nivel: "Iniciante",
    });

    const response = await request(app)
      .patch(`/series/${serie.body.serie.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        nivel: "Avançado",
      });

    expect(response.status).toBe(200);
    expect(response.body.serie.nivel).toBe("Avançado");
  });

  test("Deve retornar 401 sem token", async () => {
    const serie = await criarSerie();

    const response = await request(app)
      .patch(`/series/${serie.body.serie.id}`)
      .send({
        nome: "Série Alterada",
      });

    expect(response.status).toBe(401);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando o ID for inválido", async () => {
    const response = await request(app)
      .patch("/series/abc")
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: "Série Alterada",
      });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 404 quando a série não existir", async () => {
    const response = await request(app)
      .patch("/series/999999")
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: "Série Inexistente",
      });

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando nenhum campo for enviado", async () => {
    const serie = await criarSerie();

    const response = await request(app)
      .patch(`/series/${serie.body.serie.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({});

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando nenhum campo permitido for enviado", async () => {
    const serie = await criarSerie();

    const response = await request(app)
      .patch(`/series/${serie.body.serie.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        id: 999,
        campoInvalido: "teste",
      });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando o nome enviado no PATCH estiver vazio", async () => {
    const serie = await criarSerie();

    const response = await request(app)
      .patch(`/series/${serie.body.serie.id}`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        nome: "",
      });

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

});


describe("DELETE /series/:id", () => {

  test("Deve deletar uma série", async () => {
    const serie = await criarSerie({
      nome: "Série Para Deletar",
    });

    const response = await request(app)
      .delete(`/series/${serie.body.serie.id}`)
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(200);
    expect(response.ok).toBeTruthy();

    expect(response.body).toEqual({
      msg: "Série deletada com sucesso!",
    });
  });

  test("Deve retornar 401 sem token", async () => {
    const serie = await criarSerie();

    const response = await request(app)
      .delete(`/series/${serie.body.serie.id}`);

    expect(response.status).toBe(401);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 400 quando o ID for inválido", async () => {
    const response = await request(app)
      .delete("/series/abc")
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(400);
    expect(response.ok).toBeFalsy();
  });

  test("Deve retornar 404 quando a série não existir", async () => {
    const response = await request(app)
      .delete("/series/999999")
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(404);
    expect(response.ok).toBeFalsy();
  });

});