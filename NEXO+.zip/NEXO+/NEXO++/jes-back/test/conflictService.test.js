import { describe, test, expect } from "vitest";
import { paraMinutos, verificarConflito } from "../src/service/conflictService.js";

describe("paraMinutos", () => {
  test("Deve converter uma hora para minutos", () => {
    expect(paraMinutos("08:30")).toBe(510);
    expect(paraMinutos("12:00")).toBe(720);
    expect(paraMinutos("23:45")).toBe(1425);
  });
});

describe("verificarConflito", () => {
  test("Deve retornar null quando não existir partida no mesmo local e horário", () => {
    const partidas = [
      { id: 1, data: "2026-08-23", local: "Quadra 1", hora: "10:00", duracao: 30 },
    ];

    const candidata = {
      id: 2,
      data: "2026-08-23",
      local: "Quadra 1",
      hora: "11:00",
      duracao: 30,
    };

    expect(verificarConflito(partidas, candidata)).toBeNull();
  });

  test("Deve encontrar conflito quando os horários se sobrepõem", () => {
    const partida = {
      id: 1,
      data: "2026-08-23",
      local: "Quadra 1",
      hora: "10:00",
      duracao: 60,
    };

    const candidata = {
      id: 2,
      data: "2026-08-23",
      local: "Quadra 1",
      hora: "10:30",
      duracao: 30,
    };

    expect(verificarConflito([partida], candidata)).toEqual(partida);
  });

  test("Não deve considerar conflito quando a data for diferente", () => {
    const partida = {
      id: 1,
      data: "2026-08-23",
      local: "Quadra 1",
      hora: "10:00",
      duracao: 60,
    };

    const candidata = {
      id: 2,
      data: "2026-08-24",
      local: "Quadra 1",
      hora: "10:30",
      duracao: 30,
    };

    expect(verificarConflito([partida], candidata)).toBeNull();
  });

  test("Não deve considerar conflito quando o local for diferente", () => {
    const partida = {
      id: 1,
      data: "2026-08-23",
      local: "Quadra 1",
      hora: "10:00",
      duracao: 60,
    };

    const candidata = {
      id: 2,
      data: "2026-08-23",
      local: "Quadra 2",
      hora: "10:30",
      duracao: 30,
    };

    expect(verificarConflito([partida], candidata)).toBeNull();
  });

  test("Não deve considerar conflito com a própria partida durante uma edição", () => {
    const partida = {
      id: 1,
      data: "2026-08-23",
      local: "Quadra 1",
      hora: "10:00",
      duracao: 60,
    };

    expect(verificarConflito([partida], partida)).toBeNull();
  });

  test("Deve usar 30 minutos quando a duração não for informada", () => {
    const partida = {
      id: 1,
      data: "2026-08-23",
      local: "Quadra 1",
      hora: "10:00",
    };

    const candidata = {
      id: 2,
      data: "2026-08-23",
      local: "Quadra 1",
      hora: "10:20",
    };

    expect(verificarConflito([partida], candidata)).toEqual(partida);
  });
});
