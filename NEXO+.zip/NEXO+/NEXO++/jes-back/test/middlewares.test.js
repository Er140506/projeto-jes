import { describe, test, expect, vi } from "vitest";
import jwt from "jsonwebtoken";
import { authMiddleware } from "../src/middlewares/authMiddleware.js";
import { permitirProfessor } from "../src/middlewares/permitirProfessor.js";
import asyncHandler from "../src/utils/asyncHandler.js";

process.env.JWT_SECRET = process.env.JWT_SECRET || "segredo-teste";

describe("authMiddleware", () => {
  test("Deve retornar 401 quando o token não for informado", () => {
    const request = { headers: {} };
    const response = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn(),
    };
    const next = vi.fn();

    authMiddleware(request, response, next);

    expect(response.status).toHaveBeenCalledWith(401);
    expect(response.json).toHaveBeenCalledWith({ msg: "Token não informado" });
    expect(next).not.toHaveBeenCalled();
  });

  test("Deve retornar 401 quando o token for inválido", () => {
    const request = {
      headers: {
        authorization: "Bearer token-invalido",
      },
    };
    const response = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn(),
    };
    const next = vi.fn();

    authMiddleware(request, response, next);

    expect(response.status).toHaveBeenCalledWith(401);
    expect(response.json).toHaveBeenCalledWith({ msg: "Token inválido ou expirado" });
    expect(next).not.toHaveBeenCalled();
  });

  test("Deve permitir o acesso quando o token for válido", () => {
    const token = jwt.sign(
      { id: 10, email: "professor@email.com", tipo: "professor" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    const request = {
      headers: {
        authorization: `Bearer ${token}`,
      },
    };
    const response = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn(),
    };
    const next = vi.fn();

    authMiddleware(request, response, next);

    expect(next).toHaveBeenCalledTimes(1);
    expect(request.usuario).toMatchObject({
      id: 10,
      email: "professor@email.com",
      tipo: "professor",
    });
  });
});

describe("permitirProfessor", () => {
  test("Deve retornar 401 quando não houver usuário no request", () => {
    const request = {};
    const response = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn(),
    };
    const next = vi.fn();

    permitirProfessor(request, response, next);

    expect(response.status).toHaveBeenCalledWith(401);
    expect(response.json).toHaveBeenCalledWith({ msg: "Token não informado" });
    expect(next).not.toHaveBeenCalled();
  });

  test("Deve retornar 403 quando o usuário não for professor", () => {
    const request = {
      usuario: {
        id: 1,
        tipo: "aluno",
      },
    };
    const response = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn(),
    };
    const next = vi.fn();

    permitirProfessor(request, response, next);

    expect(response.status).toHaveBeenCalledWith(403);
    expect(response.json).toHaveBeenCalledWith({
      msg: "Apenas professores podem acessar esse recurso",
    });
    expect(next).not.toHaveBeenCalled();
  });

  test("Deve permitir o acesso quando o usuário for professor", () => {
    const request = {
      usuario: {
        id: 1,
        tipo: "professor",
      },
    };
    const response = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn(),
    };
    const next = vi.fn();

    permitirProfessor(request, response, next);

    expect(next).toHaveBeenCalledTimes(1);
    expect(response.status).not.toHaveBeenCalled();
  });
});

describe("asyncHandler", () => {
  test("Deve executar o controller e não chamar next quando não houver erro", async () => {
    const controller = vi.fn(async () => {});
    const next = vi.fn();
    const handler = asyncHandler(controller);

    await handler({}, {}, next);

    expect(controller).toHaveBeenCalledTimes(1);
    expect(next).not.toHaveBeenCalled();
  });

  test("Deve encaminhar o erro do controller para next", async () => {
    const erro = new Error("Erro de teste");
    const controller = vi.fn(async () => {
      throw erro;
    });
    const next = vi.fn();
    const handler = asyncHandler(controller);

    handler({}, {}, next);
    await new Promise((resolve) => setImmediate(resolve));

    expect(next).toHaveBeenCalledWith(erro);
  });
});
