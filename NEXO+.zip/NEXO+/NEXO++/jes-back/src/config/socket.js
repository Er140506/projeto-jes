/**
 * src/config/socket.js
 * Configuração do Socket.io - responsável pelo "tempo real" da aplicação.
 *
 * O front (app do aluno) se conecta uma vez via WebSocket e fica escutando
 * eventos. Quando o professor atualiza um placar ou gera um chaveamento,
 * o servidor avisa todo mundo conectado na hora, sem precisar que o
 * cliente fique perguntando (polling) se algo mudou.
 */

import { Server } from "socket.io"

let io = null

// Cria e configura o servidor de sockets em cima do servidor HTTP existente.
// Deve ser chamado uma única vez, no server.js, ao subir a aplicação.
export const initSocket = (httpServer) => {
    io = new Server(httpServer, {
        cors: {
            origin: "*",
            methods: ["GET", "POST", "PUT", "DELETE"]
        }
    })

    io.on("connection", (socket) => {
        console.log("Cliente conectado ao tempo real:", socket.id)

        // Permite que o front "assine" só os jogos de uma modalidade específica,
        // pra não receber eventos de partidas que não interessam pra ele.
        // Uso no front: socket.emit("entrarNaModalidade", modalidadeId)
        socket.on("entrarNaModalidade", (modalidadeId) => {
            socket.join(`modalidade_${modalidadeId}`)
        })

        socket.on("sairDaModalidade", (modalidadeId) => {
            socket.leave(`modalidade_${modalidadeId}`)
        })

        socket.on("disconnect", () => {
            console.log("Cliente desconectado do tempo real:", socket.id)
        })
    })

    return io
}

// Devolve a instância ativa do socket, pra ser usada dentro dos controllers.
export const getIO = () => io

// Helper seguro pra emitir eventos: se o socket ainda não foi inicializado
// (ex: rodando os testes automatizados, que usam só o app.js sem subir o
// servidor de verdade), simplesmente não faz nada em vez de quebrar a rota.
export const emitirEvento = (evento, dados, sala = null) => {
    if (!io) return

    if (sala) {
        io.to(sala).emit(evento, dados)
    } else {
        io.emit(evento, dados)
    }
}
