/**
 * src/controllers/partidasControllers.js
 * CRUD de partidas.
 */

import { partidasModel } from "../model/index.js"
import { tratarErro } from "../utils/erroHandler.js"
import { propagarVencedor } from "../service/bracketService.js"
import { verificarConflito } from "../service/conflictService.js"
import { emitirEvento } from "../config/socket.js"

// Campos que o cliente tem permissão de alterar via PUT.
// Evita que o body sobrescreva colunas internas do chaveamento (proximaPartidaId, etc).
const CAMPOS_PERMITIDOS = [
    "modalidadeId", "formato", "rodada", "faseNome", "slot",
    "timeAId", "timeBId", "placarA", "placarB", "status", "data", "hora",
    "local", "duracao", "iniciadaEm", "proximaPartidaId", "proximaPartidaVaga"
]

// GET /partidas - Lista todas as partidas
export const listarPartidas = async (request, response) => {
    try {
        const partidas = await partidasModel.findAll()
        response.status(200).json(partidas)
    } catch (error) {
        await tratarErro(error, response)
    }
}

// POST /partidas - Cria uma partida
export const cadastrarPartidas = async (request, response) => {
    try {
        const dadosPartida = {}
        for (const campo of CAMPOS_PERMITIDOS) {
            if (request.body[campo] !== undefined) {
                dadosPartida[campo] = request.body[campo]
            }
        }

        // NEXO+ não permite empate (ver mesma checagem em atualizarPartida)
        if (
            dadosPartida.status === "finalizado" &&
            dadosPartida.placarA != null &&
            dadosPartida.placarB != null &&
            Number(dadosPartida.placarA) === Number(dadosPartida.placarB)
        ) {
            return response.status(400).json({
                message: "Empate não é permitido: ajuste o placar até haver um vencedor antes de encerrar a partida."
            })
        }

        // Só faz sentido checar conflito de horário se data, hora e local foram informados
        if (dadosPartida.data && dadosPartida.hora && dadosPartida.local) {
            const partidasDoDia = await partidasModel.findAll({
                where: { data: dadosPartida.data, local: dadosPartida.local }
            })

            const conflito = verificarConflito(
                partidasDoDia.map((p) => p.get({ plain: true })),
                { id: null, ...dadosPartida }
            )

            if (conflito) {
                return response.status(409).json({
                    message: `Conflito de horário: já existe a partida #${conflito.id} nesse local e horário`
                })
            }
        }

        const novaPartida = await partidasModel.create(dadosPartida)

        // Avisa em tempo real quem estiver acompanhando essa modalidade
        emitirEvento("partida:criada", novaPartida, `modalidade_${novaPartida.modalidadeId}`)

        response.status(201).json({ message: "Partida Criada", partida: novaPartida })
    } catch (error) {
        await tratarErro(error, response)
    }
}

// GET /partidas/:id - Busca uma partida pelo ID
export const buscarPartidaPorId = async (request, response) => {
    try {
        const partida = await partidasModel.findByPk(request.params.id)

        if (!partida) {
            response.status(404).json({ message: "Partida não encontrada" })
            return
        }

        response.status(200).json(partida)
    } catch (error) {
        await tratarErro(error, response)
    }
}

// PUT /partidas/:id - Atualiza uma partida
export const atualizarPartida = async (request, response) => {
    try {
        const { id } = request.params
        const partida = await partidasModel.findByPk(id)

        if (!partida) {
            return response.status(404).json({ message: "Partida não encontrada" })
        }

        const dadosPartida = {}
        for (const campo of CAMPOS_PERMITIDOS) {
            if (request.body[campo] !== undefined) {
                dadosPartida[campo] = request.body[campo]
            }
        }

        // NEXO+ não permite empate: toda partida encerrada precisa ter um
        // vencedor (regra do produto). Usa os valores novos quando enviados,
        // senão os que a partida já tinha, pra cobrir tanto "só mudei o
        // status pra finalizado" quanto "só mudei o placar".
        const statusFinal = dadosPartida.status ?? partida.status
        const placarAFinal = dadosPartida.placarA ?? partida.placarA
        const placarBFinal = dadosPartida.placarB ?? partida.placarB

        if (
            statusFinal === "finalizado" &&
            placarAFinal != null &&
            placarBFinal != null &&
            Number(placarAFinal) === Number(placarBFinal)
        ) {
            return response.status(400).json({
                message: "Empate não é permitido: ajuste o placar até haver um vencedor antes de encerrar a partida."
            })
        }

        // Verifica conflito de horário (ignorando a própria partida), usando os
        // dados novos quando enviados, senão os dados que a partida já tinha
        const dataFinal = dadosPartida.data ?? partida.data
        const horaFinal = dadosPartida.hora ?? partida.hora
        const localFinal = dadosPartida.local ?? partida.local

        if (dataFinal && horaFinal && localFinal) {
            const partidasDoDia = await partidasModel.findAll({
                where: { data: dataFinal, local: localFinal }
            })

            const conflito = verificarConflito(
                partidasDoDia.map((p) => p.get({ plain: true })),
                {
                    id: partida.id,
                    data: dataFinal,
                    hora: horaFinal,
                    local: localFinal,
                    duracao: dadosPartida.duracao ?? partida.duracao
                }
            )

            if (conflito) {
                return response.status(409).json({
                    message: `Conflito de horário: já existe a partida #${conflito.id} nesse local e horário`
                })
            }
        }

        await partida.update(dadosPartida)

        // Avisa em tempo real: o placar/status dessa partida acabou de mudar.
        // É esse evento que faz o "acompanhamento em tempo real" existir de
        // verdade - o cliente recebe sem precisar ficar perguntando (polling).
        emitirEvento("partida:atualizada", partida, `modalidade_${partida.modalidadeId}`)

        // Se a partida acabou de ser finalizada com um vencedor definido,
        // propaga o time vencedor para a próxima fase do chaveamento
        if (
            partida.status === "finalizado" &&
            partida.placarA != null &&
            partida.placarB != null &&
            partida.placarA !== partida.placarB &&
            partida.proximaPartidaId
        ) {
            const todasPartidas = await partidasModel.findAll({
                where: { modalidadeId: partida.modalidadeId }
            })

            const atualizadas = propagarVencedor(
                todasPartidas.map((p) => p.get({ plain: true })),
                partida.id
            )

            const proxima = atualizadas.find((p) => p.id === partida.proximaPartidaId)
            if (proxima) {
                await partidasModel.update(
                    { timeAId: proxima.timeAId, timeBId: proxima.timeBId },
                    { where: { id: proxima.id } }
                )

                // A próxima partida do chaveamento também mudou (recebeu o
                // time vencedor), então avisa em tempo real também
                emitirEvento(
                    "partida:atualizada",
                    { id: proxima.id, timeAId: proxima.timeAId, timeBId: proxima.timeBId },
                    `modalidade_${partida.modalidadeId}`
                )
            }
        }

        response.status(200).json({
            message: "Partida atualizada com sucesso",
            partida
        })
    } catch (error) {
        await tratarErro(error, response)
    }
}

// DELETE /partidas/:id - Remove uma partida
export const deletarPartida = async (request, response) => {
    try {
        const { id } = request.params
        const partida = await partidasModel.findByPk(id)

        if (!partida) {
            return response.status(404).json({ message: "Partida não encontrada" })
        }

        await partida.destroy()

        emitirEvento("partida:deletada", { id: partida.id }, `modalidade_${partida.modalidadeId}`)

        response.status(200).json({ message: "Partida deletada com sucesso" })
    } catch (error) {
        await tratarErro(error, response)
    }
}