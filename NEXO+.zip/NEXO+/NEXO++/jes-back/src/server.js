import "./model/index.js"
import http from "http"
import app from "./app.js"
import { conexao } from "./config/conexao.js"
import { initSocket } from "./config/socket.js"

const PORT = process.env.PORT || 3000

const iniciarServidor = async () => {
    try {

        // await conexao.sync({force:true})
        await conexao.sync()

        // Cria um servidor HTTP "cru" a partir do app do Express, pra poder
        // anexar o Socket.io nele (o app.listen() do Express sozinho não
        // permite compartilhar a mesma porta com WebSocket).
        const httpServer = http.createServer(app)

        initSocket(httpServer)

        httpServer.listen(PORT, () => {
            console.log("Servidor iniciado na porta", PORT)
        })
    } catch (error) {
        console.log("Erro ao iniciar o servidor:", error.message)
    }
}

await iniciarServidor()
