# NEXO+ - Front-end

É a interface web responsável pelo acompanhamento dos Jogos Internos Estudantis. Ela oferece o cadastro e gerenciamento de modalidades, equipes, partidas, séries e provas (para o professor), além do acompanhamento de resultados, classificação e do Ranking Geral em tempo real (para o aluno e o professor).

O Front-end do NEXO+ consome os serviços disponibilizados pelo Back-end (`jes-back`) através de uma API HTTP e de uma conexão Socket.io para atualizações em tempo real.

## Principais Funções

### Acompanhamento (aluno e professor)

* Painel inicial com partidas ao vivo e resultados recentes
* Lista de modalidades, com detalhe de cada uma (classificação e chaveamento)
* Lista de equipes, filtrável por modalidade
* Classificação por modalidade (posição, jogos, vitórias, derrotas, pontos)
* Ranking Geral: soma os pontos da mesma turma (ex: "3D") entre todas as modalidades em que ela participa, mesmo sendo cadastros de equipe separados em cada uma
* Chaveamento (mata-mata) agrupado por rodada/fase, para modalidades no formato eliminatória

### Gestão (exclusiva para professor, autenticado)

* Cadastro, edição e geração de chaveamento de modalidades
* Cadastro, edição e exclusão de equipes
* Cadastro, edição, lançamento de placar e exclusão de partidas
* Cadastro, edição e exclusão de séries
* Cadastro, edição e exclusão de provas e de seus resultados (marcas), usados nas modalidades no formato "ranking"

### Regras de produto aplicadas na interface

* Sem empate: nenhuma partida pode ser encerrada com placares iguais - a interface bloqueia isso antes mesmo de chamar a API
* Mobile-first, com navegação por bottom-nav no celular e sidebar fixa em telas maiores (tablet/desktop)

### Autenticação

O sistema possui autenticação exclusiva para professores, consumindo o mesmo mecanismo de token JWT do Back-end:

* Cadastro de usuário (Professor), com código de professor
* Login
* Sessão persistida no navegador (`localStorage`)
* Logout automático com aviso quando o token expira ou é rejeitado pela API

O aluno não possui conta: acessa diretamente as informações públicas de acompanhamento, sem autenticação.

### Comunicação em tempo real

O Front-end se conecta ao mesmo servidor Socket.io do Back-end e entra nas salas de cada modalidade sendo visualizada (`entrarNaModalidade`/`sairDaModalidade`), recebendo os eventos `partida:criada`, `partida:atualizada`, `partida:deletada` e `chaveamento:gerado` para atualizar as telas de Partidas, Classificação e Ranking Geral sem precisar de atualização manual da página.

---

## Tecnologias Utilizadas

* Node.js 22+
* JavaScript (JSX)
* React 19.2
* Vite 6
* @vitejs/plugin-react 5.2
* lucide-react 1.43 (ícones)
* socket.io-client 4.8
* CSS puro, organizado por componente 

---

## Instalação

### Pré-requisitos

Antes de iniciar o projeto, é necessário ter os seguintes componentes instalados:

* Node.js
* npm
* Git
* O Back-end (`jes-back`) rodando e acessível (local ou remoto)

Após instalar os pré-requisitos, clone o projeto para sua máquina.

### 1° Clonar o projeto

Utilize:

```
git clone (link do projeto)
```

Depois, entre na pasta do projeto:

```
cd front-jes
```

### 2° Instalar as dependências

Instale as dependências utilizando:

```
npm install
```

ou:

```
npm i
```

Após concluir as configurações necessárias, execute:

```
npm run dev
```

O comando inicia o servidor de desenvolvimento do Vite.

Por padrão, a aplicação fica disponível em:

`http://localhost:5173`

---

## Configuração

O Front-end precisa saber o endereço onde o Back-end está rodando. Isso é feito através de uma variável de ambiente.

### `.env`

Crie um arquivo `.env` na raiz do projeto (pode copiar o `.env.example` já incluso) e configure a URL da API:

```env
VITE_API_URL=http://localhost:3000
```

### Descrição das variáveis

| Variável        | Função                                                    |
| --------------- | ---------------------------------------------------------- |
| `VITE_API_URL`  | Endereço base da API do Back-end (sem barra no final)     |

Sem essa variável configurada, o front assume `http://localhost:3000` como padrão.

**Não compartilhe o arquivo `.env` original e real**, caso ele contenha um endereço de API privado/interno.

---

## Como executar

Após a instalação das dependências, a configuração do `.env` e com o Back-end (`jes-back`) já rodando, execute:

```
npm run dev
```

Após iniciar, a aplicação estará disponível no endereço indicado pelo terminal.

Por exemplo:

`http://localhost:5173`

### Outros scripts

| Script            | Função                                              |
| ----------------- | ---------------------------------------------------- |
| `npm run dev`     | Inicia o servidor de desenvolvimento (com hot reload) |
| `npm run build`   | Gera a versão de produção na pasta `dist/`           |
| `npm run preview` | Serve localmente a versão gerada por `npm run build` |
| `npm run lint`    | Roda o oxlint sobre o código                         |

---

## Estrutura do Projeto

```
front-jes/
│
├── src/
│   ├── api/
│   │   ├── auth.js
│   │   ├── client.js
│   │   ├── equipes.js
│   │   ├── modalidades.js
│   │   ├── partidas.js
│   │   ├── provas.js
│   │   ├── resultados.js
│   │   ├── series.js
│   │   └── socket.js
│   │
│   ├── components/
│   │   ├── auth/
│   │   ├── bracket/
│   │   ├── common/
│   │   ├── dashboard/
│   │   ├── equipes/
│   │   ├── layout/
│   │   ├── modalidades/
│   │   ├── partidas/
│   │   ├── ranking/
│   │   ├── standings/
│   │   └── teacher/
│   │
│   ├── context/
│   │   ├── AuthContext.jsx
│   │   ├── EquipesContext.jsx
│   │   └── ModalidadesContext.jsx
│   │
│   ├── hooks/
│   │   ├── useApi.js
│   │   ├── useModalidadeRealtime.js
│   │   └── useModalidadesRealtime.js
│   │
│   ├── styles/
│   │   └── shared.css
│   │
│   ├── utils/
│   │   ├── format.js
│   │   ├── ranking.js
│   │   └── validation.js
│   │
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
│
├── public/
├── .env.example
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

### Organização das pastas

| Pasta        | Responsabilidade                                                        |
| ------------ | -------------------------------------------------------------------------- |
| `api`        | Toda a comunicação com o Back-end: uma função por rota, já normalizando os formatos de resposta da API (`msg`/`message`/`texto`, array puro/objeto envolvido) |
| `components` | Telas e componentes de interface, organizados por área (um `Componente.jsx` + `Componente.css` cada) |
| `context`    | Estado compartilhado entre telas: sessão do professor, lista de modalidades e de equipes |
| `hooks`      | Lógica reaproveitável: busca de dados (`useApi`) e inscrição em eventos de tempo real por modalidade |
| `styles`     | Estilos compartilhados entre vários componentes (cards, tabelas, badges, botões) |
| `utils`      | Funções auxiliares: formatação, validação (regra de "sem empate") e o cálculo do Ranking Geral |

---

## Integração com o Back-end

O Front-end do NEXO+ consome os serviços disponibilizados pelo Back-end (`jes-back`) através da API HTTP e do Socket.io.

A comunicação entre as duas partes permite que o Front-end realize o cadastro, consulta, atualização e exclusão dos dados, além de receber em tempo real as atualizações de partidas, resultados, equipes, modalidades e demais recursos do sistema.

A autenticação das operações do professor é feita com o token JWT emitido pelo Back-end no login/cadastro, enviado como `Authorization: Bearer <token>` nas rotas protegidas.

---
