import { useState } from "react"
import { AuthProvider, useAuth } from "./context/AuthContext.jsx"
import { ModalidadesProvider } from "./context/ModalidadesContext.jsx"
import { EquipesProvider } from "./context/EquipesContext.jsx"
import AuthScreen from "./components/auth/AuthScreen.jsx"
import Header from "./components/layout/Header.jsx"
import Sidebar from "./components/layout/Sidebar.jsx"
import BottomNav from "./components/layout/BottomNav.jsx"
import { SCREEN_TITLES } from "./components/layout/navConfig.js"
import Dashboard from "./components/dashboard/Dashboard.jsx"
import TeacherPanel from "./components/teacher/TeacherPanel.jsx"
import ManagementHub from "./components/teacher/ManagementHub.jsx"
import MatchesList from "./components/partidas/MatchesList.jsx"
import Standings from "./components/standings/Standings.jsx"
import RankingGeral from "./components/ranking/RankingGeral.jsx"
import ModalidadesList from "./components/modalidades/ModalidadesList.jsx"
import EquipesList from "./components/equipes/EquipesList.jsx"

/**
 * NEXO+ não usa uma lib de rotas - a navegação é só um estado de "tela
 * atual" (igual ao App.tsx do Design Aprimorado do Figma), o que combina
 * bem com o uso em quadra: sem URLs pra digitar, só toques grandes.
 */
function AppContent() {
  const { professor, sair } = useAuth()
  const [modoAluno, setModoAluno] = useState(false)
  const [screen, setScreen] = useState("home")

  const logado = professor || modoAluno
  const role = professor ? "professor" : "aluno"

  if (!logado) {
    return (
      <AuthScreen
        onEntrarComoAluno={() => setModoAluno(true)}
        onProfessorAutenticado={() => setScreen("home")}
      />
    )
  }

  function trocarPerfil() {
    if (professor) sair()
    setModoAluno(false)
    setScreen("home")
  }

  function renderScreen() {
    switch (screen) {
      case "home":
        return professor ? <TeacherPanel onGo={setScreen} /> : <Dashboard onGo={setScreen} />
      case "matches":
        return <MatchesList professor={professor} />
      case "standings":
        return <Standings />
      case "ranking":
        return <RankingGeral />
      case "teams":
        return <EquipesList professor={professor} />
      case "modalities":
        return <ModalidadesList professor={professor} />
      case "management":
        return professor ? <ManagementHub /> : null
      default:
        return null
    }
  }

  return (
    <div className="nexo-app">
      <Sidebar role={role} screen={screen} onGo={setScreen} onSwitchRole={trocarPerfil} />
      <div className="nexo-app-main">
        <Header subtitle={SCREEN_TITLES[screen]} role={role} onSwitchRole={trocarPerfil} />
        <main className="nexo-screen">{renderScreen()}</main>
        <BottomNav role={role} screen={screen} onGo={setScreen} />
      </div>
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <ModalidadesProvider>
        <EquipesProvider>
          <AppContent />
        </EquipesProvider>
      </ModalidadesProvider>
    </AuthProvider>
  )
}
