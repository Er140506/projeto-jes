import { useCallback, useEffect, useState } from "react"
import { classificacaoModalidade } from "../../api/modalidades.js"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { useModalidadeRealtime } from "../../hooks/useModalidadeRealtime.js"
import { useApi } from "../../hooks/useApi.js"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"

/**
 * Classificação por modalidade. A tabela NÃO mostra coluna de empates - o
 * NEXO+ não permite empate (item 15 do briefing), então esse campo (que o
 * back-end ainda calcula, sempre em zero) simplesmente não é exibido.
 */
export default function Standings() {
  const { modalidades, loading: carregandoModalidades } = useModalidades()
  const [modalidadeId, setModalidadeId] = useState(null)

  useEffect(() => {
    if (!modalidadeId && modalidades.length > 0) {
      const primeiraComPartidas = modalidades.find((m) => m.formato !== "ranking") || modalidades[0]
      setModalidadeId(primeiraComPartidas.id)
    }
  }, [modalidades, modalidadeId])

  const fetcher = useCallback(() => classificacaoModalidade(modalidadeId), [modalidadeId])
  const { data: tabela, loading, error, refetch } = useApi(fetcher, { skip: !modalidadeId })

  useModalidadeRealtime(modalidadeId, refetch)

  if (carregandoModalidades) return <LoadingState texto="Carregando modalidades..." />
  if (modalidades.length === 0) return <EmptyState icon="📋" texto="Nenhuma modalidade cadastrada ainda." />

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-filter-bar">
        {modalidades.map((m) => (
          <button
            key={m.id}
            className={`nexo-filter-chip ${modalidadeId === m.id ? "active" : ""}`}
            onClick={() => setModalidadeId(m.id)}
          >
            {m.emoji} {m.nome}
          </button>
        ))}
      </div>

      <div className="nexo-section" style={{ paddingTop: 0 }}>
        {loading && <LoadingState texto="Carregando classificação..." />}
        {error && <ErrorState mensagem={error} onRetry={refetch} />}

        {!loading && !error && tabela && (
          <>
            {tabela.length === 0 ? (
              <EmptyState icon="📋" texto="Nenhuma equipe cadastrada nesta modalidade." />
            ) : (
              <div className="nexo-card" style={{ padding: 0 }}>
                <div className="nexo-table-wrap">
                  <table className="nexo-table">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Equipe</th>
                        <th>J</th>
                        <th>V</th>
                        <th>D</th>
                        <th>Pts</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tabela.map((linha, i) => (
                        <tr key={linha.timeId}>
                          <td>
                            <span className={`nexo-table-rank ${i === 0 ? "top1" : i === 1 ? "top2" : i === 2 ? "top3" : ""}`}>
                              {i + 1}º
                            </span>
                          </td>
                          <td>
                            <span className="nexo-table-team">{linha.equipe?.nome || "—"}</span>
                          </td>
                          <td>{linha.jogos}</td>
                          <td>{linha.vitorias}</td>
                          <td>{linha.derrotas}</td>
                          <td>
                            <span className="nexo-table-pts">{linha.pontos}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
