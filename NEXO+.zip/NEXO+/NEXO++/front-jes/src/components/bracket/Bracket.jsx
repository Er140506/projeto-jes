import { useMemo } from "react"
import MatchCard from "../partidas/MatchCard.jsx"
import "./Bracket.css"

/**
 * Visualização do chaveamento (mata-mata) agrupada por rodada/fase.
 * Não recalcula nada - só organiza visualmente as partidas que o back-end
 * já gerou (src/service/bracketService.js), incluindo o link de
 * "próxima partida" pra dar noção de progressão entre fases.
 */
export default function Bracket({ partidas, professor, onEditarPartida }) {
  const rodadas = useMemo(() => {
    const grupos = new Map()
    partidas
      .filter((p) => p.formato === "eliminatoria")
      .forEach((p) => {
        const chave = p.rodada ?? 0
        if (!grupos.has(chave)) grupos.set(chave, [])
        grupos.get(chave).push(p)
      })
    return Array.from(grupos.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([rodada, lista]) => ({
        rodada,
        faseNome: lista[0]?.faseNome,
        partidas: lista.sort((a, b) => (a.slot ?? 0) - (b.slot ?? 0)),
      }))
  }, [partidas])

  if (rodadas.length === 0) return null

  return (
    <div className="bracket-scroll">
      {rodadas.map((grupo) => (
        <div className="bracket-column" key={grupo.rodada}>
          <div className="bracket-column-title">{grupo.faseNome || `Rodada ${grupo.rodada}`}</div>
          {grupo.partidas.map((partida) => (
            <div className="bracket-match" key={partida.id}>
              <MatchCard
                partida={partida}
                professor={professor}
                onClick={professor && partida.status !== "bye" ? () => onEditarPartida(partida) : undefined}
              />
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}
