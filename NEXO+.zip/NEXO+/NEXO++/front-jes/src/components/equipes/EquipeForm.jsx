import { useCallback, useState } from "react"
import Modal from "../common/Modal.jsx"
import FormField from "../common/FormField.jsx"
import FormError from "../common/FormError.jsx"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { useApi } from "../../hooks/useApi.js"
import { listarSeries } from "../../api/series.js"
import { criarEquipe, atualizarEquipe } from "../../api/equipes.js"

export default function EquipeForm({ equipe, onClose, onSalvo }) {
  const editando = !!equipe
  const { modalidades } = useModalidades()
  const seriesFetcher = useCallback(listarSeries, [])
  const { data: series } = useApi(seriesFetcher)

  const [modalidadeId, setModalidadeId] = useState(equipe?.modalidadeId || modalidades[0]?.id || "")
  const [nome, setNome] = useState(equipe?.nome || "")
  const [turma, setTurma] = useState(equipe?.turma || "")
  const [jogadores, setJogadores] = useState(equipe?.jogadores ?? 1)
  const [serieId, setSerieId] = useState(equipe?.serieId || "")
  const [erro, setErro] = useState(null)
  const [enviando, setEnviando] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setErro(null)
    setEnviando(true)

    const payload = {
      modalidadeId: Number(modalidadeId),
      nome,
      turma: turma || null,
      jogadores: Number(jogadores) || 1,
      serieId: serieId ? Number(serieId) : null,
    }

    try {
      if (editando) {
        await atualizarEquipe(equipe.id, payload)
      } else {
        await criarEquipe(payload)
      }
      onSalvo()
    } catch (err) {
      setErro(err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <Modal title={editando ? "Editar equipe" : "Nova equipe"} onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <FormError message={erro} />

        <FormField label="Modalidade">
          <select value={modalidadeId} onChange={(e) => setModalidadeId(e.target.value)} required>
            <option value="" disabled>Selecione</option>
            {modalidades.map((m) => (
              <option key={m.id} value={m.id}>{m.emoji} {m.nome}</option>
            ))}
          </select>
        </FormField>

        <FormField label="Nome da equipe">
          <input value={nome} onChange={(e) => setNome(e.target.value)} required placeholder="Ex: Turma 3D - Vôlei" />
        </FormField>

        <FormField
          label="Turma"
          hint="Identificação usada para somar pontos no Ranking Geral (ex: 3D)"
        >
          <input value={turma} onChange={(e) => setTurma(e.target.value)} maxLength={10} placeholder="Ex: 3D" />
        </FormField>

        <FormField label="Número de jogadores">
          <input type="number" min={1} max={15} value={jogadores} onChange={(e) => setJogadores(e.target.value)} />
        </FormField>

        {series && series.length > 0 && (
          <FormField label="Série" hint="Opcional">
            <select value={serieId} onChange={(e) => setSerieId(e.target.value)}>
              <option value="">Nenhuma</option>
              {series.map((s) => (
                <option key={s.id} value={s.id}>{s.nome}</option>
              ))}
            </select>
          </FormField>
        )}

        <button className="nexo-btn primary full" type="submit" disabled={enviando}>
          {enviando ? "Salvando..." : editando ? "Salvar alterações" : "Criar equipe"}
        </button>
      </form>
    </Modal>
  )
}
