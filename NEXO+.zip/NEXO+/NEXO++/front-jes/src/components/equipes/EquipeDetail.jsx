import { useState } from "react"
import { Pencil, Trash2 } from "lucide-react"
import Modal from "../common/Modal.jsx"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { deletarEquipe } from "../../api/equipes.js"
import { corDaEquipe, iniciaisDaEquipe, identidadeGeralDaEquipe } from "../../utils/format.js"
import EquipeForm from "./EquipeForm.jsx"
import "./Equipes.css"

export default function EquipeDetail({ equipe, professor, onClose, onAlterada }) {
  const { modalidadesPorId } = useModalidades()
  const [editando, setEditando] = useState(false)
  const [excluindo, setExcluindo] = useState(false)
  const [erro, setErro] = useState(null)

  const modalidade = modalidadesPorId.get(equipe.modalidadeId)

  async function excluir() {
    if (!window.confirm(`Excluir a equipe "${equipe.nome}"?`)) return
    setExcluindo(true)
    setErro(null)
    try {
      await deletarEquipe(equipe.id)
      onAlterada()
    } catch (err) {
      setErro(err.message)
      setExcluindo(false)
    }
  }

  if (editando) {
    return (
      <EquipeForm
        equipe={equipe}
        onClose={() => setEditando(false)}
        onSalvo={onAlterada}
      />
    )
  }

  return (
    <Modal title="Equipe" onClose={onClose}>
      <div className="equipe-detail-header">
        <div className="nexo-team-avatar" style={{ background: corDaEquipe(equipe.id), width: 64, height: 64, fontSize: 26 }}>
          {iniciaisDaEquipe(equipe.nome)}
        </div>
        <div>
          <h2 className="equipe-detail-nome">{equipe.nome}</h2>
          <span className="nexo-team-meta">{modalidade?.nome || "Modalidade removida"}</span>
        </div>
      </div>

      <div className="equipe-detail-info">
        <div>
          <span className="equipe-detail-label">Turma / identificação geral</span>
          <span className="equipe-detail-valor">{identidadeGeralDaEquipe(equipe)}</span>
        </div>
        <div>
          <span className="equipe-detail-label">Jogadores</span>
          <span className="equipe-detail-valor">{equipe.jogadores ?? "—"}</span>
        </div>
        {equipe.serie && (
          <div>
            <span className="equipe-detail-label">Série</span>
            <span className="equipe-detail-valor">{equipe.serie.nome}</span>
          </div>
        )}
      </div>

      {erro && <p className="modality-error">{erro}</p>}

      {professor && (
        <div className="equipe-detail-actions">
          <button className="nexo-btn ghost full" onClick={() => setEditando(true)}>
            <Pencil size={16} /> Editar
          </button>
          <button className="nexo-btn danger full" onClick={excluir} disabled={excluindo}>
            <Trash2 size={16} /> {excluindo ? "Excluindo..." : "Excluir"}
          </button>
        </div>
      )}
    </Modal>
  )
}
