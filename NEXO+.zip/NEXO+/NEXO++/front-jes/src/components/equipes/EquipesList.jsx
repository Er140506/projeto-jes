import { useMemo, useState } from "react"
import { Plus } from "lucide-react"
import { useEquipes } from "../../context/EquipesContext.jsx"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"
import { corDaEquipe, iniciaisDaEquipe } from "../../utils/format.js"
import EquipeDetail from "./EquipeDetail.jsx"
import EquipeForm from "./EquipeForm.jsx"
import "./Equipes.css"

export default function EquipesList({ professor }) {
  const { equipes, loading, error, refetchEquipes } = useEquipes()
  const { modalidades } = useModalidades()

  const [modalidadeFiltro, setModalidadeFiltro] = useState("todas")
  const [selecionada, setSelecionada] = useState(null)
  const [criando, setCriando] = useState(false)

  const modalidadesPorId = useMemo(() => new Map(modalidades.map((m) => [m.id, m])), [modalidades])

  const listaFiltrada = useMemo(() => {
    return equipes
      .filter((e) => modalidadeFiltro === "todas" || e.modalidadeId === Number(modalidadeFiltro))
      .sort((a, b) => a.nome.localeCompare(b.nome))
  }, [equipes, modalidadeFiltro])

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-filter-bar">
        <button
          className={`nexo-filter-chip ${modalidadeFiltro === "todas" ? "active" : ""}`}
          onClick={() => setModalidadeFiltro("todas")}
        >
          Todas modalidades
        </button>
        {modalidades.map((m) => (
          <button
            key={m.id}
            className={`nexo-filter-chip ${modalidadeFiltro === String(m.id) ? "active" : ""}`}
            onClick={() => setModalidadeFiltro(String(m.id))}
          >
            {m.emoji} {m.nome}
          </button>
        ))}
      </div>

      <div className="nexo-section" style={{ paddingTop: 0 }}>
        {loading && <LoadingState texto="Carregando equipes..." />}
        {error && <ErrorState mensagem={error} onRetry={refetchEquipes} />}

        {!loading && !error && listaFiltrada.length === 0 && (
          <EmptyState icon="👥" texto="Nenhuma equipe encontrada." />
        )}

        {!loading &&
          !error &&
          listaFiltrada.map((equipe) => (
            <button key={equipe.id} className="nexo-team-card team-card-btn" onClick={() => setSelecionada(equipe)}>
              <div className="nexo-team-avatar" style={{ background: corDaEquipe(equipe.id) }}>
                {iniciaisDaEquipe(equipe.nome)}
              </div>
              <div className="nexo-team-info">
                <div className="nexo-team-name">{equipe.nome}</div>
                <div className="nexo-team-meta">
                  {modalidadesPorId.get(equipe.modalidadeId)?.nome || "Modalidade removida"}
                  {equipe.turma && ` · Turma ${equipe.turma}`}
                </div>
              </div>
            </button>
          ))}
      </div>

      {professor && (
        <button className="nexo-fab" onClick={() => setCriando(true)} aria-label="Nova equipe">
          <Plus size={24} />
        </button>
      )}

      {selecionada && (
        <EquipeDetail
          equipe={selecionada}
          professor={professor}
          onClose={() => setSelecionada(null)}
          onAlterada={() => {
            setSelecionada(null)
            refetchEquipes()
          }}
        />
      )}

      {criando && (
        <EquipeForm
          onClose={() => setCriando(false)}
          onSalvo={() => {
            setCriando(false)
            refetchEquipes()
          }}
        />
      )}
    </div>
  )
}
