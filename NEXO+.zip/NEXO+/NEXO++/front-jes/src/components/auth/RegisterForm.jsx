import { useState } from "react"
import { ArrowLeft } from "lucide-react"
import FormField from "../common/FormField.jsx"
import FormError from "../common/FormError.jsx"
import { useAuth } from "../../context/AuthContext.jsx"
import "./AuthForm.css"

export default function RegisterForm({ onVoltar, onIrParaLogin, onCadastrou }) {
  const { cadastrar } = useAuth()
  const [nome, setNome] = useState("")
  const [email, setEmail] = useState("")
  const [senha, setSenha] = useState("")
  const [codigoProfessor, setCodigoProfessor] = useState("")
  const [erro, setErro] = useState(null)
  const [enviando, setEnviando] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setErro(null)
    setEnviando(true)
    try {
      await cadastrar({ nome, email, senha, codigoProfessor })
      onCadastrou()
    } catch (err) {
      setErro(err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <div className="auth-screen">
      <button className="auth-back" onClick={onVoltar}>
        <ArrowLeft size={18} />
        Voltar
      </button>

      <div className="auth-card">
        <h1 className="auth-title">Cadastro de Professor</h1>
        <p className="auth-subtitle">Peça o código de professor à coordenação da escola.</p>

        <form onSubmit={handleSubmit}>
          <FormError message={erro} />

          <FormField label="Nome completo">
            <input value={nome} onChange={(e) => setNome(e.target.value)} required placeholder="Seu nome" />
          </FormField>

          <FormField label="E-mail">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="username"
              placeholder="professor@escola.com"
            />
          </FormField>

          <FormField label="Senha" hint="Mínimo de 8 caracteres">
            <input
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              required
              minLength={8}
              autoComplete="new-password"
              placeholder="••••••••"
            />
          </FormField>

          <FormField label="Código de professor">
            <input
              value={codigoProfessor}
              onChange={(e) => setCodigoProfessor(e.target.value)}
              required
              placeholder="Fornecido pela coordenação"
            />
          </FormField>

          <button className="nexo-btn primary full" type="submit" disabled={enviando}>
            {enviando ? "Cadastrando..." : "Cadastrar"}
          </button>
        </form>

        <button className="auth-switch" onClick={onIrParaLogin}>
          Já tem conta? <strong>Entrar</strong>
        </button>
      </div>
    </div>
  )
}
