import { useState } from "react"
import { ArrowLeft } from "lucide-react"
import FormField from "../common/FormField.jsx"
import FormError from "../common/FormError.jsx"
import { useAuth } from "../../context/AuthContext.jsx"
import "./AuthForm.css"

export default function LoginForm({ onVoltar, onIrParaCadastro, onEntrou }) {
  const { entrar } = useAuth()
  const [email, setEmail] = useState("")
  const [senha, setSenha] = useState("")
  const [erro, setErro] = useState(null)
  const [enviando, setEnviando] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setErro(null)
    setEnviando(true)
    try {
      await entrar({ email, senha })
      onEntrou()
    } catch (err) {
      setErro(err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <div className="auth-screen">
      <button className="auth-back" onClick={onVoltar}>
        <ArrowLeft size={18} />
        Voltar
      </button>

      <div className="auth-card">
        <h1 className="auth-title">Entrar como Professor</h1>
        <p className="auth-subtitle">Use o e-mail e a senha cadastrados.</p>

        <form onSubmit={handleSubmit}>
          <FormError message={erro} />

          <FormField label="E-mail">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="username"
              placeholder="professor@escola.com"
            />
          </FormField>

          <FormField label="Senha">
            <input
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              required
              autoComplete="current-password"
              placeholder="••••••••"
            />
          </FormField>

          <button className="nexo-btn primary full" type="submit" disabled={enviando}>
            {enviando ? "Entrando..." : "Entrar"}
          </button>
        </form>

        <button className="auth-switch" onClick={onIrParaCadastro}>
          Ainda não tem conta? <strong>Cadastre-se</strong>
        </button>
      </div>
    </div>
  )
}
