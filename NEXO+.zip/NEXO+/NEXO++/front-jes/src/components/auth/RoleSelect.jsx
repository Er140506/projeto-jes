import { GraduationCap, Users2 } from "lucide-react"
import "./RoleSelect.css"

/**
 * Tela inicial de escolha de perfil. Baseada no RoleSelect.jsx do Design
 * Aprimorado (Figma) - a estrutura e o texto seguem a referência, mas o CSS
 * foi escrito à mão aqui porque o export do Figma não trouxe estilos pra
 * essas classes (role-screen, role-card etc. não existiam em nenhum .css
 * do pacote de design).
 */
export default function RoleSelect({ onSelectAluno, onSelectProfessor }) {
  return (
    <div className="role-screen">
      <div className="role-brand">
        <div className="role-logo">
          NEXO<span>+</span>
        </div>
        <p className="role-tagline">Campeonatos Estudantis</p>
      </div>

      <p className="role-prompt">Como você quer entrar?</p>

      <div className="role-cards">
        <button className="role-card" onClick={onSelectAluno}>
          <div className="role-card-icon aluno">
            <GraduationCap size={28} />
          </div>
          <div className="role-card-text">
            <strong>Sou Aluno</strong>
            <span>Acompanhar jogos, placares e ranking</span>
          </div>
        </button>

        <button className="role-card" onClick={onSelectProfessor}>
          <div className="role-card-icon professor">
            <Users2 size={28} />
          </div>
          <div className="role-card-text">
            <strong>Sou Professor</strong>
            <span>Gerenciar modalidades, equipes e resultados</span>
          </div>
        </button>
      </div>
    </div>
  )
}
