import { useState } from "react"
import RoleSelect from "./RoleSelect.jsx"
import LoginForm from "./LoginForm.jsx"
import RegisterForm from "./RegisterForm.jsx"

/**
 * Orquestra o fluxo de entrada: escolha de perfil -> (aluno entra direto)
 * ou (professor faz login/cadastro). O aluno não tem conta no back-end
 * (ver seção "AUTENTICAÇÃO" do briefing), então "onEntrarComoAluno" só
 * libera a navegação, sem chamar a API.
 */
export default function AuthScreen({ onEntrarComoAluno, onProfessorAutenticado }) {
  const [etapa, setEtapa] = useState("role") // role | login | registro

  if (etapa === "login") {
    return (
      <LoginForm
        onVoltar={() => setEtapa("role")}
        onIrParaCadastro={() => setEtapa("registro")}
        onEntrou={onProfessorAutenticado}
      />
    )
  }

  if (etapa === "registro") {
    return (
      <RegisterForm
        onVoltar={() => setEtapa("role")}
        onIrParaLogin={() => setEtapa("login")}
        onCadastrou={onProfessorAutenticado}
      />
    )
  }

  return <RoleSelect onSelectAluno={onEntrarComoAluno} onSelectProfessor={() => setEtapa("login")} />
}
