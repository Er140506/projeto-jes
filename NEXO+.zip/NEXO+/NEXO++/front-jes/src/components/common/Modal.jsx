import { X } from "lucide-react"
import "./Modal.css"

export default function Modal({ title, onClose, children, footer }) {
  return (
    <div className="nexo-modal-overlay" onClick={onClose}>
      <div className="nexo-modal-box" onClick={(e) => e.stopPropagation()}>
        <div className="nexo-modal-header">
          <h2>{title}</h2>
          <button className="nexo-modal-close" onClick={onClose} aria-label="Fechar">
            <X size={20} />
          </button>
        </div>
        <div className="nexo-modal-body">{children}</div>
        {footer && <div className="nexo-modal-footer">{footer}</div>}
      </div>
    </div>
  )
}
