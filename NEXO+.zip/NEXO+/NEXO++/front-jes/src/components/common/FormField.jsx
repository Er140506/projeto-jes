import "./FormField.css"

/**
 * Campo de formulário padrão do NEXO+: label grande, input grande (alvo de
 * toque confortável em quadra) e espaço reservado pra mensagem de erro.
 * Reaproveita a ideia do componente FormField do projeto antigo, mas com
 * import correto de useState removido daqui (esse componente é "burro" -
 * não guarda estado, só exibe).
 */
export default function FormField({ label, error, children, hint }) {
  return (
    <label className="nexo-field">
      <span className="nexo-field-label">{label}</span>
      {children}
      {hint && !error && <span className="nexo-field-hint">{hint}</span>}
      {error && <span className="nexo-field-error">{error}</span>}
    </label>
  )
}
