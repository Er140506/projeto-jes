import { AlertCircle } from "lucide-react"
import "./FormError.css"

/** Erro de nível de formulário (ex: falha ao salvar na API), não de campo. */
export default function FormError({ message }) {
  if (!message) return null

  return (
    <div className="nexo-form-error" role="alert">
      <AlertCircle size={18} />
      <span>{message}</span>
    </div>
  )
}
