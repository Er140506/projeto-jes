// Estados reaproveitados por praticamente toda tela que busca dados da API.
// Os estilos (.nexo-loading, .nexo-empty, .nexo-error, .nexo-spinner) vivem
// em styles/shared.css por serem usados em muitos lugares diferentes.

export function LoadingState({ texto = "Carregando..." }) {
  return (
    <div className="nexo-loading">
      <div className="nexo-spinner" />
      <span>{texto}</span>
    </div>
  )
}

export function ErrorState({ mensagem, onRetry }) {
  return (
    <div className="nexo-error">
      <span>{mensagem || "Não foi possível carregar os dados."}</span>
      {onRetry && (
        <button className="nexo-btn ghost sm" onClick={onRetry}>
          Tentar novamente
        </button>
      )}
    </div>
  )
}

export function EmptyState({ icon = "📭", texto }) {
  return (
    <div className="nexo-empty">
      <div className="nexo-empty-icon">{icon}</div>
      <div className="nexo-empty-text">{texto}</div>
    </div>
  )
}
