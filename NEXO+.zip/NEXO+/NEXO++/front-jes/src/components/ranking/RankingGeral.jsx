import { useCallback, useMemo } from "react"
import { Trophy } from "lucide-react"
import { classificacaoModalidade } from "../../api/modalidades.js"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { useModalidadesRealtime } from "../../hooks/useModalidadesRealtime.js"
import { useApi } from "../../hooks/useApi.js"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"
import { calcularRankingGeral } from "../../utils/ranking.js"
import "./RankingGeral.css"

/**
 * Ranking Geral - soma os pontos da mesma turma (ex: "3D") entre todas as
 * modalidades, mesmo sendo cadastros de equipe separados em cada uma
 * (o pedido central do briefing). Não existe endpoint pra isso no
 * back-end, então esta tela busca a classificação de cada modalidade
 * (a mesma fonte de verdade da tela de Classificação) e soma por turma -
 * ver src/utils/ranking.js.
 */
export default function RankingGeral() {
  const { modalidades, loading: carregandoModalidades } = useModalidades()

  const fetcher = useCallback(async () => {
    const entradas = await Promise.all(
      modalidades.map(async (m) => [m.id, await classificacaoModalidade(m.id)])
    )
    return Object.fromEntries(entradas)
  }, [modalidades])

  const { data: classificacoesPorModalidade, loading, error, refetch } = useApi(fetcher, {
    skip: modalidades.length === 0,
  })

  useModalidadesRealtime(
    modalidades.map((m) => m.id),
    refetch
  )

  const ranking = useMemo(() => {
    if (!classificacoesPorModalidade) return []
    return calcularRankingGeral(modalidades, classificacoesPorModalidade)
  }, [modalidades, classificacoesPorModalidade])

  if (carregandoModalidades || loading) return <LoadingState texto="Somando pontos entre modalidades..." />
  if (error) return <ErrorState mensagem={error} onRetry={refetch} />
  if (modalidades.length === 0) return <EmptyState icon="🏆" texto="Cadastre modalidades para ver o Ranking Geral." />
  if (ranking.length === 0) return <EmptyState icon="🏆" texto="Nenhuma equipe pontuou ainda." />

  const podio = ranking.slice(0, 3)
  const medalhas = ["🥇", "🥈", "🥉"]

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-hero ranking-hero">
        <div className="nexo-hero-badge">
          <Trophy size={12} /> Ranking Geral
        </div>
        <h1 className="nexo-hero-title">Soma de pontos entre todas as modalidades</h1>
        <p className="nexo-hero-sub">Equipes da mesma turma são somadas, mesmo em modalidades diferentes.</p>
      </div>

      <div className="nexo-section">
        <div className="ranking-podio">
          {podio.map((item, i) => (
            <div key={item.chave} className={`ranking-podio-card place-${i + 1}`}>
              <span className="ranking-podio-medal">{medalhas[i]}</span>
              <span className="ranking-podio-nome">{item.chave}</span>
              <span className="ranking-podio-pontos">{item.pontosTotais} pts</span>
            </div>
          ))}
        </div>
      </div>

      <div className="nexo-section" style={{ paddingTop: 0 }}>
        <div className="nexo-card" style={{ padding: 0 }}>
          <div className="nexo-table-wrap">
            <table className="nexo-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Turma / Equipe</th>
                  <th>Modalidades</th>
                  <th>Pontos</th>
                </tr>
              </thead>
              <tbody>
                {ranking.map((item, i) => (
                  <tr key={item.chave}>
                    <td>
                      <span className={`nexo-table-rank ${i === 0 ? "top1" : i === 1 ? "top2" : i === 2 ? "top3" : ""}`}>
                        {i + 1}º
                      </span>
                    </td>
                    <td>
                      <span className="nexo-table-team">{item.chave}</span>
                    </td>
                    <td className="ranking-breakdown-cell">
                      {item.porModalidade.map((pm) => (
                        <span key={pm.modalidadeId} className="ranking-breakdown-chip">
                          {pm.emoji} {pm.pontos}
                        </span>
                      ))}
                    </td>
                    <td>
                      <span className="nexo-table-pts">{item.pontosTotais}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
