import { useState } from "react"
import { Minus, Plus } from "lucide-react"
import Modal from "../common/Modal.jsx"
import FormError from "../common/FormError.jsx"
import { useEquipes } from "../../context/EquipesContext.jsx"
import { atualizarPartida, deletarPartida } from "../../api/partidas.js"
import { validarPlacarSemEmpate } from "../../utils/validation.js"
import "./ScoreModal.css"

const STATUS_OPCOES = [
  { key: "agendado", label: "Em breve" },
  { key: "ao_vivo", label: "Ao vivo" },
  { key: "finalizado", label: "Encerrada" },
]

export default function ScoreModal({ partida, onClose, onSalvo }) {
  const { equipesPorId } = useEquipes()
  const timeA = equipesPorId.get(partida.timeAId)
  const timeB = equipesPorId.get(partida.timeBId)

  const [placarA, setPlacarA] = useState(partida.placarA ?? 0)
  const [placarB, setPlacarB] = useState(partida.placarB ?? 0)
  const [status, setStatus] = useState(partida.status === "bye" ? "agendado" : partida.status)
  const [erro, setErro] = useState(null)
  const [salvando, setSalvando] = useState(false)
  const [excluindo, setExcluindo] = useState(false)

  async function salvar() {
    setErro(null)

    // Sem empate: só valida quando a partida está sendo marcada como encerrada.
    // Uma partida "ao vivo" pode passar por um instante empatada no placar.
    if (status === "finalizado") {
      const mensagem = validarPlacarSemEmpate(placarA, placarB)
      if (mensagem) {
        setErro(mensagem)
        return
      }
    }

    setSalvando(true)
    try {
      await atualizarPartida(partida.id, { placarA: Number(placarA), placarB: Number(placarB), status })
      onSalvo()
    } catch (err) {
      setErro(err.message)
    } finally {
      setSalvando(false)
    }
  }

  async function excluir() {
    if (!window.confirm("Excluir esta partida? Essa ação não pode ser desfeita.")) return
    setExcluindo(true)
    setErro(null)
    try {
      await deletarPartida(partida.id)
      onSalvo()
    } catch (err) {
      setErro(err.message)
      setExcluindo(false)
    }
  }

  return (
    <Modal title="Lançar placar" onClose={onClose}>
      <FormError message={erro} />

      <div className="score-teams">
        <div className="score-team-block">
          <span className="score-team-name">{timeA?.nome || "Time A"}</span>
          <div className="score-stepper">
            <button type="button" onClick={() => setPlacarA((v) => Math.max(0, Number(v) - 1))} aria-label="Diminuir">
              <Minus size={20} />
            </button>
            <span className="score-value">{placarA}</span>
            <button type="button" onClick={() => setPlacarA((v) => Number(v) + 1)} aria-label="Aumentar">
              <Plus size={20} />
            </button>
          </div>
        </div>

        <span className="score-x">×</span>

        <div className="score-team-block">
          <span className="score-team-name">{timeB?.nome || "Time B"}</span>
          <div className="score-stepper">
            <button type="button" onClick={() => setPlacarB((v) => Math.max(0, Number(v) - 1))} aria-label="Diminuir">
              <Minus size={20} />
            </button>
            <span className="score-value">{placarB}</span>
            <button type="button" onClick={() => setPlacarB((v) => Number(v) + 1)} aria-label="Aumentar">
              <Plus size={20} />
            </button>
          </div>
        </div>
      </div>

      <div className="score-status-row">
        {STATUS_OPCOES.map((opcao) => (
          <button
            key={opcao.key}
            className={`nexo-filter-chip ${status === opcao.key ? "active" : ""}`}
            onClick={() => setStatus(opcao.key)}
            type="button"
          >
            {opcao.label}
          </button>
        ))}
      </div>

      {status === "finalizado" && placarA === placarB && (
        <p className="score-warning">⚠️ Ajuste o placar: não é permitido empate no NEXO+.</p>
      )}

      <div className="score-actions">
        <button className="nexo-btn primary full" onClick={salvar} disabled={salvando || excluindo}>
          {salvando ? "Salvando..." : "Salvar"}
        </button>
        <button className="nexo-btn danger full" onClick={excluir} disabled={salvando || excluindo}>
          {excluindo ? "Excluindo..." : "Excluir partida"}
        </button>
      </div>
    </Modal>
  )
}
