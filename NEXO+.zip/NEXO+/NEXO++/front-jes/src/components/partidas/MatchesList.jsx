import { useCallback, useMemo, useState } from "react"
import { Plus } from "lucide-react"
import { listarPartidas } from "../../api/partidas.js"
import { useApi } from "../../hooks/useApi.js"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { useModalidadesRealtime } from "../../hooks/useModalidadesRealtime.js"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"
import MatchCard from "./MatchCard.jsx"
import ScoreModal from "./ScoreModal.jsx"
import MatchForm from "./MatchForm.jsx"

const FILTROS_STATUS = [
  { key: "todos", label: "Todas" },
  { key: "ao_vivo", label: "Ao Vivo" },
  { key: "agendado", label: "Em Breve" },
  { key: "finalizado", label: "Encerradas" },
]

export default function MatchesList({ professor }) {
  const fetcher = useCallback(listarPartidas, [])
  const { data: partidas, loading, error, refetch } = useApi(fetcher)
  const { modalidades } = useModalidades()

  const [modalidadeFiltro, setModalidadeFiltro] = useState("todas")
  const [statusFiltro, setStatusFiltro] = useState("todos")
  const [partidaSelecionada, setPartidaSelecionada] = useState(null)
  const [criando, setCriando] = useState(false)

  const idsParaOuvir = useMemo(
    () => (modalidadeFiltro === "todas" ? modalidades.map((m) => m.id) : [Number(modalidadeFiltro)]),
    [modalidadeFiltro, modalidades]
  )
  useModalidadesRealtime(idsParaOuvir, refetch)

  const listaFiltrada = useMemo(() => {
    if (!partidas) return []
    return partidas
      .filter((p) => modalidadeFiltro === "todas" || p.modalidadeId === Number(modalidadeFiltro))
      .filter((p) => statusFiltro === "todos" || p.status === statusFiltro)
      .sort((a, b) => {
        // Ao vivo primeiro, depois agendadas mais próximas, depois encerradas mais recentes
        const prioridade = { ao_vivo: 0, agendado: 1, bye: 1, finalizado: 2 }
        const diffPrioridade = (prioridade[a.status] ?? 3) - (prioridade[b.status] ?? 3)
        if (diffPrioridade !== 0) return diffPrioridade
        const chaveA = `${a.data || ""}${a.hora || ""}`
        const chaveB = `${b.data || ""}${b.hora || ""}`
        return a.status === "finalizado" ? chaveB.localeCompare(chaveA) : chaveA.localeCompare(chaveB)
      })
  }, [partidas, modalidadeFiltro, statusFiltro])

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-filter-bar">
        <button
          className={`nexo-filter-chip ${modalidadeFiltro === "todas" ? "active" : ""}`}
          onClick={() => setModalidadeFiltro("todas")}
        >
          Todas modalidades
        </button>
        {modalidades.map((m) => (
          <button
            key={m.id}
            className={`nexo-filter-chip ${modalidadeFiltro === String(m.id) ? "active" : ""}`}
            onClick={() => setModalidadeFiltro(String(m.id))}
          >
            {m.emoji} {m.nome}
          </button>
        ))}
      </div>

      <div className="nexo-filter-bar">
        {FILTROS_STATUS.map((f) => (
          <button
            key={f.key}
            className={`nexo-filter-chip ${statusFiltro === f.key ? "active" : ""}`}
            onClick={() => setStatusFiltro(f.key)}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="nexo-section" style={{ paddingTop: 0 }}>
        {loading && <LoadingState texto="Carregando partidas..." />}
        {error && <ErrorState mensagem={error} onRetry={refetch} />}

        {!loading && !error && listaFiltrada.length === 0 && (
          <EmptyState icon="🏟️" texto="Nenhuma partida encontrada com esse filtro." />
        )}

        {!loading &&
          !error &&
          listaFiltrada.map((partida) => (
            <MatchCard
              key={partida.id}
              partida={partida}
              professor={professor}
              onClick={professor && partida.status !== "bye" ? () => setPartidaSelecionada(partida) : undefined}
            />
          ))}
      </div>

      {professor && (
        <button className="nexo-fab" onClick={() => setCriando(true)} aria-label="Nova partida">
          <Plus size={24} />
        </button>
      )}

      {partidaSelecionada && (
        <ScoreModal
          partida={partidaSelecionada}
          onClose={() => setPartidaSelecionada(null)}
          onSalvo={() => {
            setPartidaSelecionada(null)
            refetch()
          }}
        />
      )}

      {criando && (
        <MatchForm
          onClose={() => setCriando(false)}
          onSalvo={() => {
            setCriando(false)
            refetch()
          }}
        />
      )}
    </div>
  )
}
