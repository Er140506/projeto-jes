import { useMemo, useState } from "react"
import Modal from "../common/Modal.jsx"
import FormField from "../common/FormField.jsx"
import FormError from "../common/FormError.jsx"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { useEquipes } from "../../context/EquipesContext.jsx"
import { criarPartida } from "../../api/partidas.js"

/**
 * Criação manual de partida. O caminho principal pra popular o calendário
 * é "Gerar chaveamento" (dentro da modalidade), que já usa o algoritmo do
 * back-end - este formulário é o complemento pra jogos avulsos/amistosos
 * fora do chaveamento automático.
 */
export default function MatchForm({ onClose, onSalvo }) {
  const { modalidades } = useModalidades()
  const { equipes } = useEquipes()

  const modalidadesComPartida = useMemo(() => modalidades.filter((m) => m.formato !== "ranking"), [modalidades])

  const [modalidadeId, setModalidadeId] = useState(modalidadesComPartida[0]?.id || "")
  const [timeAId, setTimeAId] = useState("")
  const [timeBId, setTimeBId] = useState("")
  const [faseNome, setFaseNome] = useState("Fase de Grupos")
  const [rodada, setRodada] = useState(1)
  const [data, setData] = useState("")
  const [hora, setHora] = useState("")
  const [local, setLocal] = useState("")
  const [erro, setErro] = useState(null)
  const [enviando, setEnviando] = useState(false)

  const modalidadeSelecionada = modalidades.find((m) => m.id === Number(modalidadeId))
  const equipesDaModalidade = equipes.filter((e) => e.modalidadeId === Number(modalidadeId))

  async function handleSubmit(e) {
    e.preventDefault()
    setErro(null)

    if (timeAId && timeBId && timeAId === timeBId) {
      setErro("Escolha duas equipes diferentes.")
      return
    }

    setEnviando(true)
    try {
      await criarPartida({
        modalidadeId: Number(modalidadeId),
        formato: modalidadeSelecionada?.formato === "eliminatoria" ? "eliminatoria" : "pontoscorridos",
        rodada: Number(rodada) || 1,
        faseNome: faseNome || "Fase de Grupos",
        timeAId: timeAId ? Number(timeAId) : null,
        timeBId: timeBId ? Number(timeBId) : null,
        data: data || null,
        hora: hora || null,
        local: local || null,
        status: "agendado",
      })
      onSalvo()
    } catch (err) {
      setErro(err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <Modal title="Nova partida" onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <FormError message={erro} />

        <FormField label="Modalidade">
          <select value={modalidadeId} onChange={(e) => { setModalidadeId(e.target.value); setTimeAId(""); setTimeBId("") }} required>
            <option value="" disabled>Selecione</option>
            {modalidadesComPartida.map((m) => (
              <option key={m.id} value={m.id}>{m.emoji} {m.nome}</option>
            ))}
          </select>
        </FormField>

        <FormField label="Equipe A">
          <select value={timeAId} onChange={(e) => setTimeAId(e.target.value)}>
            <option value="">A definir</option>
            {equipesDaModalidade.map((e) => (
              <option key={e.id} value={e.id}>{e.nome}</option>
            ))}
          </select>
        </FormField>

        <FormField label="Equipe B">
          <select value={timeBId} onChange={(e) => setTimeBId(e.target.value)}>
            <option value="">A definir</option>
            {equipesDaModalidade.map((e) => (
              <option key={e.id} value={e.id}>{e.nome}</option>
            ))}
          </select>
        </FormField>

        <FormField label="Fase">
          <input value={faseNome} onChange={(e) => setFaseNome(e.target.value)} placeholder="Ex: Fase de Grupos" />
        </FormField>

        <FormField label="Rodada">
          <input type="number" min={1} value={rodada} onChange={(e) => setRodada(e.target.value)} />
        </FormField>

        <FormField label="Data">
          <input type="date" value={data} onChange={(e) => setData(e.target.value)} />
        </FormField>

        <FormField label="Horário">
          <input type="time" value={hora} onChange={(e) => setHora(e.target.value)} />
        </FormField>

        <FormField label="Local">
          <input value={local} onChange={(e) => setLocal(e.target.value)} placeholder="Ex: Quadra 1" />
        </FormField>

        <button className="nexo-btn primary full" type="submit" disabled={enviando}>
          {enviando ? "Criando..." : "Criar partida"}
        </button>
      </form>
    </Modal>
  )
}
