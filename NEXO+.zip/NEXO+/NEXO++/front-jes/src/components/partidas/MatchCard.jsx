import { statusPartidaInfo, formatarDataHora } from "../../utils/format.js"
import { useEquipes } from "../../context/EquipesContext.jsx"
import "./MatchCard.css"

/**
 * Card de partida reaproveitado nas telas de Partidas, Dashboard e Bracket.
 * Recebe só a `partida` crua (timeAId/timeBId) e resolve os nomes das
 * equipes pelo contexto compartilhado - ver EquipesContext.jsx pra saber
 * por que isso é necessário (GET /partidas não populada os times).
 */
export default function MatchCard({ partida, onClick, professor }) {
  const { equipesPorId } = useEquipes()
  const timeA = equipesPorId.get(partida.timeAId)
  const timeB = equipesPorId.get(partida.timeBId)
  const info = statusPartidaInfo(partida.status)
  const temPlacar = partida.placarA != null && partida.placarB != null

  const conteudo = (
    <>
      <div className="nexo-match-team">
        <div className="nexo-match-team-name">{timeA?.nome || "A definir"}</div>
      </div>

      <div className="nexo-match-score-block">
        {temPlacar ? (
          <>
            <span className="nexo-match-score">{partida.placarA}</span>
            <span className="nexo-match-sep">×</span>
            <span className="nexo-match-score">{partida.placarB}</span>
          </>
        ) : (
          <span className="nexo-match-sep">vs</span>
        )}
      </div>

      <div className="nexo-match-team">
        <div className="nexo-match-team-name">{timeB?.nome || "A definir"}</div>
      </div>
    </>
  )

  return (
    <div
      className={`nexo-match-card-wrap ${onClick ? "clickable" : ""}`}
      onClick={onClick}
      role={onClick ? "button" : undefined}
    >
      <div className="nexo-match-card">{conteudo}</div>
      <div className="nexo-match-meta">
        <span className={`nexo-badge ${info.badge}`}>{info.label}</span>
        {partida.faseNome && <span>· {partida.faseNome}</span>}
        {partida.local && <span>· {partida.local}</span>}
        {(partida.data || partida.hora) && <span>· {formatarDataHora(partida.data, partida.hora)}</span>}
      </div>
      {professor && onClick && (
        <div className="nexo-match-edit-hint">Toque para {partida.status === "finalizado" ? "editar placar" : "lançar placar"}</div>
      )}
    </div>
  )
}
