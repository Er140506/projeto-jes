import { LogOut } from "lucide-react"
import { navFor } from "./navConfig.js"
import "./Sidebar.css"

export default function Sidebar({ role, screen, onGo, onSwitchRole }) {
  const itens = navFor(role)

  return (
    <aside className="nexo-sidebar">
      <div className="nexo-sidebar-brand">
        <div className="nexo-sidebar-logo">
          NEXO<span>+</span>
        </div>
        <div className="nexo-sidebar-tagline">Campeonatos Estudantis</div>
      </div>

      <div className={`nexo-sidebar-role ${role}`}>
        {role === "professor" ? "👨‍🏫 Professor" : "🎓 Aluno"}
      </div>

      <nav className="nexo-sidebar-nav">
        {itens.map(({ key, label, icon: Icon }) => {
          const ativo = screen === key
          return (
            <button
              key={key}
              className={`nexo-sidebar-item ${ativo ? "active" : ""}`}
              onClick={() => onGo(key)}
              aria-current={ativo ? "page" : undefined}
            >
              <Icon size={19} />
              {label}
            </button>
          )
        })}
      </nav>

      <button className="nexo-sidebar-logout" onClick={onSwitchRole}>
        <LogOut size={18} />
        Trocar perfil
      </button>
    </aside>
  )
}
