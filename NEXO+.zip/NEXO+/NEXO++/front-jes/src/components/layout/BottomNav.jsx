import { navFor } from "./navConfig.js"
import "./BottomNav.css"

export default function BottomNav({ role, screen, onGo }) {
  const itens = navFor(role).slice(0, 5)

  return (
    <nav className="nexo-bottom-nav" role="navigation" aria-label="Navegação principal">
      {itens.map(({ key, label, icon: Icon }) => {
        const ativo = screen === key
        return (
          <button
            key={key}
            className={`nexo-nav-item ${ativo ? "active" : ""}`}
            onClick={() => onGo(key)}
            aria-current={ativo ? "page" : undefined}
          >
            <div className="nexo-nav-indicator" />
            <Icon size={22} strokeWidth={ativo ? 2.5 : 1.8} />
            <span>{label}</span>
          </button>
        )
      })}
    </nav>
  )
}
