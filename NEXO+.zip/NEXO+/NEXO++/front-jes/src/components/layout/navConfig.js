import { Home, Swords, BarChart2, Trophy, Users, Layers, Settings } from "lucide-react"

// Itens comuns a aluno e professor. "Gestão" só aparece pra professor.
// A ordem importa: a bottom-nav do celular mostra só os 5 primeiros
// (partidas e placar são o que mais se usa em quadra), o resto fica
// acessível pela Sidebar (tablet/desktop) e por atalhos dentro das telas.
export function navFor(role) {
  const itens = [
    { key: "home", label: "Início", icon: Home },
    { key: "matches", label: "Partidas", icon: Swords },
    { key: "standings", label: "Classificação", icon: BarChart2 },
    { key: "ranking", label: "Ranking Geral", icon: Trophy },
    { key: "teams", label: "Equipes", icon: Users },
    { key: "modalities", label: "Modalidades", icon: Layers },
  ]

  if (role === "professor") {
    itens.push({ key: "management", label: "Gestão", icon: Settings })
  }

  return itens
}

export const SCREEN_TITLES = {
  home: "Início",
  matches: "Partidas",
  standings: "Classificação",
  ranking: "Ranking Geral",
  teams: "Equipes",
  modalities: "Modalidades",
  management: "Gestão",
}
