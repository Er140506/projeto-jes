import { LogOut } from "lucide-react"
import "./Header.css"

export default function Header({ subtitle, role, onSwitchRole }) {
  return (
    <header className="nexo-header">
      <div className="nexo-header-brand">
        <div className="nexo-header-logo">
          NEXO<span>+</span>
        </div>
        {subtitle && <div className="nexo-header-subtitle">{subtitle}</div>}
      </div>
      <div className="nexo-header-actions">
        {role && (
          <div className={`nexo-role-badge ${role}`}>
            {role === "professor" ? "👨‍🏫 Prof." : "🎓 Aluno"}
          </div>
        )}
        {onSwitchRole && (
          <button className="nexo-icon-btn" onClick={onSwitchRole} aria-label="Trocar perfil">
            <LogOut size={20} />
          </button>
        )}
      </div>
    </header>
  )
}
