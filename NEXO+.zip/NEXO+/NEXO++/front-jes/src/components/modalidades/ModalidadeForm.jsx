import { useState } from "react"
import Modal from "../common/Modal.jsx"
import FormField from "../common/FormField.jsx"
import FormError from "../common/FormError.jsx"
import { criarModalidade, atualizarModalidade } from "../../api/modalidades.js"

export default function ModalidadeForm({ modalidade, onClose, onSalvo }) {
  const editando = !!modalidade

  const [nome, setNome] = useState(modalidade?.nome || "")
  const [emoji, setEmoji] = useState(modalidade?.emoji || "🏆")
  const [tipo, setTipo] = useState(modalidade?.tipo || "equipe")
  const [formato, setFormato] = useState(modalidade?.formato || "pontoscorridos")
  const [minJogadores, setMinJogadores] = useState(modalidade?.minJogadores ?? 1)
  const [maxJogadores, setMaxJogadores] = useState(modalidade?.maxJogadores ?? 1)
  const [duracaoPadrao, setDuracaoPadrao] = useState(modalidade?.duracaoPadrao ?? "")
  const [erro, setErro] = useState(null)
  const [enviando, setEnviando] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setErro(null)
    setEnviando(true)

    const payload = {
      nome,
      emoji,
      tipo,
      formato,
      minJogadores: Number(minJogadores) || 1,
      maxJogadores: Number(maxJogadores) || 1,
      duracaoPadrao: duracaoPadrao ? Number(duracaoPadrao) : null,
      // O back-end usa esse booleano (não o "formato") pra decidir se a
      // modalidade aceita chaveamento - ver gerarChaveamento no controller.
      ranking: formato === "ranking",
    }

    try {
      if (editando) {
        await atualizarModalidade(modalidade.id, payload)
      } else {
        await criarModalidade(payload)
      }
      onSalvo()
    } catch (err) {
      setErro(err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <Modal title={editando ? "Editar modalidade" : "Nova modalidade"} onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <FormError message={erro} />

        <FormField label="Nome">
          <input value={nome} onChange={(e) => setNome(e.target.value)} required placeholder="Ex: Vôlei" />
        </FormField>

        <FormField label="Emoji" hint="Usado como ícone nos cards">
          <input value={emoji} onChange={(e) => setEmoji(e.target.value)} maxLength={10} placeholder="🏐" />
        </FormField>

        <FormField label="Tipo">
          <select value={tipo} onChange={(e) => setTipo(e.target.value)}>
            <option value="equipe">Por equipe</option>
            <option value="individual">Individual</option>
          </select>
        </FormField>

        <FormField label="Formato de disputa">
          <select value={formato} onChange={(e) => setFormato(e.target.value)}>
            <option value="pontoscorridos">Pontos corridos</option>
            <option value="eliminatoria">Eliminatória (mata-mata)</option>
            <option value="ranking">Ranking por provas</option>
          </select>
        </FormField>

        {tipo === "equipe" && (
          <>
            <FormField label="Jogadores por equipe (mínimo)">
              <input type="number" min={1} value={minJogadores} onChange={(e) => setMinJogadores(e.target.value)} />
            </FormField>
            <FormField label="Jogadores por equipe (máximo)">
              <input type="number" min={1} value={maxJogadores} onChange={(e) => setMaxJogadores(e.target.value)} />
            </FormField>
          </>
        )}

        <FormField label="Duração padrão (minutos)" hint="Opcional">
          <input type="number" min={1} value={duracaoPadrao} onChange={(e) => setDuracaoPadrao(e.target.value)} />
        </FormField>

        <button className="nexo-btn primary full" type="submit" disabled={enviando}>
          {enviando ? "Salvando..." : editando ? "Salvar alterações" : "Criar modalidade"}
        </button>
      </form>
    </Modal>
  )
}
