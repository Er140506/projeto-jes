import { useState } from "react"
import { Plus } from "lucide-react"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"
import { FORMATO_MODALIDADE_LABEL } from "../../utils/format.js"
import ModalidadeDetail from "./ModalidadeDetail.jsx"
import ModalidadeForm from "./ModalidadeForm.jsx"
import "./Modalidades.css"

export default function ModalidadesList({ professor }) {
  const { modalidades, loading, error, refetchModalidades } = useModalidades()
  const [selecionadaId, setSelecionadaId] = useState(null)
  const [criando, setCriando] = useState(false)

  if (selecionadaId) {
    return <ModalidadeDetail modalidadeId={selecionadaId} professor={professor} onVoltar={() => setSelecionadaId(null)} />
  }

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-section">
        {loading && <LoadingState texto="Carregando modalidades..." />}
        {error && <ErrorState mensagem={error} onRetry={refetchModalidades} />}

        {!loading && !error && modalidades.length === 0 && (
          <EmptyState icon="🏐" texto="Nenhuma modalidade cadastrada ainda." />
        )}

        {!loading &&
          !error &&
          modalidades.map((m) => (
            <button key={m.id} className="nexo-modality-card modality-card-btn" onClick={() => setSelecionadaId(m.id)}>
              <div className="nexo-modality-icon" style={{ background: "var(--nexo-blue-light)" }}>
                {m.emoji || "🏆"}
              </div>
              <div className="nexo-modality-info">
                <div className="nexo-modality-name">{m.nome}</div>
                <div className="nexo-modality-meta">{FORMATO_MODALIDADE_LABEL[m.formato] || m.formato}</div>
              </div>
            </button>
          ))}
      </div>

      {professor && (
        <button className="nexo-fab" onClick={() => setCriando(true)} aria-label="Nova modalidade">
          <Plus size={24} />
        </button>
      )}

      {criando && (
        <ModalidadeForm
          onClose={() => setCriando(false)}
          onSalvo={() => {
            setCriando(false)
            refetchModalidades()
          }}
        />
      )}
    </div>
  )
}
