import { useCallback, useMemo, useState } from "react"
import { ArrowLeft, Pencil, Shuffle } from "lucide-react"
import { classificacaoModalidade, gerarChaveamento } from "../../api/modalidades.js"
import { listarPartidas } from "../../api/partidas.js"
import { useApi } from "../../hooks/useApi.js"
import { useEquipes } from "../../context/EquipesContext.jsx"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { useModalidadeRealtime } from "../../hooks/useModalidadeRealtime.js"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"
import { FORMATO_MODALIDADE_LABEL } from "../../utils/format.js"
import MatchCard from "../partidas/MatchCard.jsx"
import Bracket from "../bracket/Bracket.jsx"
import ModalidadeForm from "./ModalidadeForm.jsx"
import ScoreModal from "../partidas/ScoreModal.jsx"
import "./Modalidades.css"

/**
 * Recebe só o ID e busca a modalidade sempre fresca do ModalidadesContext -
 * assim, depois de editar (PUT /modalidades/:id só devolve os campos
 * alterados, não o objeto inteiro), o cabeçalho desta tela reflete a
 * modalidade atualizada em vez de continuar mostrando a versão antiga que
 * foi selecionada na lista.
 *
 * Não existe DELETE /modalidades/:id no back-end (só equipes, partidas,
 * séries, provas e resultados têm exclusão - conferido no router), então
 * esta tela não tem botão de "excluir modalidade": criar um chamaria uma
 * rota inexistente e sempre falharia.
 */
export default function ModalidadeDetail({ modalidadeId, professor, onVoltar }) {
  const { modalidadesPorId, refetchModalidades } = useModalidades()
  const modalidade = modalidadesPorId.get(modalidadeId)

  const [editando, setEditando] = useState(false)
  const [gerando, setGerando] = useState(false)
  const [erroChaveamento, setErroChaveamento] = useState(null)
  const [partidaSelecionada, setPartidaSelecionada] = useState(null)

  const { equipes } = useEquipes()
  const equipesElegiveis = useMemo(
    () => equipes.filter((e) => e.modalidadeId === modalidadeId && !e.fundidaEmId),
    [equipes, modalidadeId]
  )

  const classificacaoFetcher = useCallback(() => classificacaoModalidade(modalidadeId), [modalidadeId])
  const { data: tabela, refetch: refetchClassificacao } = useApi(classificacaoFetcher, { skip: !modalidade })

  const partidasFetcher = useCallback(async () => {
    const todas = await listarPartidas()
    return todas.filter((p) => p.modalidadeId === modalidadeId)
  }, [modalidadeId])
  const { data: partidas, loading, error, refetch: refetchPartidas } = useApi(partidasFetcher, { skip: !modalidade })

  const atualizarTudo = useCallback(() => {
    refetchClassificacao()
    refetchPartidas()
  }, [refetchClassificacao, refetchPartidas])

  useModalidadeRealtime(modalidadeId, atualizarTudo)

  // A modalidade pode ter acabado de ser removida em outra aba/sessão, ou
  // o contexto ainda não terminou de carregar - evita quebrar a tela.
  if (!modalidade) {
    return (
      <div className="nexo-screen-inner">
        <div className="nexo-section">
          <button className="modality-back" onClick={onVoltar}>
            <ArrowLeft size={18} /> Modalidades
          </button>
          <EmptyState icon="🏐" texto="Modalidade não encontrada." />
        </div>
      </div>
    )
  }

  async function handleGerarChaveamento() {
    // Confere ANTES de chamar a API: com menos de 2 equipes, gerar
    // chaveamento apagaria as partidas existentes sem criar nenhuma nova
    // (o back-end agora também bloqueia isso, mas aqui dá o aviso sem
    // nem precisar da viagem até o servidor).
    if (equipesElegiveis.length < 2) {
      setErroChaveamento("É preciso ao menos 2 equipes cadastradas nesta modalidade para gerar o chaveamento.")
      return
    }

    if (
      !window.confirm(
        "Gerar chaveamento agora? Isso substitui todas as partidas já cadastradas nesta modalidade pelo novo chaveamento."
      )
    ) {
      return
    }

    setGerando(true)
    setErroChaveamento(null)
    try {
      await gerarChaveamento(modalidadeId)
      atualizarTudo()
    } catch (err) {
      setErroChaveamento(err.message)
    } finally {
      setGerando(false)
    }
  }

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-section" style={{ paddingBottom: 0 }}>
        <button className="modality-back" onClick={onVoltar}>
          <ArrowLeft size={18} /> Modalidades
        </button>

        <div className="nexo-card modality-header-card">
          <div className="modality-header-top">
            <div className="nexo-modality-icon" style={{ background: "var(--nexo-blue-light)" }}>
              {modalidade.emoji || "🏆"}
            </div>
            <div>
              <h1 className="modality-title">{modalidade.nome}</h1>
              <span className="nexo-modality-meta">
                {FORMATO_MODALIDADE_LABEL[modalidade.formato] || modalidade.formato}
                {modalidade.tipo && ` · ${modalidade.tipo === "equipe" ? "Por equipe" : "Individual"}`}
              </span>
            </div>
          </div>

          {professor && (
            <div className="modality-actions">
              <button className="nexo-btn ghost sm" onClick={() => setEditando(true)}>
                <Pencil size={15} /> Editar
              </button>
              {modalidade.formato !== "ranking" && (
                <button className="nexo-btn orange sm" onClick={handleGerarChaveamento} disabled={gerando}>
                  <Shuffle size={15} /> {gerando ? "Gerando..." : "Gerar chaveamento"}
                </button>
              )}
            </div>
          )}
          {erroChaveamento && <p className="modality-error">{erroChaveamento}</p>}
        </div>
      </div>

      {tabela && tabela.length > 0 && (
        <div className="nexo-section">
          <div className="nexo-section-header">
            <h2 className="nexo-section-title">Classificação</h2>
          </div>
          <div className="nexo-card" style={{ padding: 0 }}>
            <div className="nexo-table-wrap">
              <table className="nexo-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Equipe</th>
                    <th>J</th>
                    <th>V</th>
                    <th>D</th>
                    <th>Pts</th>
                  </tr>
                </thead>
                <tbody>
                  {tabela.map((linha, i) => (
                    <tr key={linha.timeId}>
                      <td>{i + 1}º</td>
                      <td><span className="nexo-table-team">{linha.equipe?.nome || "—"}</span></td>
                      <td>{linha.jogos}</td>
                      <td>{linha.vitorias}</td>
                      <td>{linha.derrotas}</td>
                      <td><span className="nexo-table-pts">{linha.pontos}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <div className="nexo-section" style={{ paddingTop: 0 }}>
        <div className="nexo-section-header">
          <h2 className="nexo-section-title">
            {modalidade.formato === "eliminatoria" ? "Chaveamento" : "Partidas"}
          </h2>
        </div>

        {loading && <LoadingState texto="Carregando partidas..." />}
        {error && <ErrorState mensagem={error} onRetry={refetchPartidas} />}
        {!loading && !error && partidas?.length === 0 && (
          <EmptyState icon="🏟️" texto="Nenhuma partida cadastrada nesta modalidade ainda." />
        )}

        {!loading && !error && partidas?.length > 0 && modalidade.formato === "eliminatoria" ? (
          <Bracket partidas={partidas} professor={professor} onEditarPartida={setPartidaSelecionada} />
        ) : (
          !loading &&
          !error &&
          partidas?.map((partida) => (
            <MatchCard
              key={partida.id}
              partida={partida}
              professor={professor}
              onClick={professor && partida.status !== "bye" ? () => setPartidaSelecionada(partida) : undefined}
            />
          ))
        )}
      </div>

      {editando && (
        <ModalidadeForm
          modalidade={modalidade}
          onClose={() => setEditando(false)}
          onSalvo={() => {
            setEditando(false)
            refetchModalidades()
            atualizarTudo()
          }}
        />
      )}

      {partidaSelecionada && (
        <ScoreModal
          partida={partidaSelecionada}
          onClose={() => setPartidaSelecionada(null)}
          onSalvo={() => {
            setPartidaSelecionada(null)
            atualizarTudo()
          }}
        />
      )}
    </div>
  )
}
