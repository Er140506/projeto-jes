import { useCallback, useMemo } from "react"
import { Trophy, Users, Layers, Radio } from "lucide-react"
import { listarPartidas } from "../../api/partidas.js"
import { useApi } from "../../hooks/useApi.js"
import { useEquipes } from "../../context/EquipesContext.jsx"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"
import { formatarDataHora, statusPartidaInfo } from "../../utils/format.js"
import "./Dashboard.css"

export default function Dashboard({ onGo }) {
  const fetcher = useCallback(listarPartidas, [])
  const { data: partidas, loading, error, refetch } = useApi(fetcher)
  const { equipesPorId, equipes } = useEquipes()
  const { modalidades } = useModalidades()

  const resumo = useMemo(() => {
    if (!partidas) return null
    const aoVivo = partidas.filter((p) => p.status === "ao_vivo")
    const recentes = partidas
      .filter((p) => p.status === "finalizado")
      .sort((a, b) => `${b.data}${b.hora}`.localeCompare(`${a.data}${a.hora}`))
      .slice(0, 5)
    return { aoVivo, recentes }
  }, [partidas])

  if (loading) return <LoadingState texto="Carregando painel..." />
  if (error) return <ErrorState mensagem={error} onRetry={refetch} />
  if (!resumo) return null

  const nomeEquipe = (id) => equipesPorId.get(id)?.nome || "A definir"
  const partidaDestaque = resumo.aoVivo[0]

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-hero">
        <div className="nexo-hero-badge">
          <Radio size={12} /> {resumo.aoVivo.length > 0 ? "Acontecendo agora" : "NEXO+"}
        </div>
        <h1 className="nexo-hero-title">
          {partidaDestaque
            ? `${nomeEquipe(partidaDestaque.timeAId)} vs ${nomeEquipe(partidaDestaque.timeBId)}`
            : "Bem-vindo ao NEXO+"}
        </h1>
        <p className="nexo-hero-sub">
          {partidaDestaque
            ? `${partidaDestaque.placarA} × ${partidaDestaque.placarB} · partida ao vivo`
            : "Acompanhe os jogos e o ranking dos campeonatos escolares"}
        </p>
        <div className="nexo-hero-stats">
          <div className="nexo-hero-stat">
            <span className="nexo-hero-stat-num">{modalidades.length}</span>
            <span className="nexo-hero-stat-label">Modalidades</span>
          </div>
          <div className="nexo-hero-stat">
            <span className="nexo-hero-stat-num">{equipes.length}</span>
            <span className="nexo-hero-stat-label">Equipes</span>
          </div>
          <div className="nexo-hero-stat">
            <span className="nexo-hero-stat-num">{resumo.aoVivo.length}</span>
            <span className="nexo-hero-stat-label">Ao vivo</span>
          </div>
        </div>
      </div>

      <div className="nexo-section">
        <div className="nexo-stats-row">
          <button className="nexo-stat-card" onClick={() => onGo("ranking")}>
            <div className="nexo-stat-icon gold">
              <Trophy size={20} />
            </div>
            <span className="nexo-stat-label">Ranking Geral</span>
          </button>
          <button className="nexo-stat-card" onClick={() => onGo("modalities")}>
            <div className="nexo-stat-icon blue">
              <Layers size={20} />
            </div>
            <span className="nexo-stat-number">{modalidades.length}</span>
            <span className="nexo-stat-label">Modalidades</span>
          </button>
          <button className="nexo-stat-card" onClick={() => onGo("teams")}>
            <div className="nexo-stat-icon orange">
              <Users size={20} />
            </div>
            <span className="nexo-stat-number">{equipes.length}</span>
            <span className="nexo-stat-label">Equipes</span>
          </button>
          <button className="nexo-stat-card" onClick={() => onGo("matches")}>
            <div className="nexo-stat-icon red">
              <Radio size={20} />
            </div>
            <span className="nexo-stat-number">{resumo.aoVivo.length}</span>
            <span className="nexo-stat-label">Ao vivo</span>
          </button>
        </div>
      </div>

      <div className="nexo-section">
        <div className="nexo-section-header">
          <h2 className="nexo-section-title">Resultados recentes</h2>
        </div>

        {resumo.recentes.length === 0 ? (
          <EmptyState icon="🏁" texto="Nenhum resultado registrado ainda." />
        ) : (
          <div className="nexo-card" style={{ padding: 0 }}>
            {resumo.recentes.map((partida) => (
              <div className="nexo-result-row" key={partida.id}>
                <span className="nexo-result-teams">
                  {nomeEquipe(partida.timeAId)} vs {nomeEquipe(partida.timeBId)}
                </span>
                <span className="nexo-result-score">
                  {partida.placarA} × {partida.placarB}
                </span>
                <span className={`nexo-badge ${statusPartidaInfo(partida.status).badge}`}>
                  {formatarDataHora(partida.data, partida.hora)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
