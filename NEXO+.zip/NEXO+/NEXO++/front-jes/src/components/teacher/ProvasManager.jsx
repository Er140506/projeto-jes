import { useCallback, useMemo, useState } from "react"
import { Plus } from "lucide-react"
import { listarProvas } from "../../api/provas.js"
import { listarResultados } from "../../api/resultados.js"
import { useApi } from "../../hooks/useApi.js"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"
import ProvaForm from "./ProvaForm.jsx"
import ProvaDetail from "./ProvaDetail.jsx"
import "./ManagementHub.css"

/**
 * Provas & Resultados servem as modalidades no formato "ranking"
 * (ex: atletismo) - o GET /provas não vem com os resultados populados
 * (o controller não faz include), então eles são buscados separadamente
 * e agrupados por provaId aqui.
 */
export default function ProvasManager() {
  const provasFetcher = useCallback(listarProvas, [])
  const resultadosFetcher = useCallback(listarResultados, [])
  const { data: provas, loading: carregandoProvas, error: erroProvas, refetch: refetchProvas } = useApi(provasFetcher)
  const { data: resultados, refetch: refetchResultados } = useApi(resultadosFetcher)
  const { modalidadesPorId } = useModalidades()

  const [criando, setCriando] = useState(false)
  const [selecionada, setSelecionada] = useState(null)

  const resultadosPorProva = useMemo(() => {
    const mapa = new Map()
    ;(resultados || []).forEach((r) => {
      if (!mapa.has(r.provaId)) mapa.set(r.provaId, [])
      mapa.get(r.provaId).push(r)
    })
    return mapa
  }, [resultados])

  function atualizarTudo() {
    refetchProvas()
    refetchResultados()
  }

  if (selecionada) {
    return (
      <ProvaDetail
        prova={selecionada}
        resultados={resultadosPorProva.get(selecionada.id) || []}
        onVoltar={() => setSelecionada(null)}
        onAlterado={atualizarTudo}
      />
    )
  }

  return (
    <div className="nexo-section" style={{ paddingTop: 0 }}>
      {carregandoProvas && <LoadingState texto="Carregando provas..." />}
      {erroProvas && <ErrorState mensagem={erroProvas} onRetry={refetchProvas} />}

      {!carregandoProvas && !erroProvas && provas?.length === 0 && (
        <EmptyState icon="🏃" texto="Nenhuma prova cadastrada ainda." />
      )}

      {!carregandoProvas && !erroProvas && provas?.length > 0 && (
        <div className="nexo-card" style={{ padding: 0 }}>
          {provas.map((prova) => (
            <button className="nexo-admin-row prova-row-btn" key={prova.id} onClick={() => setSelecionada(prova)}>
              <div className="nexo-admin-row-info">
                <div className="nexo-admin-row-title">{prova.nome}</div>
                <div className="nexo-admin-row-meta">
                  {modalidadesPorId.get(prova.modalidadeId)?.nome || "Modalidade removida"} ·{" "}
                  {prova.tipoMarca === "menor" ? "Menor marca vence" : "Maior marca vence"} ·{" "}
                  {(resultadosPorProva.get(prova.id) || []).length} resultado(s)
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      <button className="nexo-fab" onClick={() => setCriando(true)} aria-label="Nova prova">
        <Plus size={24} />
      </button>

      {criando && (
        <ProvaForm
          onClose={() => setCriando(false)}
          onSalvo={() => {
            setCriando(false)
            refetchProvas()
          }}
        />
      )}
    </div>
  )
}
