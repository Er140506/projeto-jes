import { useState } from "react"
import SeriesManager from "./SeriesManager.jsx"
import ProvasManager from "./ProvasManager.jsx"
import "./ManagementHub.css"

export default function ManagementHub() {
  const [aba, setAba] = useState("series")

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-filter-bar">
        <button className={`nexo-filter-chip ${aba === "series" ? "active" : ""}`} onClick={() => setAba("series")}>
          Séries
        </button>
        <button className={`nexo-filter-chip ${aba === "provas" ? "active" : ""}`} onClick={() => setAba("provas")}>
          Provas &amp; Resultados
        </button>
      </div>

      {aba === "series" ? <SeriesManager /> : <ProvasManager />}
    </div>
  )
}
