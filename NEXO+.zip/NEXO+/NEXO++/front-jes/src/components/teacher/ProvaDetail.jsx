import { useState } from "react"
import { ArrowLeft, Pencil, Trash2, Plus } from "lucide-react"
import { deletarProva } from "../../api/provas.js"
import { deletarResultado } from "../../api/resultados.js"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { EmptyState } from "../common/StateViews.jsx"
import ProvaForm from "./ProvaForm.jsx"
import ResultadoForm from "./ResultadoForm.jsx"
import "./ManagementHub.css"
import "../modalidades/Modalidades.css"

export default function ProvaDetail({ prova, resultados, onVoltar, onAlterado }) {
  const { modalidadesPorId } = useModalidades()
  const [editandoProva, setEditandoProva] = useState(false)
  const [resultadoEditando, setResultadoEditando] = useState(null) // null | {} (novo) | resultado
  const [erro, setErro] = useState(null)

  const ordenados = [...resultados].sort((a, b) =>
    prova.tipoMarca === "menor" ? a.marca - b.marca : b.marca - a.marca
  )

  async function excluirProva() {
    if (!window.confirm(`Excluir a prova "${prova.nome}"? Isso também remove seus resultados.`)) return
    try {
      await deletarProva(prova.id)
      onVoltar()
      onAlterado()
    } catch (err) {
      setErro(err.message)
    }
  }

  async function excluirResultado(resultado) {
    if (!window.confirm("Excluir este resultado?")) return
    setErro(null)
    try {
      await deletarResultado(resultado.id)
      onAlterado()
    } catch (err) {
      setErro(err.message)
    }
  }

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-section" style={{ paddingBottom: 0 }}>
        <button className="modality-back" onClick={onVoltar}>
          <ArrowLeft size={18} /> Provas
        </button>

        <div className="nexo-card modality-header-card">
          <div>
            <h1 className="modality-title">{prova.nome}</h1>
            <span className="nexo-modality-meta">
              {modalidadesPorId.get(prova.modalidadeId)?.nome} ·{" "}
              {prova.tipoMarca === "menor" ? "Menor marca vence" : "Maior marca vence"}
            </span>
          </div>
          <div className="modality-actions">
            <button className="nexo-btn ghost sm" onClick={() => setEditandoProva(true)}>
              <Pencil size={15} /> Editar
            </button>
            <button className="nexo-btn danger sm" onClick={excluirProva}>
              <Trash2 size={15} /> Excluir prova
            </button>
          </div>
          {erro && <p className="modality-error">{erro}</p>}
        </div>
      </div>

      <div className="nexo-section">
        <div className="nexo-section-header">
          <h2 className="nexo-section-title">Resultados</h2>
        </div>

        {ordenados.length === 0 ? (
          <EmptyState icon="📏" texto="Nenhum resultado lançado ainda." />
        ) : (
          <div className="nexo-card" style={{ padding: 0 }}>
            {ordenados.map((resultado, i) => (
              <div className="nexo-admin-row" key={resultado.id}>
                <span className="nexo-table-rank">{i + 1}º</span>
                <div className="nexo-admin-row-info">
                  <div className="nexo-admin-row-title">{resultado.equipe?.nome || "Equipe removida"}</div>
                  <div className="nexo-admin-row-meta">Marca: {resultado.marca}</div>
                </div>
                <div className="nexo-admin-row-actions">
                  <button className="nexo-icon-action" onClick={() => setResultadoEditando(resultado)} aria-label="Editar">
                    <Pencil size={16} />
                  </button>
                  <button className="nexo-icon-action danger" onClick={() => excluirResultado(resultado)} aria-label="Excluir">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        <button className="nexo-btn ghost full" style={{ marginTop: 12 }} onClick={() => setResultadoEditando({})}>
          <Plus size={16} /> Lançar resultado
        </button>
      </div>

      {editandoProva && (
        <ProvaForm
          prova={prova}
          onClose={() => setEditandoProva(false)}
          onSalvo={() => {
            setEditandoProva(false)
            onAlterado()
          }}
        />
      )}

      {resultadoEditando && (
        <ResultadoForm
          prova={prova}
          resultado={resultadoEditando.id ? resultadoEditando : null}
          onClose={() => setResultadoEditando(null)}
          onSalvo={() => {
            setResultadoEditando(null)
            onAlterado()
          }}
        />
      )}
    </div>
  )
}
