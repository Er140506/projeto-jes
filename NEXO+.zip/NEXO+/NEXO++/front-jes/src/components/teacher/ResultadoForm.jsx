import { useState } from "react"
import Modal from "../common/Modal.jsx"
import FormField from "../common/FormField.jsx"
import FormError from "../common/FormError.jsx"
import { useEquipes } from "../../context/EquipesContext.jsx"
import { criarResultado, atualizarResultado } from "../../api/resultados.js"

export default function ResultadoForm({ prova, resultado, onClose, onSalvo }) {
  const editando = !!resultado
  const { equipes } = useEquipes()
  const equipesDaModalidade = equipes.filter((e) => e.modalidadeId === prova.modalidadeId)

  const [equipeId, setEquipeId] = useState(resultado?.equipeId || equipesDaModalidade[0]?.id || "")
  const [marca, setMarca] = useState(resultado?.marca ?? "")
  const [erro, setErro] = useState(null)
  const [enviando, setEnviando] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setErro(null)

    if (!equipeId) {
      setErro("Cadastre uma equipe nesta modalidade antes de lançar resultados.")
      return
    }

    setEnviando(true)
    try {
      if (editando) {
        await atualizarResultado(resultado.id, { marca: Number(marca) })
      } else {
        await criarResultado({ provaId: prova.id, equipeId: Number(equipeId), marca: Number(marca) })
      }
      onSalvo()
    } catch (err) {
      setErro(err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <Modal title={editando ? "Editar resultado" : "Lançar resultado"} onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <FormError message={erro} />

        <FormField label="Equipe">
          <select value={equipeId} onChange={(e) => setEquipeId(e.target.value)} required disabled={editando}>
            <option value="" disabled>Selecione</option>
            {equipesDaModalidade.map((e) => (
              <option key={e.id} value={e.id}>{e.nome}</option>
            ))}
          </select>
        </FormField>

        <FormField
          label={prova.tipoMarca === "menor" ? "Marca (ex: tempo em segundos)" : "Marca (ex: distância em metros)"}
        >
          <input type="number" step="0.01" min="0.01" value={marca} onChange={(e) => setMarca(e.target.value)} required />
        </FormField>

        <button className="nexo-btn primary full" type="submit" disabled={enviando}>
          {enviando ? "Salvando..." : editando ? "Salvar alterações" : "Lançar resultado"}
        </button>
      </form>
    </Modal>
  )
}
