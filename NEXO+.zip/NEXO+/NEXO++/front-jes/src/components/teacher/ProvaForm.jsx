import { useMemo, useState } from "react"
import Modal from "../common/Modal.jsx"
import FormField from "../common/FormField.jsx"
import FormError from "../common/FormError.jsx"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { criarProva, atualizarProva } from "../../api/provas.js"

export default function ProvaForm({ prova, onClose, onSalvo }) {
  const editando = !!prova
  const { modalidades } = useModalidades()
  const modalidadesRanking = useMemo(() => modalidades.filter((m) => m.formato === "ranking"), [modalidades])

  const [modalidadeId, setModalidadeId] = useState(prova?.modalidadeId || modalidadesRanking[0]?.id || "")
  const [nome, setNome] = useState(prova?.nome || "")
  const [tipoMarca, setTipoMarca] = useState(prova?.tipoMarca || "menor")
  const [erro, setErro] = useState(null)
  const [enviando, setEnviando] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setErro(null)

    if (!modalidadeId) {
      setErro("Cadastre antes uma modalidade no formato 'Ranking por provas'.")
      return
    }

    setEnviando(true)
    const payload = { modalidadeId: Number(modalidadeId), nome, tipoMarca }

    try {
      if (editando) {
        await atualizarProva(prova.id, payload)
      } else {
        await criarProva(payload)
      }
      onSalvo()
    } catch (err) {
      setErro(err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <Modal title={editando ? "Editar prova" : "Nova prova"} onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <FormError message={erro} />

        <FormField label="Modalidade" hint="Só modalidades no formato 'Ranking por provas'">
          <select value={modalidadeId} onChange={(e) => setModalidadeId(e.target.value)} required>
            <option value="" disabled>Selecione</option>
            {modalidadesRanking.map((m) => (
              <option key={m.id} value={m.id}>{m.emoji} {m.nome}</option>
            ))}
          </select>
        </FormField>

        <FormField label="Nome da prova">
          <input value={nome} onChange={(e) => setNome(e.target.value)} required placeholder="Ex: 100m rasos" />
        </FormField>

        <FormField label="Critério de vitória">
          <select value={tipoMarca} onChange={(e) => setTipoMarca(e.target.value)}>
            <option value="menor">Menor marca vence (ex: tempo)</option>
            <option value="maior">Maior marca vence (ex: distância)</option>
          </select>
        </FormField>

        <button className="nexo-btn primary full" type="submit" disabled={enviando}>
          {enviando ? "Salvando..." : editando ? "Salvar alterações" : "Criar prova"}
        </button>
      </form>
    </Modal>
  )
}
