import { useState } from "react"
import Modal from "../common/Modal.jsx"
import FormField from "../common/FormField.jsx"
import FormError from "../common/FormError.jsx"
import { criarSerie, atualizarSerie } from "../../api/series.js"

export default function SerieForm({ serie, onClose, onSalvo }) {
  const editando = !!serie

  const [nome, setNome] = useState(serie?.nome || "")
  const [nivel, setNivel] = useState(serie?.nivel || "")
  const [pais, setPais] = useState(serie?.pais || "")
  const [corPrimaria, setCorPrimaria] = useState(serie?.corPrimaria || "#7C3AED")
  const [corSecundaria, setCorSecundaria] = useState(serie?.corSecundaria || "#A855F7")
  const [erro, setErro] = useState(null)
  const [enviando, setEnviando] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setErro(null)
    setEnviando(true)

    const payload = { nome, nivel: nivel || null, pais: pais || null, corPrimaria, corSecundaria }

    try {
      if (editando) {
        await atualizarSerie(serie.id, payload)
      } else {
        await criarSerie(payload)
      }
      onSalvo()
    } catch (err) {
      setErro(err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <Modal title={editando ? "Editar série" : "Nova série"} onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <FormError message={erro} />

        <FormField label="Nome" hint="Precisa ser único">
          <input value={nome} onChange={(e) => setNome(e.target.value)} required placeholder="Ex: Série A" />
        </FormField>

        <FormField label="Nível" hint="Opcional">
          <input value={nivel} onChange={(e) => setNivel(e.target.value)} placeholder="Ex: Ensino Médio" />
        </FormField>

        <FormField label="Categoria/País" hint="Opcional">
          <input value={pais} onChange={(e) => setPais(e.target.value)} placeholder="Ex: Regional" />
        </FormField>

        <FormField label="Cor primária">
          <input type="color" value={corPrimaria} onChange={(e) => setCorPrimaria(e.target.value)} />
        </FormField>

        <FormField label="Cor secundária">
          <input type="color" value={corSecundaria} onChange={(e) => setCorSecundaria(e.target.value)} />
        </FormField>

        <button className="nexo-btn primary full" type="submit" disabled={enviando}>
          {enviando ? "Salvando..." : editando ? "Salvar alterações" : "Criar série"}
        </button>
      </form>
    </Modal>
  )
}
