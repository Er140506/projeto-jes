import { useCallback, useState } from "react"
import { Plus, Pencil, Trash2 } from "lucide-react"
import { listarSeries, deletarSerie } from "../../api/series.js"
import { useApi } from "../../hooks/useApi.js"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"
import SerieForm from "./SerieForm.jsx"
import "./ManagementHub.css"

export default function SeriesManager() {
  const fetcher = useCallback(listarSeries, [])
  const { data: series, loading, error, refetch } = useApi(fetcher)
  const [editando, setEditando] = useState(null) // null | {} (nova) | serie existente
  const [erroExclusao, setErroExclusao] = useState(null)

  async function excluir(serie) {
    if (!window.confirm(`Excluir a série "${serie.nome}"?`)) return
    setErroExclusao(null)
    try {
      await deletarSerie(serie.id)
      refetch()
    } catch (err) {
      setErroExclusao(err.message)
    }
  }

  return (
    <div className="nexo-section" style={{ paddingTop: 0 }}>
      {loading && <LoadingState texto="Carregando séries..." />}
      {error && <ErrorState mensagem={error} onRetry={refetch} />}
      {erroExclusao && <p className="modality-error">{erroExclusao}</p>}

      {!loading && !error && series?.length === 0 && (
        <EmptyState icon="🎗️" texto="Nenhuma série cadastrada ainda." />
      )}

      {!loading && !error && series?.length > 0 && (
        <div className="nexo-card" style={{ padding: 0 }}>
          {series.map((serie) => (
            <div className="nexo-admin-row" key={serie.id}>
              <div
                className="serie-color-dot"
                style={{ background: serie.corPrimaria || "var(--nexo-blue)" }}
              />
              <div className="nexo-admin-row-info">
                <div className="nexo-admin-row-title">{serie.nome}</div>
                {(serie.nivel || serie.pais) && (
                  <div className="nexo-admin-row-meta">
                    {[serie.nivel, serie.pais].filter(Boolean).join(" · ")}
                  </div>
                )}
              </div>
              <div className="nexo-admin-row-actions">
                <button className="nexo-icon-action" onClick={() => setEditando(serie)} aria-label="Editar">
                  <Pencil size={16} />
                </button>
                <button className="nexo-icon-action danger" onClick={() => excluir(serie)} aria-label="Excluir">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <button className="nexo-fab" onClick={() => setEditando({})} aria-label="Nova série">
        <Plus size={24} />
      </button>

      {editando && (
        <SerieForm
          serie={editando.id ? editando : null}
          onClose={() => setEditando(null)}
          onSalvo={() => {
            setEditando(null)
            refetch()
          }}
        />
      )}
    </div>
  )
}
