import { useCallback, useMemo, useState } from "react"
import { Radio, Users, Layers, Settings2 } from "lucide-react"
import { listarPartidas } from "../../api/partidas.js"
import { useApi } from "../../hooks/useApi.js"
import { useEquipes } from "../../context/EquipesContext.jsx"
import { useModalidades } from "../../context/ModalidadesContext.jsx"
import { LoadingState, ErrorState, EmptyState } from "../common/StateViews.jsx"
import MatchCard from "../partidas/MatchCard.jsx"
import ScoreModal from "../partidas/ScoreModal.jsx"
import "./TeacherPanel.css"

/**
 * Home do professor: prioriza o que precisa de ação agora (partidas ao vivo
 * e as próximas a acontecer), com atalho direto pro lançamento de placar -
 * o fluxo mais usado durante os jogos, em quadra.
 */
export default function TeacherPanel({ onGo }) {
  const fetcher = useCallback(listarPartidas, [])
  const { data: partidas, loading, error, refetch } = useApi(fetcher)
  const { equipes } = useEquipes()
  const { modalidades } = useModalidades()
  const [partidaSelecionada, setPartidaSelecionada] = useState(null)

  const { aoVivo, proximas } = useMemo(() => {
    if (!partidas) return { aoVivo: [], proximas: [] }
    return {
      aoVivo: partidas.filter((p) => p.status === "ao_vivo"),
      proximas: partidas
        .filter((p) => p.status === "agendado")
        .sort((a, b) => `${a.data || ""}${a.hora || ""}`.localeCompare(`${b.data || ""}${b.hora || ""}`))
        .slice(0, 5),
    }
  }, [partidas])

  return (
    <div className="nexo-screen-inner">
      <div className="nexo-hero teacher-hero">
        <div className="nexo-hero-badge">
          <Radio size={12} /> Painel do Professor
        </div>
        <h1 className="nexo-hero-title">O que precisa da sua atenção agora</h1>
        <p className="nexo-hero-sub">Lance placares, gerencie equipes e acompanhe os campeonatos.</p>
      </div>

      <div className="nexo-section">
        <div className="teacher-actions-grid">
          <button className="teacher-action-card" onClick={() => onGo("teams")}>
            <Users size={22} />
            <span>Equipes</span>
          </button>
          <button className="teacher-action-card" onClick={() => onGo("modalities")}>
            <Layers size={22} />
            <span>Modalidades</span>
          </button>
          <button className="teacher-action-card" onClick={() => onGo("management")}>
            <Settings2 size={22} />
            <span>Séries &amp; Provas</span>
          </button>
        </div>
      </div>

      {loading && <LoadingState texto="Carregando partidas..." />}
      {error && <ErrorState mensagem={error} onRetry={refetch} />}

      {!loading && !error && (
        <>
          <div className="nexo-section" style={{ paddingTop: 0 }}>
            <div className="nexo-section-header">
              <h2 className="nexo-section-title">Ao vivo agora ({aoVivo.length})</h2>
            </div>
            {aoVivo.length === 0 ? (
              <EmptyState icon="📡" texto="Nenhuma partida ao vivo neste momento." />
            ) : (
              aoVivo.map((p) => (
                <MatchCard key={p.id} partida={p} professor onClick={() => setPartidaSelecionada(p)} />
              ))
            )}
          </div>

          <div className="nexo-section" style={{ paddingTop: 0 }}>
            <div className="nexo-section-header">
              <h2 className="nexo-section-title">Próximas partidas</h2>
            </div>
            {proximas.length === 0 ? (
              <EmptyState icon="🗓️" texto="Nenhuma partida agendada." />
            ) : (
              proximas.map((p) => (
                <MatchCard key={p.id} partida={p} professor onClick={() => setPartidaSelecionada(p)} />
              ))
            )}
          </div>
        </>
      )}

      <div className="nexo-section" style={{ paddingTop: 0 }}>
        <div className="nexo-stats-row">
          <div className="nexo-stat-card">
            <span className="nexo-stat-number">{modalidades.length}</span>
            <span className="nexo-stat-label">Modalidades</span>
          </div>
          <div className="nexo-stat-card">
            <span className="nexo-stat-number">{equipes.length}</span>
            <span className="nexo-stat-label">Equipes</span>
          </div>
        </div>
      </div>

      {partidaSelecionada && (
        <ScoreModal
          partida={partidaSelecionada}
          onClose={() => setPartidaSelecionada(null)}
          onSalvo={() => {
            setPartidaSelecionada(null)
            refetch()
          }}
        />
      )}
    </div>
  )
}
