import { useEffect } from "react"
import { getSocket, entrarNaModalidade, sairDaModalidade } from "../api/socket.js"

/**
 * Assina os eventos de tempo real de uma modalidade específica enquanto o
 * componente estiver montado (ex: tela de Partidas ou Classificação aberta
 * numa modalidade). `onEvento` recebe (nomeDoEvento, payload).
 */
export function useModalidadeRealtime(modalidadeId, onEvento) {
  useEffect(() => {
    if (!modalidadeId) return undefined

    const socket = getSocket()
    entrarNaModalidade(modalidadeId)

    const eventos = ["partida:criada", "partida:atualizada", "partida:deletada", "chaveamento:gerado"]
    const handlers = eventos.map((nome) => {
      const handler = (payload) => onEvento?.(nome, payload)
      socket.on(nome, handler)
      return [nome, handler]
    })

    return () => {
      handlers.forEach(([nome, handler]) => socket.off(nome, handler))
      sairDaModalidade(modalidadeId)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modalidadeId])
}
