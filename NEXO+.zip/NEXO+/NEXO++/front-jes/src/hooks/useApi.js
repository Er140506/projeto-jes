import { useCallback, useEffect, useState } from "react"

/**
 * Hook simples de busca de dados, usado por praticamente toda tela que lê
 * da API. Evita repetir o mesmo boilerplate de loading/error em cada
 * componente. `fetcher` deve ser estável (useCallback) pra não entrar em
 * loop - todas as telas seguem esse padrão.
 */
export function useApi(fetcher, { skip = false } = {}) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(!skip)
  const [error, setError] = useState(null)
  const [tentativa, setTentativa] = useState(0)

  const refetch = useCallback(() => setTentativa((n) => n + 1), [])

  useEffect(() => {
    if (skip) return undefined
    let ativo = true
    setLoading(true)
    setError(null)

    fetcher()
      .then((resultado) => {
        if (ativo) setData(resultado)
      })
      .catch((err) => {
        if (ativo) setError(err?.message || "Erro inesperado.")
      })
      .finally(() => {
        if (ativo) setLoading(false)
      })

    return () => {
      ativo = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [skip, tentativa, fetcher])

  return { data, loading, error, refetch, setData }
}
