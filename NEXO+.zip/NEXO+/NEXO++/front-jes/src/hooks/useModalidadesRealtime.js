import { useEffect } from "react"
import { getSocket, entrarNaModalidade, sairDaModalidade } from "../api/socket.js"

/**
 * Igual a useModalidadeRealtime, mas entra em várias salas de modalidade ao
 * mesmo tempo - usado na tela de Partidas quando o filtro é "todas as
 * modalidades" (o back-end só emite evento pra sala "modalidade_<id>",
 * então pra ouvir tudo é preciso entrar em cada sala individualmente).
 */
export function useModalidadesRealtime(modalidadeIds, onEvento) {
  const chave = (modalidadeIds || []).join(",")

  useEffect(() => {
    const ids = chave ? chave.split(",").map(Number) : []
    if (ids.length === 0) return undefined

    const socket = getSocket()
    ids.forEach(entrarNaModalidade)

    const eventos = ["partida:criada", "partida:atualizada", "partida:deletada", "chaveamento:gerado"]
    const handlers = eventos.map((nome) => {
      const handler = (payload) => onEvento?.(nome, payload)
      socket.on(nome, handler)
      return [nome, handler]
    })

    return () => {
      handlers.forEach(([nome, handler]) => socket.off(nome, handler))
      ids.forEach(sairDaModalidade)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chave])
}
