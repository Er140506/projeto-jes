import { createContext, useCallback, useContext, useMemo, useState, useEffect } from "react"
import { listarEquipes } from "../api/equipes.js"

/**
 * O back-end só faz "include" de time A/B em dois lugares (chaveamento e
 * classificação) - o GET /partidas comum devolve só timeAId/timeBId "crus"
 * (ver src/controllers/partidasControllers.js: partidasModel.findAll() sem
 * include nenhum). Pra não sair refazendo esse fetch em cada tela que
 * mostra uma partida, a lista de equipes é buscada uma vez aqui e
 * compartilhada como um Map por id.
 */
const EquipesContext = createContext(null)

export function EquipesProvider({ children }) {
  const [equipes, setEquipes] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const carregar = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const lista = await listarEquipes()
      setEquipes(lista)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    carregar()
  }, [carregar])

  const equipesPorId = useMemo(() => {
    const mapa = new Map()
    equipes.forEach((e) => mapa.set(e.id, e))
    return mapa
  }, [equipes])

  const value = useMemo(
    () => ({ equipes, equipesPorId, loading, error, refetchEquipes: carregar }),
    [equipes, equipesPorId, loading, error, carregar]
  )

  return <EquipesContext.Provider value={value}>{children}</EquipesContext.Provider>
}

export function useEquipes() {
  const ctx = useContext(EquipesContext)
  if (!ctx) throw new Error("useEquipes precisa estar dentro de <EquipesProvider>")
  return ctx
}
