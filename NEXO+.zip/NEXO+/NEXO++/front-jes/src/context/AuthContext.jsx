import { createContext, useCallback, useContext, useMemo, useState } from "react"
import { login as apiLogin, registrar as apiRegistrar } from "../api/auth.js"
import { setToken } from "../api/client.js"

const STORAGE_KEY = "nexo:usuario"
const AuthContext = createContext(null)

function lerUsuarioSalvo() {
  try {
    const bruto = localStorage.getItem(STORAGE_KEY)
    return bruto ? JSON.parse(bruto) : null
  } catch {
    return null
  }
}

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(() => lerUsuarioSalvo())

  const persistirSessao = useCallback((usuarioLogado, token) => {
    setUsuario(usuarioLogado)
    setToken(token)
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(usuarioLogado))
    } catch {
      // segue sem persistir se localStorage não estiver disponível
    }
  }, [])

  const entrar = useCallback(
    async (credenciais) => {
      const data = await apiLogin(credenciais)
      persistirSessao(data.usuario, data.token)
      return data.usuario
    },
    [persistirSessao]
  )

  const cadastrar = useCallback(
    async (dados) => {
      const data = await apiRegistrar(dados)
      persistirSessao(data.usuario, data.token)
      return data.usuario
    },
    [persistirSessao]
  )

  const sair = useCallback(() => {
    setUsuario(null)
    setToken(null)
    try {
      localStorage.removeItem(STORAGE_KEY)
    } catch {
      // ignora
    }
  }, [])

  // Uma rota protegida respondeu 401 (token expirado/inválido) - desloga.
  const tratarErroDeAuth = useCallback(
    (erro) => {
      if (erro?.status === 401) {
        sair()
        return true
      }
      return false
    },
    [sair]
  )

  const value = useMemo(
    () => ({ usuario, professor: !!usuario, entrar, cadastrar, sair, tratarErroDeAuth }),
    [usuario, entrar, cadastrar, sair, tratarErroDeAuth]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error("useAuth precisa estar dentro de <AuthProvider>")
  return ctx
}
