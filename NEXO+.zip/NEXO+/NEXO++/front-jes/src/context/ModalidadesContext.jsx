import { createContext, useCallback, useContext, useMemo, useState, useEffect } from "react"
import { listarModalidades } from "../api/modalidades.js"

/**
 * Lista de modalidades compartilhada - usada pelo menu de Modalidades, pelos
 * filtros de Partidas, pelo seletor de modalidade em Classificação/Ranking
 * Geral e pelos formulários de Equipe/Partida (professor). Evita repetir o
 * mesmo GET /modalidades em várias telas ao mesmo tempo.
 */
const ModalidadesContext = createContext(null)

export function ModalidadesProvider({ children }) {
  const [modalidades, setModalidades] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const carregar = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const lista = await listarModalidades()
      setModalidades(lista)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    carregar()
  }, [carregar])

  const modalidadesPorId = useMemo(() => {
    const mapa = new Map()
    modalidades.forEach((m) => mapa.set(m.id, m))
    return mapa
  }, [modalidades])

  const value = useMemo(
    () => ({ modalidades, modalidadesPorId, loading, error, refetchModalidades: carregar }),
    [modalidades, modalidadesPorId, loading, error, carregar]
  )

  return <ModalidadesContext.Provider value={value}>{children}</ModalidadesContext.Provider>
}

export function useModalidades() {
  const ctx = useContext(ModalidadesContext)
  if (!ctx) throw new Error("useModalidades precisa estar dentro de <ModalidadesProvider>")
  return ctx
}
