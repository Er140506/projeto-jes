import { identidadeGeralDaEquipe } from "./format.js"

/**
 * Ranking Geral - soma os pontos da mesma turma (ex: "3D") entre todas as
 * modalidades em que ela participa, mesmo sendo cadastros de equipe
 * separados em cada modalidade (item central do briefing).
 *
 * Fonte dos pontos: GET /modalidades/:id/classificacao (standingsService.js),
 * a mesma fonte de verdade usada na tela de Classificação por modalidade -
 * não existe um cálculo paralelo aqui, só o agrupamento por turma.
 *
 * @param {Array} modalidades - lista de modalidades (precisa de id/nome/emoji)
 * @param {Object} classificacoesPorModalidade - { [modalidadeId]: linhas[] }
 *   onde cada linha é o retorno de calcularClassificacao (timeId, pontos, equipe)
 */
export function calcularRankingGeral(modalidades, classificacoesPorModalidade) {
  const porTurma = new Map()

  for (const modalidade of modalidades) {
    const linhas = classificacoesPorModalidade[modalidade.id] || []

    for (const linha of linhas) {
      if (!linha.equipe) continue
      const chave = identidadeGeralDaEquipe(linha.equipe)

      if (!porTurma.has(chave)) {
        porTurma.set(chave, {
          chave,
          pontosTotais: 0,
          jogos: 0,
          vitorias: 0,
          derrotas: 0,
          porModalidade: [],
        })
      }

      const acumulado = porTurma.get(chave)
      acumulado.pontosTotais += linha.pontos || 0
      acumulado.jogos += linha.jogos || 0
      acumulado.vitorias += linha.vitorias || 0
      acumulado.derrotas += linha.derrotas || 0

      if (linha.jogos > 0 || linha.pontos > 0) {
        acumulado.porModalidade.push({
          modalidadeId: modalidade.id,
          nome: modalidade.nome,
          emoji: modalidade.emoji,
          pontos: linha.pontos || 0,
        })
      }
    }
  }

  return Array.from(porTurma.values()).sort((a, b) => {
    if (b.pontosTotais !== a.pontosTotais) return b.pontosTotais - a.pontosTotais
    return b.vitorias - a.vitorias
  })
}
