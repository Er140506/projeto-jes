// Formata "YYYY-MM-DD" (DATEONLY do back-end) pra "dd/mm" ou "dd/mm/aaaa"
export function formatarData(data, { comAno = false } = {}) {
  if (!data) return ""
  const [ano, mes, dia] = String(data).split("-")
  if (!ano || !mes || !dia) return data
  return comAno ? `${dia}/${mes}/${ano}` : `${dia}/${mes}`
}

// Formata "HH:MM:SS" (TIME do back-end) pra "HH:MM"
export function formatarHora(hora) {
  if (!hora) return ""
  return String(hora).slice(0, 5)
}

export function formatarDataHora(data, hora) {
  const partes = [formatarData(data), formatarHora(hora)].filter(Boolean)
  return partes.join(" às ")
}

export const STATUS_PARTIDA = {
  agendado: { label: "Em Breve", badge: "upcoming" },
  ao_vivo: { label: "Ao Vivo", badge: "live" },
  finalizado: { label: "Encerrada", badge: "finished" },
  bye: { label: "Bye", badge: "bye" },
}

export function statusPartidaInfo(status) {
  return STATUS_PARTIDA[status] || { label: status || "—", badge: "finished" }
}

export const FORMATO_MODALIDADE_LABEL = {
  pontoscorridos: "Pontos corridos",
  eliminatoria: "Eliminatória",
  ranking: "Ranking (provas)",
}

// Paleta fixa e determinística pra avatar de equipe - o back-end não guarda
// cor por equipe, então é gerada a partir do id (mesma equipe = mesma cor
// sempre, sem precisar guardar nada a mais).
const PALETA_EQUIPES = [
  "#005FCC", "#F56300", "#16A34A", "#7C3AED",
  "#DB2777", "#D97706", "#0EA5E9", "#DC2626",
]

export function corDaEquipe(id) {
  const n = Number(id) || 0
  return PALETA_EQUIPES[n % PALETA_EQUIPES.length]
}

export function iniciaisDaEquipe(nome) {
  if (!nome) return "?"
  const partes = nome.trim().split(/\s+/)
  if (partes.length === 1) return partes[0].slice(0, 2).toUpperCase()
  return (partes[0][0] + partes[partes.length - 1][0]).toUpperCase()
}

// Identificador "geral" da equipe pro Ranking Geral: usa a turma quando
// existe (é o campo pensado pra isso - ex: "3D"), senão cai pro nome.
export function identidadeGeralDaEquipe(equipe) {
  const turma = equipe?.turma?.trim()
  return turma || equipe?.nome || "—"
}
