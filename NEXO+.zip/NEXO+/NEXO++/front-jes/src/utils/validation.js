/**
 * O NEXO+ não permite empates (item 15 do briefing): toda partida encerrada
 * precisa ter um vencedor. O back-end também ganhou uma validação equivalente
 * em partidasControllers.js, mas o front confere antes de nem tentar enviar,
 * pra dar feedback imediato pro professor em quadra.
 */
export function validarPlacarSemEmpate(placarA, placarB) {
  if (placarA === "" || placarB === "" || placarA === null || placarB === null) {
    return "Informe os dois placares."
  }

  const a = Number(placarA)
  const b = Number(placarB)

  if (Number.isNaN(a) || Number.isNaN(b)) {
    return "Os placares devem ser números."
  }

  if (a < 0 || b < 0) {
    return "O placar não pode ser negativo."
  }

  if (a === b) {
    return "Não é permitido empate: ajuste o placar até haver um vencedor."
  }

  return null
}
