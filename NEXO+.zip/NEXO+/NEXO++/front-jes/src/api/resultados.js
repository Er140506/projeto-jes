import { apiRequest } from "./client.js"

// GET /resultados - responde um array puro (já formatado)
export function listarResultados() {
  return apiRequest("/resultados")
}

// POST /resultados - responde { msg, resultado } (professor)
export async function criarResultado(payload) {
  const data = await apiRequest("/resultados", { method: "POST", body: payload, auth: true })
  return data?.resultado ?? null
}

// PUT /resultados/:id - responde { msg, resultado }
export async function atualizarResultado(id, payload) {
  const data = await apiRequest(`/resultados/${id}`, { method: "PUT", body: payload, auth: true })
  return data?.resultado ?? null
}

// PATCH /resultados/:id - responde { msg, resultado }
export async function atualizarParcialResultado(id, payload) {
  const data = await apiRequest(`/resultados/${id}`, { method: "PATCH", body: payload, auth: true })
  return data?.resultado ?? null
}

// DELETE /resultados/:id
export function deletarResultado(id) {
  return apiRequest(`/resultados/${id}`, { method: "DELETE", auth: true })
}
