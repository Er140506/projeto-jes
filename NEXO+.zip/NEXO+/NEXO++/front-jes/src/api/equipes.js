import { apiRequest } from "./client.js"

// GET /equipes - responde um array puro
export function listarEquipes() {
  return apiRequest("/equipes")
}

// GET /equipes/:id - responde um objeto puro (com "modalidade" incluída)
export function buscarEquipe(id) {
  return apiRequest(`/equipes/${id}`)
}

// POST /equipes - responde { texto, id, modalidadeId, equipe } (professor)
export async function criarEquipe(payload) {
  const data = await apiRequest("/equipes", { method: "POST", body: payload, auth: true })
  return data?.equipe ?? null
}

// PUT /equipes/:id - responde { msg, equipe }
export async function atualizarEquipe(id, payload) {
  const data = await apiRequest(`/equipes/${id}`, { method: "PUT", body: payload, auth: true })
  return data?.equipe ?? null
}

// PATCH /equipes/:id - responde { msg, equipe }
export async function atualizarParcialEquipe(id, payload) {
  const data = await apiRequest(`/equipes/${id}`, { method: "PATCH", body: payload, auth: true })
  return data?.equipe ?? null
}

// DELETE /equipes/:id
export function deletarEquipe(id) {
  return apiRequest(`/equipes/${id}`, { method: "DELETE", auth: true })
}
