import { apiRequest } from "./client.js"

// GET /partidas - responde um array puro
export function listarPartidas() {
  return apiRequest("/partidas")
}

// GET /partidas/:id - responde um objeto puro
export function buscarPartida(id) {
  return apiRequest(`/partidas/${id}`)
}

// POST /partidas - responde { message, partida } (professor)
export async function criarPartida(payload) {
  const data = await apiRequest("/partidas", { method: "POST", body: payload, auth: true })
  return data?.partida ?? null
}

// PUT /partidas/:id - responde { message, partida }
export async function atualizarPartida(id, payload) {
  const data = await apiRequest(`/partidas/${id}`, { method: "PUT", body: payload, auth: true })
  return data?.partida ?? null
}

// DELETE /partidas/:id
export function deletarPartida(id) {
  return apiRequest(`/partidas/${id}`, { method: "DELETE", auth: true })
}
