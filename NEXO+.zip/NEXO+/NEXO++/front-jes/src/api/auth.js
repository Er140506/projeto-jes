import { apiRequest } from "./client.js"

// POST /auth/registrar - cadastro de professor (exige código de professor)
export function registrar({ nome, email, senha, codigoProfessor }) {
  return apiRequest("/auth/registrar", {
    method: "POST",
    body: { nome, email, senha, codigoProfessor },
  })
}

// POST /auth/login
export function login({ email, senha }) {
  return apiRequest("/auth/login", {
    method: "POST",
    body: { email, senha },
  })
}
