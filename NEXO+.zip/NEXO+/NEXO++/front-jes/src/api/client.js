/**
 * src/api/client.js
 * Cliente HTTP central do NEXO+. Reaproveita a ideia do src/API/api.js do
 * projeto antigo (uma função "api()" única por trás de tudo), mas corrige o
 * bug que existia lá (".resplace" em vez de ".replace") e adiciona:
 *  - leitura automática do token salvo (rotas de professor);
 *  - normalização de erro (o back-end usa "msg", "message" e "mensagem"
 *    dependendo da rota - ver seção 10 do briefing).
 */

const rawBase = import.meta.env.VITE_API_URL || "http://localhost:3000"
export const API_BASE = rawBase.replace(/\/$/, "")

const TOKEN_KEY = "nexo:token"

export function getToken() {
  try {
    return localStorage.getItem(TOKEN_KEY)
  } catch {
    return null
  }
}

export function setToken(token) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token)
    else localStorage.removeItem(TOKEN_KEY)
  } catch {
    // localStorage indisponível (modo privado, etc.) - segue sem persistir
  }
}

export class ApiError extends Error {
  constructor(message, status) {
    super(message)
    this.name = "ApiError"
    this.status = status
  }
}

/**
 * Faz uma requisição para a API e devolve o corpo já em JSON.
 * `auth: true` inclui o Bearer token salvo (rotas de professor).
 */
export async function apiRequest(path, { method = "GET", body, auth = false } = {}) {
  const headers = { "Content-Type": "application/json" }

  if (auth) {
    const token = getToken()
    if (token) headers.Authorization = `Bearer ${token}`
  }

  let response
  try {
    response = await fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    })
  } catch {
    throw new ApiError(`Não foi possível conectar à API em ${API_BASE}.`, 0)
  }

  let data = null
  try {
    data = await response.json()
  } catch {
    data = null
  }

  if (!response.ok) {
    // O back-end usa nomes diferentes pra mensagem de erro dependendo da rota
    // (msg, message, mensagem) - tenta todos antes de cair num texto genérico.
    const message =
      data?.msg || data?.message || data?.mensagem || `Erro ${response.status}`
    throw new ApiError(typeof message === "string" ? message : `Erro ${response.status}`, response.status)
  }

  return data
}
