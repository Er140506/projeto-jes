import { apiRequest } from "./client.js"

// GET /provas - responde um array puro (já formatado, com "resultados")
export function listarProvas() {
  return apiRequest("/provas")
}

// POST /provas - responde { msg, prova } (professor)
export async function criarProva(payload) {
  const data = await apiRequest("/provas", { method: "POST", body: payload, auth: true })
  return data?.prova ?? null
}

// PUT /provas/:id - responde { msg, prova }
export async function atualizarProva(id, payload) {
  const data = await apiRequest(`/provas/${id}`, { method: "PUT", body: payload, auth: true })
  return data?.prova ?? null
}

// PATCH /provas/:id - responde { msg, prova }
export async function atualizarParcialProva(id, payload) {
  const data = await apiRequest(`/provas/${id}`, { method: "PATCH", body: payload, auth: true })
  return data?.prova ?? null
}

// DELETE /provas/:id
export function deletarProva(id) {
  return apiRequest(`/provas/${id}`, { method: "DELETE", auth: true })
}
