import { apiRequest } from "./client.js"

// GET /series - responde um array puro (já formatado)
export function listarSeries() {
  return apiRequest("/series")
}

// POST /series - responde { msg, serie } (professor)
export async function criarSerie(payload) {
  const data = await apiRequest("/series", { method: "POST", body: payload, auth: true })
  return data?.serie ?? null
}

// PUT /series/:id - responde { msg, serie }
export async function atualizarSerie(id, payload) {
  const data = await apiRequest(`/series/${id}`, { method: "PUT", body: payload, auth: true })
  return data?.serie ?? null
}

// PATCH /series/:id - responde { msg, serie }
export async function atualizarParcialSerie(id, payload) {
  const data = await apiRequest(`/series/${id}`, { method: "PATCH", body: payload, auth: true })
  return data?.serie ?? null
}

// DELETE /series/:id
export function deletarSerie(id) {
  return apiRequest(`/series/${id}`, { method: "DELETE", auth: true })
}
