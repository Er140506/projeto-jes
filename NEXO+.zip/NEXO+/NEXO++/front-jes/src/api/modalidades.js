import { apiRequest } from "./client.js"

// GET /modalidades - o back-end responde { msg: [...] } (não é um array puro)
export async function listarModalidades() {
  const data = await apiRequest("/modalidades")
  return data?.msg ?? []
}

// GET /modalidades/:id - responde { msg: {...} }
export async function buscarModalidade(id) {
  const data = await apiRequest(`/modalidades/${id}`)
  return data?.msg ?? null
}

// POST /modalidades - responde { msg: modalidadeCriada } (professor)
export async function criarModalidade(payload) {
  const data = await apiRequest("/modalidades", { method: "POST", body: payload, auth: true })
  return data?.msg ?? null
}

// PUT /modalidades/:id - responde { msg: "...", atualizacao: {...} }
// (só devolve os campos alterados, não a modalidade inteira - por isso a
// tela sempre busca a modalidade de novo depois de salvar).
export async function atualizarModalidade(id, payload) {
  return apiRequest(`/modalidades/${id}`, { method: "PUT", body: payload, auth: true })
}

// NÃO existe DELETE /modalidades/:id no back-end (só equipes, partidas,
// séries, provas e resultados têm rota de exclusão - conferido no router).
// Por isso não há função de exclusão de modalidade aqui: criar uma
// chamaria uma rota inexistente e sempre falharia com 404.

// GET /modalidades/:id/classificacao - responde um array puro
export function classificacaoModalidade(id) {
  return apiRequest(`/modalidades/${id}/classificacao`)
}

// POST /modalidades/:id/chaveamento - responde um array puro de partidas
export function gerarChaveamento(id) {
  return apiRequest(`/modalidades/${id}/chaveamento`, { method: "POST", auth: true })
}
