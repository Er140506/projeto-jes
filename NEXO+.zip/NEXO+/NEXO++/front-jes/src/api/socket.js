/**
 * src/api/socket.js
 * Conexão Socket.io única, compartilhada pela aplicação inteira.
 * O back-end (src/config/socket.js) já expõe:
 *   - sala "modalidade_<id>", assinada via "entrarNaModalidade"/"sairDaModalidade"
 *   - eventos: "partida:criada", "partida:atualizada", "partida:deletada",
 *              "chaveamento:gerado"
 * O front só precisa entrar na sala da modalidade que está sendo vista e
 * escutar esses eventos pra atualizar a tela sem precisar de polling -
 * essencial pra "acompanhar ao vivo" em quadra.
 */
import { io } from "socket.io-client"
import { API_BASE } from "./client.js"

let socket = null

export function getSocket() {
  if (!socket) {
    socket = io(API_BASE, {
      autoConnect: true,
      transports: ["websocket", "polling"],
    })
  }
  return socket
}

export function entrarNaModalidade(modalidadeId) {
  if (!modalidadeId) return
  getSocket().emit("entrarNaModalidade", modalidadeId)
}

export function sairDaModalidade(modalidadeId) {
  if (!modalidadeId) return
  getSocket().emit("sairDaModalidade", modalidadeId)
}
